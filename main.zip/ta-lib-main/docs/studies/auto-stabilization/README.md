# Auto-Stabilization: how fast two starts agree

Measurements behind [the Auto-Stabilization design](../../auto-stabilization-design.md): for every function,
how the value at a bar computed from a later start approaches the value computed from bar 0.

## What is here

| File | What it does |
|---|---|
| `auto_stabilization_probe.c` | Runs every function through the abstraction layer from bar 0 and from six later starts, on three synthetic series, and writes one row per (series, function, parameter set, output, start) |
| `auto_stabilization_census.c` | Runs every function that owns an unstable id from two starts on thousands of random series and counts how often the need passes the count the library discards. Its header has the usage and the columns |
| `analyze.py` | Folds those rows into one line per output, worst case over series and starts, and a class per function |
| `rules_vs_need.py` | Sets the count the library discards at each level, for every function that owns an unstable id, against the measured need |
| `rules_check.py` | Checks the one-pole, SWAK and FISHER rules against the kernels at seven values of K and a grid of periods, and ADOSC's at both levels, with no library involved. The calibrated rules are not in it: section 3 of `results.txt` holds those. For T3, a calibrated rule, it computes what the seed that shows latest needs against the largest difference it causes, with the bound it meets: more than the count |
| `tie_break.c` | Compares MAXINDEX and MININDEX from two starts on a series full of equal extremes. It counted mismatches at the commit `results.txt` names, and counts none since a tie names the most recent bar (#503) |
| `results.txt` | The output of the probe and its scripts at the commit named on its first line. Rules re-sized since are on the [Unstable Period page](../../../website/src/api/unstable-period/README.md), and the census is rerun, not recorded |

## Running it

From the repository root, after `scripts/build.py`:

```bash
cd docs/studies/auto-stabilization
gcc -O2 -I../../../include auto_stabilization_probe.c ../../../cmake-build/libta-lib.a -lm -o /tmp/auto_stabilization_probe
gcc -O2 -I../../../include auto_stabilization_census.c ../../../cmake-build/libta-lib.a -lm -o /tmp/auto_stabilization_census
/tmp/auto_stabilization_probe 40000 > /tmp/probe.tsv          # every function; add a name to run one
CENSUS_CSV=../ema-seeding/data/ibm_daily_ohlc.csv /tmp/auto_stabilization_census 20000 1 > /tmp/census.tsv   # with real daily bars as a fourth series kind
CENSUS_PERIOD=98 CENSUS_NEEDS=/tmp/needs.tsv /tmp/auto_stabilization_census 20000 1 FRAMA   # one period, and every trial's need
OVR="FastLimit=0.2,SlowLimit=0.02" /tmp/auto_stabilization_probe 40000 MAMA   # one function, other parameters
python3 analyze.py /tmp/probe.tsv /tmp/agg.json summary
python3 analyze.py /tmp/probe.tsv /tmp/agg.json nonexact
python3 rules_vs_need.py /tmp/probe.tsv
python3 rules_check.py
```

Link the static library by path. `-lta-lib` picks up an installed TA-Lib instead of this tree's.

## Method

- **Series.** 40000 bars each: a geometric random walk (`rw`), a one-bar zigzag riding a slow
  drift (`zz`), and alternating 5000-bar up and down trends with little noise (`tr`). Prices are
  rounded to two decimals. The zigzag is the hard case for the adaptive averages: its efficiency
  ratio and its CMO sit near their minimum.
- **Starts.** Bar 0 against bars 1, 2, 5, 33, 250 and 1000. Every unstable period is 0, so the
  later run's first output is the function's own seed convention.
- **Parameter sets.** The defaults; every integer parameter whose name contains `Period`
  tripled; every MA type on every MA-type parameter.
- **Age.** A bar's age is the number of outputs the later run has already produced. An Auto
  count is a number of ages to discard.
- **Need.** For a tolerance `e^-K`, the first age from which the two runs stay within it for the
  rest of the series. `A<K>` measures against the largest difference between the two runs over
  all of the function's outputs (the seed discrepancy), `B<K>` against the range of the
  from-bar-0 output over the compared bars. `K` is 10 for the design's `PREC_4` level and 19
  for `PREC_8`; the regression leg holds `K - 3`, so 7 and 16.
- **Significant digits.** `C<d>` is the first age from which the two runs agree to `d`
  significant digits of the value: a difference of at most `10^-d` of the larger magnitude.
- **Count.** `auto4` and `auto8` are the bars the library adds to the lookback with every
  id on `PREC_4` and on `PREC_8`.
- **Bit-identity.** `Z` is the first age from which the two runs are bit-identical, -1 when
  they never are.
- **Classes.** `EXACT`: no difference at all. `ROUND`: differences below 1e-9 of the range.
  `CONV`: larger differences that fall under `e^-14`. `SLOW`: within `e^-7` but never within
  `e^-14`. `NEVER`: still above 1e-3 of the largest difference at the end of the series.

## What it does not show

- Real market data in the probe. The three shapes bracket the adaptive averages; they are not a
  market. The census takes one real series, whose windows overlap.
- Periods beyond three times the default.
- The Rust, Java and C# libraries.
- SWAK_BP away from its default delta. MAMA is measured at seven limit settings (section 6
  of `results.txt`).
- A tick that is a power of two. With such a tick the arithmetic is exact, two starts land on
  the same side of MAMA's zero test, and the census counts no start past its count at any
  price level; 0.2, 0.1 or 0.01 show what the Unstable Period page states.
- Functions that subtract two averages, away from the default and tripled periods. With the
  EMA, ZLEMA or RMA type, APO and PPO reach the level's own `e^-K` after the inherited count, by
  up to ADOSC's offset for the pair (e.g. 9 bars at the defaults, 48 at 25 and 26 with the EMA
  type). PVO does too (e.g. 15 bars at the defaults, 54 with its periods tripled). MACD and
  MACDFIX do by that offset less the signal EMA's count, which leaves something only with a
  signal period of 1 to 3 or close periods. At the default and tripled periods all of them
  hold the leg. `CENSUS_SET` reruns any of them. APO's and PPO's legs are seeded by the moving average they
  call, so a longer lookback alone does not age them; MACDEXT hands MACD its all-EMA case while
  its own lookback and stream are built from moving-average calls, so MACD cannot move alone.
- A measured need beyond `K` of about 21 is unreliable in the `rw` series: prices there grow by
  orders of magnitude, so late rounding differences are large against an early seed difference.

## Reading `results.txt`

Section 2 is the table to read: every output that is not bit-identical, at the defaults, with
periods tripled, and with each MA type. A `-1` in an `A` or `B` column means the tolerance was
never held to the end.

- `MAXINDEX` and `MINMAXINDEX` appear as `CONV` because of the tie-break in section 5, which
  #503 has since made independent of the start, not because they carry state.
- `CRSI` is `ROUND` at its defaults because its rank window is longer than its RSI legs need.
- `CORREL` at a period of 90 is classed `NEVER`: its rounding difference is 3.5e-8 of a narrow
  range, above the 1e-9 line `analyze.py` draws for `ROUND`. It carries no state.
- Section 2's other columns: `lb` is the lookback at 0, `S` the largest difference on that
  output, `S/R` the same against the output's range, `tail` the largest difference over the last
  tenth of the ages against `S`, and the last column the `A10` need on each series.
- Section 3 compares a rule with the need only for the function that owns the id, at the
  defaults and tripled periods. A function that inherits its count is held to the leg by
  `ta_regtest`, whose two-start comparison runs every function. KAMA, FRAMA and VIDYA are
  compared on `rw` and `tr` only: their counts are sized for a market that trends or wanders, and `zz` takes several times longer. Its
  flags: `LEG4` and `LEG8` mean the count is short of what the leg holds (none is); `k4` and
  `k8` that it is short at the level's own `e^-K`, which happens for ratio outputs; `sig4` and
  `sig8` that the value does not agree to that many significant digits at the count, which
  happens for outputs that pass through zero.
- The MA-type rows of section 2 are not compared with a rule by any script here. The cases
  that do not meet the count the design gives: the KAMA and VIDYA types on `zz`; the same two
  types in PVO on every series, because the volume here is independent noise; the VIDYA and the
  MAMA type in STOCHRSI, whose FastK rests at 0 or 100; and BBW with the T3 type on `tr`, where
  the seed difference is 5e-6 and the leg's threshold applied to it is at the band's own
  rounding.

# Rust Publish Runbook

Releasing the `ta-lib` crate to crates.io.

**`c-publish-runbook.md` must be completed first.** The C release of this version
has to be public before the crate publishes; `README.md` in this directory holds
the order.

**Status:** `ta-lib-dispatch` 0.1.2 published 2026-08-12. `ta-lib` not yet published: 0.8.1
shipped C and Java only, so the first crate carries whatever `VERSION` holds at the next
release. The remaining blockers are tracked in issue #179.

This is a **per-release** procedure, not a one-off: the crate version is locked to the repo
`VERSION`, and a release in practice changes something every backend shares. It runs on its own path, though: cutting a release publishes the C assets and
nothing else.

---

## What ships

The Rust workspace (`ta_codegen/output/rust/`) has three members; **two of them publish.**

| Member | Crate | Published | Version |
|---|---|---|---|
| `library/` | `ta-lib` | yes | locked to repo `VERSION` |
| `dispatch/` | `ta-lib-dispatch` | yes | independent (`DISPATCH_VERSION`) |
| `tools/` | `ta-lib-tools` | **no** — `publish = false` | — |

`dispatch` is one macro: the runtime FMA CPU-feature check, which is where the workspace's
only `unsafe` lives so the library can keep `#![forbid(unsafe_code)]`. It is versioned
independently because it changes when that macro changes, which is close to never — it is
**not** part of the lockstep in §2.

Both crate manifests, both READMEs and both `LICENSE` files are **generated**
(`generate_rust_crate_scaffolding`, `ta_codegen/generator/src/main.rs`). Never hand-edit
them; the regen-check gate fails if you do.

## Version policy

**One number, every backend.** C, the Rust crate and the Java artifact all carry the repo
`VERSION` — they are one generated library, not four that ship together.

**The obligation that buys: bump `MINOR` whenever any backend breaks its API**, even when
the change that motivated the release was a C patch. Cargo treats the minor as the breaking
position below 1.0, so `ta-lib = "0.8"` accepts every 0.8.x — a break shipped in a patch
upgrades itself into consumers' builds with no signal.

`cargo-semver-checks` in the dev nightly is the mechanical guard (#179 E7). It needs a
published version to compare against, so it can only be added *after* the first release.

`ta-lib-dispatch` is exempt: it carries its own version and is not bound to a release.

## Publish order, and why it is not optional

**`ta-lib-dispatch` first, then `ta-lib`** — and only when dispatch actually changed.

`library/Cargo.toml` pins the support crate exactly (`version = "=<DISPATCH_VERSION>"`, the
companion-crate pattern), so a published `ta-lib` can never float onto a newer macro. The
cost is that **while the pinned dispatch version is not yet on crates.io, `cargo package -p
ta-lib` and `cargo publish -p ta-lib` cannot resolve it at all.** Package the pair instead
and cargo verifies `ta-lib` against a temporary registry built from the sibling:

```bash
cargo package -p ta-lib-dispatch -p ta-lib
```

A published `.crate` is immutable. Changing *anything* inside one — the LICENSE, a README
badge, a keyword — is only expressible as a new version. That is what turned dispatch 0.1.1
into 0.1.2. Get the contents right before publishing, not after.

## Credentials

A maintainer's personal crates.io token, stored by `cargo login`, publishing from their
own machine, the same shape as the Java publish. No CI secret. Create it at crates.io,
Account Settings, API Tokens:

- **Scope:** `publish-update` only. Both crates exist, so no `publish-new`, and no
  owner or yank scope.
- **Crates:** `ta-lib` and `ta-lib-dispatch`.
- **Expiry:** set one (a year is fine). An expired token fails `cargo publish` loudly;
  make a new one and `cargo login` again.

Both crates are also owned by the team `github:ta-lib:rust-crate-io-owners`, whose
members can publish with their own token. That team, not one machine, is what keeps a
release possible when a maintainer is unavailable.

## Publishing

(RP1) Pre-flight.

`main nightly tests` runs these gates against `main` every night, plus the ones a local
machine cannot: the debug-profile overflow sweep, the MSRV floor, arm64, Windows and macOS.
Confirm its latest run is green on the commit being tagged. Run the gates below anyway: the
nightly can predate that commit, and the release path itself compiles no Rust.

From the repo root:

```bash
scripts/build.py generate        # output/rust must be regenerated, not stale
git status --porcelain           # must be empty — publish from a clean, committed tree
```

Then the crate's own gates, from `ta_codegen/output/rust/`:

```bash
cargo clippy --all-targets -- -D warnings
cargo test --lib -p ta-lib
cargo test --doc -p ta-lib
RUSTDOCFLAGS="-D warnings" cargo doc --no-deps -p ta-lib
cargo package -p ta-lib-dispatch -p ta-lib      # packages AND verify-builds both
```

And the cross-language gate, from `bin/`:

```bash
./ta_regtest --codegen --language=c,rust
./ta_regtest --xlang-hash --language=c,rust
```

Sanity-check the tarball contents once — the file list is easy to break and impossible to
fix after the fact:

```bash
tar tzf target/package/ta-lib-<VERSION>.crate | grep -Ev '^ta-lib-[^/]+/src/ta_func/'
# expect: Cargo.toml, Cargo.lock, LICENSE, README.md, src/lib.rs,
#         src/abstract_api.rs, src/ta_func_api.xml
```

(RP2) Publish `ta-lib-dispatch`, only when it changed, then (RP3) `ta-lib`.

```bash
cd ta_codegen/output/rust

cargo publish -p ta-lib-dispatch --dry-run     # only if dispatch changed
cargo publish -p ta-lib-dispatch               # permanent

cargo publish -p ta-lib --dry-run              # if dispatch changed, resolves only once it is live
cargo publish -p ta-lib                        # permanent
```

If the second publish cannot resolve the pin immediately after the first, that is index
lag — retry in a minute. It is not a manifest problem.

(RP4) **Check docs.rs actually built** — `https://docs.rs/ta-lib/<VERSION>`. docs.rs compiles
  independently of `cargo publish`, so a rustdoc failure there is invisible from a
  successful publish.
**Badges lag by minutes.** The README badges are live shields.io / docs.rs renders keyed
  on crate *name*; they report the registry's newest version and know nothing about the
  tree. Nothing to update.
(RP5) **Flip the website** (#179 B4): remove the "Not yet released" banner from
  `website/src/api/rust/README.md` and `website/src/api/rust/stream/README.md`. The site
  deploys from `main` on push.
(RP6) **`cargo owner --list`** on both crates if the maintainer set changed.
(RP7) **First publish only:** add `cargo-semver-checks` to the dev nightly against the
  version just published (#179 E7). It had no baseline before this release.

## Known, not covered here

- `ta-lib` 0.1.0–0.1.2 on crates.io are an **unrelated third-party FFI wrapper**, not ours:
  5097 downloads, zero reverse dependencies. Until the first real publish, the `ta-lib`
  README badges advertise that crate and its failing docs build. Whether to yank is #179 B2
  — it breaks no published crate and no existing lockfile, and only blocks new `^0.1`
  resolutions.

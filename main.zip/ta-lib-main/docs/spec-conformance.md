# Spec Conformance

The caller-facing rules are published at https://ta-lib.org/spec/ (source
`website/src/spec/`) under the `r` ids used below. The public pages hold only
what a caller relies on and a test enforces. This file is the maintainer's side:
per id, whether each backend conforms, what tests it, and why the rule is what
it is. It also states what the public pages leave out because only the tests and
a maintainer need it: the evaluation order. A
change to a published rule edits the public page; a change here edits a mark, a
test or a reason.

The columns are a conformance tracker, one per shipped backend. A new backend
adds a column; it does not change a rule.

## Marks

| Mark | Meaning |
|:---:|---|
| ✅ | Verified: a probe against the built artifact produced the specified behaviour. |
| ⚠️ | Deviates deliberately, **or** is implemented but not verified by the CI test suite. The rule's footnote says which, and where a deviation was decided. |
| ❌ | Measured, and does **not** conform. Needs a fix. Collected in Appendix D. |
| — | Not applicable: the condition cannot be expressed in this backend's types. |
| *(blank)* | Not yet verified. |

`—` is not a pass. It means the language removes the failure mode (safe Rust
cannot pass one buffer twice, an enum has no out-of-domain value), so there is
nothing for the backend to check and nothing for a caller to hit.

## Conformance

Rows of the batch, opening and advancing tables are in evaluation order: a call
that breaks several conditions reports the first (rationale: Order). Footnote
numbers are append-only: a
retired footnote leaves a gap, so a citation of `[4]` keeps its meaning.

### Lookback tier

| Rule | Topic | C | Rust | Java | C# | TypeScript | Go |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|
| rL2 | [rejection signal](https://ta-lib.org/spec/lookback/#rl2) | ✅ | ✅ | ✅ | ✅ |  |  |
| rL3 | [agrees with batch and Open](https://ta-lib.org/spec/lookback/#rl3) | ✅ | ✅ | ✅ | ✅ |  |  |
| rL4 | [agrees with C](https://ta-lib.org/spec/lookback/#rl4) | — | ✅ | ✅ | ✅ |  |  |
| rL2 | [its only failure](https://ta-lib.org/spec/lookback/#rl2) | ✅ | ✅ | ✅ | ✅ |  |  |
| rL11 | [display shift rejects what the lookback rejects](https://ta-lib.org/spec/lookback/#rl11) | ✅ | ✅ | ✅ | ✅ |  | ✅ |

### Batch tier

| Rule | Topic | C | Rust | Java | C# | TypeScript | Go |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|
| rB1 | [start index](https://ta-lib.org/spec/errors/#rb1) | ✅ | ✅ | ✅ | ✅ |  |  |
| rB2 | [end index](https://ta-lib.org/spec/errors/#rb2) | ✅ | ✅ | ✅ | ✅ |  |  |
| rB3 | [parameter value](https://ta-lib.org/spec/errors/#rb3) | ✅ | ✅ | ✅ | ✅ |  |  |
| rB4 | [absent argument](https://ta-lib.org/spec/errors/#rb4) | ✅ | ✅<br>[1] | ✅ | ✅<br>[2] |  |  |
| rB5 | [buffer length](https://ta-lib.org/spec/errors/#rb5) | ⚠️<br>[3] | ✅ | ✅ | ✅ |  |  |
| rB6 | [one buffer, two outputs](https://ta-lib.org/spec/errors/#rb6) | ✅ | ✅ | ✅ | ✅ |  |  |
| rB7 | [allocation failure](https://ta-lib.org/spec/errors/#rb7) | ✅<br>[24] | —<br>[24] | —<br>[24] | —<br>[24] | —<br>[24] | —<br>[24] |
| rB8 | [internal error](https://ta-lib.org/spec/errors/#rb8) | ✅<br>[25] | —<br>[25] | ✅<br>[25] | ✅<br>[25] |  |  |
| rB9 | [non-integer index or parameter](https://ta-lib.org/spec/errors/#rb9) | — | — | — | — |  |  |

[1] Rust slices cannot be null: an empty one is the absent argument. What C
writes through a pointer (the index/count pair, a stream handle) is returned
instead.

[2] A C# span cannot be null. A null array converts to an empty span, and an
empty span is the absent argument: rB4 or rS4 for an input or an output, rS7
for a stream's history. A stream's later input beside an empty history has the
history's length, so that call answers rS7 too.

[3] C has no sizes to check against: a property of the ABI, not a defect.

[24] C: `testAllocationFailure` (`test_internals.c`) fails a real allocation,
`TA_SMA_Open`'s ring, under an address-space limit; Linux without a sanitizer
only. Rust, Java, C#, TypeScript and Go allocate through their runtime and have no code for it.

[25] C: `testInternalErrorReported` (`test_internals.c`) trips an Abstract API
guard on a corrupted holder. No generated guard is reachable (rationale rB8),
so Java's `InternalFailureTest` and C#'s `BatchApiTest` check the mappers both
tiers throw through. Rust's `RetCode::InternalError` has no field for an id.

### Stream opening

| Rule | Topic | C | Rust | Java | C# | TypeScript | Go |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|
| rS2 | [history too long](https://ta-lib.org/spec/streaming/#rs2) | ✅<br>[5] | ✅<br>[5] | ⚠️<br>[5] | ✅<br>[5] |  |  |
| rS3 | [parameter value](https://ta-lib.org/spec/streaming/#rs3) | ✅ | ✅ | ✅ | ✅ |  |  |
| rS4 | [absent argument](https://ta-lib.org/spec/streaming/#rs4) | ✅ | ✅<br>[1] | ✅ | ✅<br>[2] |  |  |
| rS5 | [buffer length](https://ta-lib.org/spec/streaming/#rs5) | ⚠️<br>[3] | ✅ | ✅ | ✅ |  |  |
| rS6 | [aliasing](https://ta-lib.org/spec/streaming/#rs6) | ✅ | —<br>[22] | ✅ | ✅ |  |  |
| rS7 | [short history](https://ta-lib.org/spec/streaming/#rs7) | ✅<br>[4] | ✅<br>[4] | ✅<br>[4] | ✅<br>[4] |  |  |

The openers do not scan the history for non-finite values (rationale: finite
inputs).

[4] An empty history is answered at rS7's place, after rS2, rS3 and every
presence check, by the same anchor guard that answers any too-short history.
rS2 runs ahead of every presence check, and each backend's one check ahead of
it differs because each is a precondition for evaluating the history's length
rather than an argument competing with it. C publishes "no handle on any
failure" through `*stream`, and has nowhere to publish it without one. Java
cannot read a length from an array that is not there. A Rust slice cannot be
absent, and a C# null array arrives as an empty span, so rS7 is how an absent
history is reported (footnote [2]).

[5] The bound is in each opener's own prologue (Java and C# answer it from the
public frame, ahead of the other legs' presence checks). C takes `historyLen` as a bare `int`, so its
probe needs no array. Rust probes it on a zeroed vector of `INDEX_MAX + 2` elements that is
never read (`tests/stream_open_contract.rs`, 64-bit targets), and C# on a span
that claims that length over one element (`StreamApiTest`); both rest on the
length being refused before a bar is read. Java probes `Core.requireHistory`,
the helper every public opener calls (`NoPhantomIoTest`), because an array of
that length needs an 800 MB heap, so no Java opener is driven to it:
`java_public_openers_check_arguments_then_the_index_pair` holds the call. The
legal upper edge through an opener, a history of exactly `INDEX_MAX + 1` bars,
is unprobed in all four.

[22] Cannot be provoked. `OpenAndFill` takes each output as its own `&mut` slice,
so two outputs, or an output and the input, cannot name the same buffer while the
call is live. The batch tier emits rB6's pointer comparison anyway; the streaming
tier emits nothing.

### Stream advancing

| Rule | Topic | C | Rust | Java | C# | TypeScript | Go |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|
| rU1 | [absent handle](https://ta-lib.org/spec/streaming/#ru1) | ✅ | — | — | — | — | ⚠️<br>[26] |
| rU4 | [index ceiling](https://ta-lib.org/spec/streaming/#ru4) | ✅ | ✅ | ✅ | ✅ |  |  |
| rU2 | [absent output](https://ta-lib.org/spec/streaming/#ru2) | ✅ | — | ✅ | — | — | — |
| rU3 | [non-finite bar](https://ta-lib.org/spec/streaming/#ru3) | ✅ | ✅ | ✅ | ✅ |  |  |

[26] A nil Go handle is not checked: a method call on one panics.

### Stream release

| Rule | Topic | C | Rust | Java | C# | TypeScript | Go |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|
| rH10 | [`Close(NULL)`](https://ta-lib.org/spec/streaming/#rh10) | ✅ | — | — | — | — | — |

Only C has an explicit release. The others reclaim a handle when it becomes
unreachable, so there is no double release or use after release to track.
`sf_null_arguments` (`test_stream_finite.c`) calls `Close(NULL)` on each of its
emitted bodies, and drives a NULL handle and a NULL out-pointer through
`Update`, `Peek`, `Value`, `OutRange` and `Clone` in C.

### Configuration

| Rule | Topic | C | Rust | Java | C# | TypeScript | Go |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|
| rT2 | [target](https://ta-lib.org/spec/settings-threads/#rt2) | ✅ | ✅<br>[13] | ✅<br>[13] | ✅ |  |  |
| rT3 | [unstable period values](https://ta-lib.org/spec/settings-threads/#rt3) | ✅ | ✅ | ✅ | ✅ |  |  |
| rT4 | [reading](https://ta-lib.org/spec/settings-threads/#rt4) | ⚠️<br>[14] | ✅ | ✅ | ✅ |  |  |
| rT5 | [range type](https://ta-lib.org/spec/settings-threads/#rt5) | ✅ | — | — | ✅ |  |  |
| rT6 | [average period bound](https://ta-lib.org/spec/settings-threads/#rt6) | ✅ | ✅ | ✅ | ✅ |  |  |
| rT7 | [factor domain](https://ta-lib.org/spec/settings-threads/#rt7) | ✅ | ✅ | ✅ | ✅ |  |  |
| rT8 | [no change on refusal](https://ta-lib.org/spec/settings-threads/#rt8) | ✅ | ✅<br>[16] | ✅ | ✅ |  |  |
| rT10 | [initial state](https://ta-lib.org/spec/settings-threads/#rt10) | ✅ | — | — | — | — |  |
| rT11 | [threads in C](https://ta-lib.org/spec/settings-threads/#rt11) | ✅ | — | — | — | — | — |
| rT12 | [a getter returns what was set](https://ta-lib.org/spec/settings-threads/#rt12) | ✅ | ✅ | ✅ | ✅ |  |  |

[13] The wildcard is a declared member, so it is rejected by value; a target
outside the declared set is unrepresentable.

[14] C's getter returns the period itself, so it has no error channel. Accepted,
and pinned by `test_internals.c`; every other backend rejects it because a
getter that can fail costs it nothing.

[16] Verified that a later valid setter does not clear an earlier latched
rejection.

### TypeScript caveats

| Rule | Topic | C | Rust | Java | C# | TypeScript | Go |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|
| rJ1 | [names](https://ta-lib.org/spec/#rj1) | — | — | — | — |  | — |
| rJ2 | [call shape](https://ta-lib.org/spec/#rj2) | — | — | — | — |  | — |
| rJ3 | [absent output allocated](https://ta-lib.org/spec/#rj3) | — | — | — | — |  | — |
| rJ4 | [lookback options](https://ta-lib.org/spec/#rj4) | — | — | — | — |  | — |
| rJ5 | [display-shift order](https://ta-lib.org/spec/#rj5) | — | — | — | — |  | — |

## Test coverage

### Lookback rules

`xlang_lookback_leg`, `xlang_tier_native_check`, `xlang_tier_gold_check`
(regtest `--xlang-hash`); `aNullEnumLookbackIsMinusOne` in `BatchApiTest`
(Java) for a null MA type.

What enters a lookback, in C, in a bare run:

- rL1's first bar: `checkNoBarBeforeTheFirst` (`test_abstract.c`) overwrites
  every bar below `max(startIdx, lookback) - lookback` in every input of every
  function, with NaN and with a large finite value, at unstable periods 0 and
  5 and under each Auto level, and requires the same answer bit for bit. Its
  control overwrites one bar more, which most functions read. A lookback
  under a level that does not fit the series is a failure, not a skip.
- rL6: `test_func_unstable_shift` (`test_codegen.c`) raises each owner's id by
  5, at the default parameters and with every integer parameter at its
  minimum, and requires five more bars of lookback and the same remaining
  values (the four DI/DM functions at period 1: no more bars). For every
  function it sets every id above the lookback, at the default parameters,
  with every integer parameter at its minimum and at each value of its list
  parameters: a lookback that does not move must come with outputs that do
  not move. `test_adx.c` pins the DI/DM rows,
  `test_period_boundary.c` the DEMA, TEMA and period-1 MA stage counts, and
  `test_kc.c` KC's longer path over a grid of two unstable periods.
- rL8 under an Auto level: `test_auto_stabilization.c` asks every function flagged
  identity at a period of 1, owner of an id or not, for its lookback at a
  period of 1 with every id on each level, and requires 0.
- rL6 under an Auto level, and rZ1: the count leg of `test_auto_stabilization.c`. With one id
  on a level, its owner's lookback minus its lookback at 0 must equal the
  rule, computed from the file's own copy of the rule table, and the owner
  must report the bits it reports at 0, starting that many bars later. It
  runs at the defaults, with every integer parameter at its minimum and
  tripled, and at the real parameters a rule reads (SWAK_BP's delta, MAMA's
  limits). A function flagged as owning an id that the file has no rule for
  fails. `test_stc.c` holds the STC line to `TA_EMA(fast) - TA_EMA(slow)` bit
  for bit under each level: the fast leg is placed by its own lookback, which
  under a level is not the slow leg's.
- rZ2: the same file's offset check asks CKSP, ADOSC and KVO for their lookback
  with the id they inherit on a count of 30 and on each level: a count adds
  exactly 30 bars, a level the owner's count plus the function's own.
- rL5, rL7 and rL12: `abstract_lookback_under_settings` and, for rL12, `ds_under_settings` (`test_abstract.c`), for
  every function at its default parameters: another range type and factor on
  every candle setting moves no lookback; seven more bars on every averaging
  period move a candlestick lookback by seven or not at all, and no other;
  all three candle components plus an unstable period move no display shift;
  with every
  unstable period, then every averaging period, at `TA_INDEX_MAX` the lookback
  only grows, at the integer parameters' maxima too.
- rL2's signal: `abstract_check_display_shift` refuses a negative lookback
  other than -1 on every vector it drives. `ds_param_vectors` drives every
  function with each integer range, real range and integer list at its bounds
  or values and outside them, one parameter at a time, and requires the
  rejection outside.

rL4 under settings: `server_verify_lookback_value` compares each server's
lookback with C's, for every function with every unstable period raised
(`test_func_unstable_shift`) and for every candlestick function under each row
of the candle settings matrix (`test_candlestick.c`), under regtest
`--codegen`. Under each Auto level: `xlang_auto_lookback_leg` (regtest
`--xlang-hash`), with every id on the level, on every accepted vector of the
lookback leg plus one with every integer parameter at its maximum, the only
way into VIDYA's saturating arm. An Auto count depends on the parameters, so
this is the one check that the four renderings of every rule agree; it fails
when too few of its cases are lengthened by a level. The ports' display-shift calls are compared with C's at default
settings only.

### rL11

`abstract_check_display_shift` (`test_abstract.c`; against each server under
regtest `--codegen`, in-process in a bare run); `aNullEnumLookbackIsMinusOne`
in `BatchApiTest` (Java) for a null MA type.

### Batch conditions

`testIndexRange`, `checkOutputAliasRejected`, `testBatchArgumentContract`,
`c_batch_prologue_orders_parameters_before_presence`,
`rust_public_entry_orders_the_argument_contract`,
`rust_batch_impl_orders_capacity_before_aliasing`,
`every_declared_input_is_checked_in_every_backend`, `BatchApiTest` (Java, C#);
no phantom io and `--xlang-hash` for behaviour matching.

rB6: `checkOutputAliasRejected` (`test_abstract.c`) sweeps every ordered output
pair of every function, cross-typed pairs included, binding both onto one buffer
and requiring `TA_BAD_PARAM`, once over the full range and once over a range
that produces no values (Appendix D item 15), with the pair rebound apart as
that leg's control. Java's and C#'s `BatchApiTest` pass one array as two outputs.

rB4 and rS4, an empty argument: an output is refused when empty, on a range that
produces nothing and on a history too short to open, with a one-element control
for each. Java `anEmptyOutputIsAnAbsentOne` and C#
`AnEmptyOutputIsAnAbsentOne` (`BatchApiTest`), C# `StreamApiTest`, Rust
`an_empty_output_is_an_absent_one` (`tests/batch_contract.rs`),
`a_sub_lookback_range_frees_the_output_bound_and_not_the_input_bound`
(`tests/empty_range.rs`) and the short-history test of
`tests/stream_open_contract.rs`. An empty input was already refused by the
length rule.

rW6: `checkInPlaceAliasCorrect` (`test_abstract.c`),
`anOutputOnItsInputAnswersTheSame` (Java's `MetadataTest`) and
`AnOutputOnItsInputAnswersTheSame` (C#'s `MetadataTest`) place each real output
on each real input component of every function and require the answer of the
separate-buffer call bit for bit. The call ends 16 bars before the series does,
and those bars must keep their input values.

rP4: the float leg of regtest `--codegen` compares each server's float entry
point with its own double one on the same widened inputs, bit for bit: C over
the parameter sweep, Java and C# for every function at its default parameters
and at the default sentinels. It runs with all three on x86-64 only. C is also
held by `test_variants.c` in a bare run.

rP5: `arg_order_suite.rs` holds every committed batch declaration, C's
`TA_S_` form and the Java and C# float overloads included, to the YAML's order.
`validate_inputs`, `try_inject_parameters` and `validate_outputs`
(`docs_site.rs`) fail `generate` when a function page's Inputs, Parameters or
Outputs list differs from the call signature in name or order.

rJ1 to rJ5: `arg_order_suite.rs` holds every public TypeScript batch
declaration to its inputs, then `options?` (rJ2). `options.test.ts` pins the
returned views (rJ2), a partly given buffer set (rJ3), one options object
accepted by every function's batch, lookback, display shift (index first), open
and fill, and the lookback and display-shift throws (rJ4, rJ5). rJ1:
`ts_keys_follow_the_naming_rule` (`enums_suite.rs`) holds the naming functions
to the rule on each word shape; the corpus suites read each key off the
generated source, so a key's spelling in a function is held only where a test
hard-codes it (`batchArgs.test.ts`, `publicApi.test.ts`, `abstract.test.ts`,
`ts_stream_suite.rs`, `scripts/ts_consumer_check`).

rW7: `check_flags` (`parser/yaml.rs`) fails `generate` on a pattern output
whose flags break its rules, and `validate_output_values` (`docs_site.rs`) on an
Output Values table that differs from the values the flags declare.
`test_candle_value_set` (`test_candlestick.c`) holds every value a candlestick
function writes on its series to the values its output's flags declare, a color
output's sign to its candle's color, and each +-200 that follows an earlier
value in the range to a live pattern of its sign that no 200 has confirmed; a
+-200 whose pattern may precede the range is held to nothing. An output declares
level 200 exactly when `test_hikkake_predicate_coverage` proves it writes +-200.
It requires each of
+-80, +-100 and +-200 to occur, a color output to fire, a 200 to be matched, and
most functions to fire. That every declared value occurs is held per function
by the MC/DC scenarios (`pb_check_mcdc`), whose firing cases must produce
exactly the values of level 100 and 80 the output's flags declare, and by
`test_hikkake_predicate_coverage` for the +-200 of CDLHIKKAKE and CDLHIKKAKEMOD.

rE3 at a batch call: in C, `abstract_rejected_call_writes_nothing`
(`test_abstract.c`) paints every output buffer, calls each parameter vector of
its sweep that the lookback rejects and requires `TA_BAD_PARAM` with no element
written. Its two floors count the vectors rejected inside their declared range,
the rejections a C body makes itself after the generated checks: at a bound
(MAVP's inverted window) and one step above the lower bound (FRAMA's odd
period). `checkIndexRangeRejected` holds the same paint over every index
rejection, for every function. Java's and C#'s `BatchApiTest` hold a canary
after rB5. In Rust, `a_rejected_call_writes_no_output` (`abstract_api.rs`)
paints the outputs of every function through a holder and requires `BadParam`
with no element written, on an input one bar short and on a last output of one
element with the others bound. It repeats that for each integer-range parameter
one step outside its range and where the lookback refuses it at a bound or one
step above the lower bound. A holder answers the index codes itself, so the
order of the public entry's own index checks stays with
`rust_public_entry_orders_the_argument_contract`.

rB8's band: `testEnumValueContract` (`test_internals.c`) requires
`TA_SetRetCodeInfo` to name each value from 5000 to 5999 `TA_INTERNAL_ERROR`,
and `TA_UNKNOWN_ERR` for every value from 0 to 0xFFFF that is not a pinned
member and for four values outside that walk.

### Stream opening conditions

rS2, rS4, rS5 and rS7 are mapped below; rS3 is driven by the parameter
leg of `test_open_contract.c` over the C openers; rS6 is mapped only for one buffer
passed as two outputs: `testBatchArgumentContract` passes one buffer as
ACCBANDS's first two `OpenAndFill` outputs on a history of lookback bars
(`TA_BAD_PARAM`), with a separate-outputs control answering rS7.

`testStreamShortHistory` drives the empty history, rS2's rejecting side and rS7
in C: 9, 3 and 8 rejections, with rS7's 16 controls. Three of the empty-history
cases are *also* an absent argument and answer `TA_BAD_PARAM`, which is what
makes them about the order and not only the code.
`testBatchArgumentContract` drives rS4 with rB4's own argument shapes plus the
handle: 14 rejections and 5 controls, counted apart from rB4's. `BatchApiTest`
does the same for Java, and adds the empty history's; `StreamApiTest` covers rS4
in C#, where the condition is a zero-length span on a later input beside a
non-empty history. In
Rust `tests/stream_open_contract.rs` covers the empty history, rS2 and rS4's
empty output. Java's `BatchApiTest`
asserts `BAD_PARAM`, not only the exception type, at each rS4 rejection and at
an `OpenAndFill` output placed on its input (rS6).

`scripts/check_stream_retcodes.py` carries rS7, the empty history's anchor guard
included, over the whole generated corpus in every backend; a probe names one
function, and this is what covers the rest.
`every_open_pass_rejects_an_anchor_past_the_history` pins that no emptiness check
answers ahead of that guard, and
`csharp_public_openers_leave_an_empty_history_to_the_core` that no C# public
frame does.
`an_opener_never_answers_the_code_its_sub_call_handed_back` pins rS7 for composed
openers in the three ported backends; C is outside that sweep (rationale rS7).

rS5 is probed from **both sides** in each of the three backends that can express
it (an exactly sized output accepted and filled, one element shorter rejected),
because only the pair pins the arithmetic: a bound of `historyLen` would reject
the first, and no bound at all would accept the second. Each also drives the
tiers that hand-roll their fill (the dispatch tier including its identity arm,
the period bank, and a composed multi-output, whose sub-calls fill scratch of
their own rather than the caller's arrays), and asserts that a rejected fill left
the buffer untouched. Corpus-wide, the width is pinned by the three
`*_public_*fill*` / `*_public_openers_*` gates in `open_validation_suite.rs`,
which require it to be read from the function's own lookback rather than from
the history's length, and that the bound REJECT rather than merely exist.

### rH3, rH6 and rH9

`stream_verify`'s fork leg, in each language server and for every function,
opens its original with `OpenAndFill` on the shortest history, updates it,
forks it, calls `Advance` twice on the fork, and feeds both to the end. Every
bar of both must match batch, so a handle that came from `OpenAndFill` is held
to rH1 under `Update` (rH3), and a counted bar reaches nothing a step reads
(rH6); the fork reports two bars more than its original, which is the resume
recipe's step of one `Advance` per bar counted without being fed. MININDEX,
MAXINDEX and MINMAXINDEX ride the same leg: their index after the counted bars
is still the batch index over the bars fed.

rH9: `test_open_contract.c` requires `TA_FUNC_FLG_STREAM` on every function
`TA_ForEachFunc` lists and as many entries in the stream table.

A bar whose output is not finite: `dz_stream` (`test_div_zero.c`) and the
streaming halves of the Rust, Java and C# DivZero tests drive DIV, which
carries the flag rW5 names, through `Peek` and `Update` and require success,
the value and the bar count.

### rU3

Checked with an explicit finite test, so it rejects NaN and both infinities
alike. Verified: every `Update` and every `Peek` entry point checks its bar.

### rU4

No cross-language gate can reach rU4 (`stream_verify` runs 240 bars and
`INDEX_MAX` is 100 000 000), so it is pinned by one source gate and one runtime
probe per backend. `only_an_accepted_bar_advances_the_range` asserts the guard's
*position* (first, with only C's handle check allowed in front of it), the code
it names, and its ABSENCE from `Peek`, in all four backends over the whole
corpus. Then each of `test_stream_finite.c`, `stream_out_range.rs`,
`StreamSmokeTest` and `StreamApiTest` drives one handle to the ceiling and
demands the refusal, the code, and that nothing moved. The code is asserted
twice because the type cannot stand in for it: Java renders rB1's code and rU4's
as one exception class.

### Abstract API rules

rA1: in C, `checkHolderErrorContract` (`test_abstract.c`) ends on a fully bound
holder whose index or parameter the function refuses, which must come back as
the function's code. In the ports, through a bound holder: a short input and a
short output (`an_undersized_input_is_rejected_not_read_past`,
`an_undersized_output_is_rejected_not_written_past`) and both index codes
(`a_bound_holder_answers_the_batch_index_codes`) in Rust; `holderRejectsMisuse`
(Java) and `BinderRejectsMisuse` (C#) send a short input, a short output, an end
index below the start index and one array bound as two outputs. The generator's `rust_binder_calls_the_public_tier` pins that every
Rust arm calls the public entry point. Across languages: under `--codegen`,
`d2_param_vectors` sends each function's rejected parameter vectors through
`abstract_call`. An empty output: `an_empty_output_bound_to_a_holder_is_absent`
(Rust), `holderRejectsMisuse` (Java) and `BinderRejectsMisuse` (C#) bind MAMA's
second output to an empty buffer.

rA2: `testHolderStaysReusable` (C), `a_rejected_setter_leaves_the_holder_as_it_found_it`
(Rust), `aRejectedSetterLeavesTheHolderAsItFoundIt` (Java),
`ARejectedSetterLeavesTheCallAsItFoundIt` (C#), and the generator's
`metadata_price_setter_validates_before_writing` for all four.

rA3 in C: `checkHolderErrorContract` drives, for every function, each setter
with a wrong index, a wrong kind and a NULL, `TA_CallFunc` with the inputs, then
the outputs, unbound, with each NULL argument and with a holder the API did not
make. `test_default_calls` then checks, once, the lookups by name, the two table
frees, a handle the API did not give out, an absent one, and a parameter index
that names nothing. In the ports: `the_setters_refuse_what_does_not_belong`
(Rust), `holderRejectsMisuse` (Java) and `BinderRejectsMisuse` (C#), whose
helpers also require the exception to be a `TALibArgumentException`. Across
languages: under `--codegen`, `test_abstract.c` sends every function's
`abstract_call` with input 0, then output 0, left unbound (`skipInput`,
`skipOutput`) and requires C's code from each server. These tests pin today's
codes, which is more than rA3 asks: a deliberate refinement changes them
together.

rA4: `checkFuncHandleFoldsCase` (C), `lookup_is_ascii_case_insensitive`,
`the_fold_does_not_widen_what_resolves` and `unknown_name_is_none` (Rust),
`byNameFoldsAsciiCase` and `registryIsComplete` (Java), `ByNameFoldsAsciiCase`
and `CatalogueIsComplete` (C#).

rA5: in C, `callWithDefaults` calls every function through a holder with no
optional parameter set and, under `--codegen`, requires each server to give the
same answer with the declared defaults bound. In the ports:
`unset_matches_the_documented_default` (Rust), `callByNameMatchesTheTypedApi`
and `choiceListSentinelMatchesTheDefault` (Java),
`UnboundParametersTakeTheDocumentedDefault` (C#).

rA6: `test_default_calls` (C, over `TA_ForEachFunc`),
`every_function_binds_calls_and_agrees_with_its_lookback` (Rust),
`callByNameMatchesTheTypedApi` (Java), `BothCallPathsAgree` (C#). Each walks the
registry it tests. Across languages, under `--codegen`: `callWithDefaults` sends
an `abstract_call` for every function C enumerates, which each server resolves
in its shipped registry, and `abstract_verify_for_each_func` requires each
server's enumeration to be C's, as a set (Java's server enumerates a table of
its own).

rA7: the generator's `the_spec_flag_catalog_is_complete` requires each port's
flag type to carry the values of the C `#define`s of its family, one member per
value, with none of its own (an alias member and C#'s `None` aside); Rust lacks
none, and Java and C# lack only the
flags whose catalog row says so. It matches by value: a port member's name is
not held, so two members exchanging values would pass here. The same test holds
the catalog itself, which is more than rA7 asks: a row for every flag `#define`
of `ta_abstract.h`, no flag family beyond those it reads, the flag types the
specification page names, and "No function sets it" exactly on the flags no
function carries.

### Settings rules

rT3's levels and rT12: `testUnstablePeriodBounds` (`test_internals.c`) sets
each level per id and through the wildcard, reads it back as itself, and
requires `TA_INDEX_MAX + 5` and `+ 9` refused with nothing written;
`test_unstable_bounds` (`test_codegen.c`) sends the same values to every
server; the ports' own suites read both levels back from a built `Core`
(the Rust template's tests, `CoreApiTest`, `CoreBuilderTest`).

rT4's C getter: `test_internals.c`. rT8's Rust latch: verified by probe
(footnote [16]). rT8's candle setter in Java: `aRejectedCandleSettingWritesNothing`
(`CoreApiTest`), through CDLDOJI. rT2,
rT4 and rT5 under a cast out of the enum in C#: `CandleMisuseThrows` and
`MisuseThrows` (`CoreBuilderTest`). rT10: `testUnstablePeriodBounds`
(`test_internals.c`) changes the settings and initializes over them.

`TA_Initialize` and `TA_Shutdown` are idempotent (ruled 2026-10-02): a repeated
call of either answers `TA_SUCCESS` and leaves every setting at its default,
settings changed in between included. The public contract still asks for one
call of each, so this is held to, not promised: `testUnstablePeriodBounds`
calls each twice over changed settings. Nothing reads an initialized flag, so
`TA_LIB_NOT_INITIALIZE` has no producer.

rT11: `scripts/thread_sanitize.py` (nightly) builds the library and
`scripts/thread_sanitize.c` with clang's ThreadSanitizer and runs eight threads
through, for every function, its double and float batch entry points, its
lookup by name, lookback and `TA_CallFunc`, and its `Open`, `OpenAndFill` and
`Close`; then, for a spread of stream shapes, through `Peek`, `Update` and
`Advance` on a handle of their own, and `Peek`, `Value`, `OutRange` and `Clone`
on handles they share. The sanitizer's report is the test: a function-static
counter, or a `Peek` that stores into its handle, returns the right values on
every thread, so comparing answers finds neither. Not run on several threads:
the `Update`, `Peek`, `Advance` and accessors of the functions outside that
spread, and
the fused clones gcc builds, since under clang the FMA dispatch compiles away.

### Auto levels

What the specification states about a level is mapped above: rT3 and rT12
under Settings rules, rL1, rL4, rL6, rZ1 and rZ2 under Lookback rules. Two more legs run
under each level.

Stream against batch: `stream_verify`'s unstable-period leg runs one more pass
per level, in each language server, on the default vector of a function an
unstable id reaches, on every list-parameter vector and on the below-default boundary
vectors. MACDEXT gains an all-EMA vector at periods (7, 8, 2): its batch
delegates to MACD while its stream composes three MAs, each placed by its own
lookback, and under a level the two agree only if MACD places its fast leg the
same way: shorter periods forget a misplaced seed before the first bar
compared at `PREC_8`. The default all-EMA vector reports too few bars on the 240-bar
series to show it. A floor on the output bars compared under a level keeps
the passes from comparing nothing.

Two starts: the second leg of `test_auto_stabilization.c`, in a bare run. It is the
check behind what the specification says [a level targets](https://ta-lib.org/spec/auto-stabilization/#target),
which is not a numbered rule: the leg bounds the difference against the seed's, not the digits of the value. Every function runs on three
synthetic 8192-bar series (a random walk, alternating trends, a range), from
bar 0 and from six later starts, at the defaults, with every integer parameter
at its minimum and tripled, at every MA type, and at the real parameters a
rule reads. Compared at every bar both runs report:

- a call whose lookback no level moves: within `T = max(1e-10, 1e-7 * range)`,
  integer outputs equal;
- a converging call: with `S` the largest difference at a setting of 0, within
  `max(e^-(K-3) * S, T)` at `PREC_4` and within `max(e^-(K-3) * S, F)` at
  `PREC_8`, with `F` a committed floor per function and output, for the
  outputs whose own rounding is above that threshold. A call whose `S` is
  under `T` is not a comparison;
- a function flagged `path_dependent` is not compared, and fails if it meets
  the converging criterion on every series and start.

Not compared: KAMA, FRAMA, VIDYA and the KAMA and VIDYA MA types on the range
series, which their counts are not sized for; STOCHRSI with the MAMA or VIDYA
type, whose FastK rests at 0 or 100; CRSI when a level lengthens its lookback,
its streak being a state machine. MAXINDEX, MININDEX and MINMAXINDEX are
compared after rebasing the later start's index, which counts from the first
bar handed in. One counter per class and a floor on the bars compared, per
series for a window and per call for a converging one, keep the leg from
passing on nothing; a call that fails or reports no lookback is a failure.

Sampled starts: `scripts/auto_stabilization_sample.py`, its own nightly job. The
leg above runs three series from six starts, which cannot show how often a
count sized by measurement runs short. The script runs the census of
`docs/studies/auto-stabilization/` on a fixed seed, for every function that
owns an unstable id, at its defaults and with its periods tripled and at their
minimum, on a random walk, a flipping trend, a range-bound series and windows
of the IBM daily series. Each row is held to `census_table.tsv`: a ceiling on
the share of starts whose need passes the count at each level, the largest
need, and the starts that never converge. The trial that set the largest need
of each row when the table was made is replayed. A row on either side without
its counterpart fails, so a function that gains an unstable id brings its rows,
and so does a row whose lookback or count moved: a trial's start and length
follow them, so a re-sized rule is calibrated again.
The [known exceptions](https://ta-lib.org/spec/auto-stabilization/#exceptions)
are rows like any other: their ceiling is the share measured, not zero.

### Versions and determinism

rV1: `scripts/abi.py check`, the PR gate's "Public C ABI matches ABI.manifest"
step (`pr-codegen-gate.yml`), measures the installed headers' declarations
against `ABI.released` and refuses a removed or changed one without a new N;
`nightly-jobs.yml` checks the soname and `macos-jobs.yml` the macOS install name against the N
in `ABI.manifest`.

rV2: `testEnumValueContract` pins C's numbers. `MAType` reaches every language
from `enums.yaml`, and `FuncUnstId` reaches C, Java and C# from it; Rust's
`FuncUnstId` is a template that `generate` refuses when its member names or
their order differ from `enums.yaml`, with its wildcard's number pinned by
`rust_funcunstid_pins_the_all_sentinel`. `RangeType` and `CandleSettingType` are
written by hand in C's header and in each port:
`every_backend_candle_enum_member_carries_c_s_number` (generator suite) reads
C's numbers from `ta_defs.h` and requires them of every Rust, Java and C#
member.

rV3: `rust_matype_emits_every_yaml_variant_and_its_frozen_shape` and
`rust_template_enums_are_non_exhaustive` (generator suite).

rD1's set of functions: `the_transcendental_flag_is_what_the_sources_call`
(generator suite) derives it from the indicator sources and requires the same
set to carry `TA_FUNC_FLG_USES_TRANSCENDENTAL`, the flag that moves a Java or C#
comparison from bitwise to a tolerance.
`test_elementary_math` (`test_1in_1out.c`) holds each elementary function to
the host math library's routine of that name. rD1's and rH1's transcendental
exception: where the batch tier is a vector kernel, `regtest_vmath_batch`
(`test_util.c`) alone moves a comparison of a kernel value with a one-value
result from bitwise to `fuzz_vmath_near`, and `test_elementary_lanes` holds
every element of a batch call to one function of one value on every platform.

rD2: `CODEGEN_TRANSCENDENTAL_TOL` (`test_codegen.h`) is the rule's figure and
its shape, 1e-9 relative above a magnitude of 1 and absolute below. It holds
every Java and C# call that evaluates a transcendental function against C, on
one machine, in `--codegen` and `--xlang-hash`. Elsewhere on one machine the
comparisons are bitwise or the kernel lane's `fuzz_vmath_near`, both tighter:
that one allows `FUZZ_VMATH_MAX_STEPS` (8) adjacent doubles of the same sign,
under 1.8e-15 of the value, which is where a stream stands against its batch
call for a transcendental function.
HT_DCPHASE, HT_SINE and HT_TRENDMODE are skipped on the constant series
(`xlang_illcond`), where their phase is undefined and two languages can differ
outright.

rD3: it states what is not promised, so no test holds it. What a level does
bound between two starts is the second leg under [Auto levels](#auto-levels),
and how often a count runs short is the sampled census there.

rD2 between machines ([across machines](https://ta-lib.org/spec/versions/#machines)): no machine is compared with another. Each is held on its own to the suite's
reference values, which bounds two machines indirectly. `ta_test_legacy` replays
the v0.6.4 values, frozen at 17 digits, on every platform, each function within
its own bound, all under 1e-9. The Hilbert functions and the elementary ones, whose
value follows the host math library, have no v0.6.4 row:
`test_transcendental_ref.c` holds every function
flagged `TA_FUNC_FLG_USES_TRANSCENDENTAL`, those among them, to
values committed once, at rD2's figure and shape, and a flagged function
without a row fails. Known gap: a function added after v0.6.4 that calls no
transcendental function has no frozen value; its hand-written values are
compared at 0.01.

The build-flags caller item: `the_three_build_systems_carry_the_same_flags`
(generator suite) requires the statements that set `-ffp-contract=off`,
`-fno-math-errno` and the two alignment flags in CMake, autotools and the
generator, and `-ffast-math` and `-Ofast` in none.

## Rationale

### Order

The public pages promise one code per rejected call and no order (rE1): no
correct caller depends on which code a doubly wrong call gets. Each tier still
evaluates its conditions in the order of its table above, in all four backends.
That is what makes a multi-fault call predictable for automated tests, and what
keeps rE2 true for it. Conditions answering the same code are unordered in
practice: a caller cannot tell which of them fired, so swapping two is
invisible. The cross-language comparison covers the index codes
(`test_index_range_xlang`), the parameter codes and the opener codes
(`--xlang-hash`); the other conditions are tested per language.

### rE3: checks precede writes

The range out-parameters in C. The public rule is the weak one, to keep room
to change: `*outBegIdx` and `*outNBElement` may or may not have been written
when a call does not return `TA_SUCCESS`, so a caller reads them after
`TA_SUCCESS` only. The library holds itself to more, and the suite tests it:

- `TA_INSUFFICIENT_HISTORY` writes 0 to both. Nothing was output, and a caller
  that skipped the return code reads an empty range instead of stale indices.
- Every other rejection leaves both as the caller had them. The aim is one
  write of the pair, at exit, on success; a body that still writes it earlier
  does so after its last argument check.
- Nothing holds after rB7 or rB8: some bodies zero the pair on those exits,
  others leave it.

Coverage, each call painting the pair with a sentinel first: every `TA_CallFunc`
the suite makes (`regtest_guarded_call`, which `ta_test_priv.h` substitutes for
it, failing the run at `freeLib`); the double and float entry of every function
at each in-range parameter vector its body refuses (`test_variants.c`); every
function's `OpenAndFill`, held to (0, 0) at each too-short history and to the
sentinel at each out-of-range parameter (`test_open_contract.c`); FRAMA's and
MAVP's `OpenAndFill` at the parameters their bodies refuse (`test_frama.c`,
`test_mavp.c`); the absent-argument rows of `test_internals.c`.

### Messages

The public pages say only to branch on the code. The `<N>: ` and
`<N> <verb>: ` prefixes are emitted and tested all the same.

A composed function calls its callee's public entry point, so a rejection the
callee detects carries the callee's name. Accepted rather than worked around: a
sub-function failure naming the sub-function is understandable, and restoring
the outer name would mean catching and rethrowing at every cross-call, which the
machinery calling the public tier exists to remove. It is narrow in practice:
every outer function validates its own parameters before it cross-calls, so
reaching it needs a fault the outer prologue does not screen for first.
`docs/streaming-api-design.md` fixes the `<N> <verb>: ` prefix as a
cross-language contract.

### Failure mapping ([hub](https://ta-lib.org/spec/#failures))

The platform exception types are many-to-one: one `IndexOutOfBoundsException`
serves both index codes in Java, one `IllegalStateException` or
`InvalidOperationException` the library-side ones. A caller who cannot tell two
conditions apart cannot respond to either, so every exception Java and C# raise
from the batch and stream tiers carries its `TA_RetCode`. They are subclasses of
the platform types, so an existing `catch` is unaffected. An absent argument and
a buffer too short, which have no code of their own (and the second of which C
cannot detect), answer `TA_BAD_PARAM`, which makes the mapping total over those
two tiers.

The settings builders raise plain platform types for their own refusals: they
are not function calls, so they have no `TA_RetCode` a caller would be
recovering. The Abstract API's refusals carry a code (rA3), and its
*dispatch* calls the public entry point, so an indicator's rejection reaches the
caller carrying its own code in every backend.

C#'s rU4 is a `TALibArgumentException`, not the
`TALibArgumentOutOfRangeException` its index codes take in batch: `Update` and
`Advance` have no `endIdx` parameter to name. An opener's empty-history
`ParamName` is the history series, the argument a caller can change.

A backend enum carrying a member it never produces is harmless; one missing a
member it needs is not.

Known gap: Java's and C#'s MA stream throw a plain `IllegalStateException` /
`InvalidOperationException` ("unreachable: open rejects arms without a
sub-stream", `Core_MA.java`, `Core_MA.cs`) with no code and no prefix.
Unreachable by construction.

### rB4, rS4: empty is absent

An argument is absent when it is `NULL` in C, null or zero-length in Java,
zero-length in Rust and C#, and the call answers
`TA_BAD_PARAM` at the absent check: after the index and parameter conditions,
before any length (ruled 2026-10-02). A zero-length buffer is almost always a
mistake, and a caller cannot cheaply tell whether a call will produce nothing.
"No room is owed when nothing is written" protected no real use, and hid a null
buffer behind a success or behind `TA_INSUFFICIENT_HISTORY`. C sees only `NULL`:
a buffer of no capacity is invisible there, as every length is.

A stream's empty history is not part of it: it answers rS7, after rS3 and
rS4, like any history too short to open.

### rB5, rS5: C

Measured with guard-paged buffers: an input that does not reach `endIdx`, or an
output too short for the count the call produces, is read or written anyway, and
the call faults inside the algorithm with the output already partly written.
Behind Rust's check the same bound is asserted for LLVM: a panic, never memory
corruption, since the crate forbids `unsafe`.

### rB6, rW6: overlap

Decided in #225: the library detects buffer identity and nothing finer. The four
backends do not even agree on whether a partial overlap can exist, so a stronger
rule could not be one rule:

| backend | can a caller express a partial overlap? | detected? |
|---|---|---|
| C | Yes: two pointers into one allocation | **No.** Detecting it means ordering pointers into different declared objects, which C leaves undefined; a conforming check would have to launder them through `uintptr_t` and reason about representation |
| Java | **No**: two arrays are the same object or disjoint; there is no offset to differ | n/a, so the run-time reference-equality check is complete |
| Rust | **No** in safe code: `&[T]` and `&mut [T]` over the same data cannot coexist, and two `&mut` cannot either | the `as_ptr()` identity guard never fires in safe code; it is kept for parity, and for the FFI boundary |
| C# | **Yes**: two `Span<T>` slices of one array | **Yes**, incidentally: `Span.Overlaps` exists, so the check is one call |

Measured: `TA_BBANDS` with its three bands one element apart returns
`TA_SUCCESS` and a wrong upper band on every bar.

So the guarantee is set by the weakest member that can express the problem,
which is C, and C is the one language where the check is not merely expensive
but not straightforwardly expressible. Java and Rust satisfy the stronger rule
for free by making the state unreachable, which is not the same as enforcing it.

Outputs must be different buffers in every language. An empty output is absent
(rB4) and never reaches a verdict of the pair guard. A call that is both
undersized and identical answers rB5, the earlier rule (#261).

Outputs of different element types can only be the same buffer through a
reinterpreting cast. C compares both through `const void *` (well defined, not
the `double * == int *` constraint violation that reading suggests), and C#
compares byte ranges through `MemoryMarshal.AsBytes`, because
`MemoryMarshal.Cast` lets a caller lay a `Span<int>` over a `Span<double>`
without `unsafe`. Java and safe Rust cannot build the case. Java's batch tier
omits the term; its streaming tier spells it `(Object)a == (Object)b`, which
compiles and is always false. Skipping the pair in C would leave a hole: every
same-typed pair answers `TA_BAD_PARAM`, and the one pair a caller has to cast to
build would answer `TA_SUCCESS` and write through both (SUPERTREND mixes the two
types; #272, #386).

C# detects more than the rule: its guard
`if (outReal.Overlaps(inReal) && outReal != inReal)` rejects a partial
input/output overlap while allowing whole-buffer in place, `Overlaps` rejects a
partial output/output overlap, and its `float` overload rejects any overlap
between a `float` input and a `double` output (#386). Kept because it costs one
call on a type that already answers the question (ruled 2026-10-02), and made
last so that a call with another fault answers the code C and Java give it: in
the batch tier after the same-buffer guard, at an opener after the history
check. The same buffer at an opener is one start address, as C compares it,
and stays ahead of the history check in every language. If uniformity is ever
preferred over the extra safety, removing it is the change, not adding the check
elsewhere.

rW6 is supported, not tolerated: several bodies are written for it and elect
their scratch by testing for exactly that case. That election is why STOCH,
STOCHF and KDJ leave intermediate values past `count` when their first output is
in place (ruled 2026-10-03: accepted). The scratch spans the values the
smoothing consumes and never reaches past `endIdx`, which is the limit the
public rule states.

### rB7: allocation failure

`TA_ALLOC_ERR` is returned, and that is the entire promise. Nothing is tested
past it. The library will not abort on the caller's behalf; that choice is the
caller's. What it will not do is pretend a path it never tests is safe to
continue from. Every `TA_ALLOC_ERR` the library returns is a null check on
`TA_Malloc`; a condition the caller could have avoided is `TA_BAD_PARAM`. In C
the handle out-parameter is still set to NULL on that path, which the public
page does not promise.

### rB8: internal errors

Some batch functions per backend carry a guard, and none is reachable today:
they test a period below 1, which rB3's declared floor already refuses. A stream
opener carries one more for each ring, window, circular buffer and
rolling-extremum span it captures, each checking that span against the history it
was handed, and a dispatching or dual-mode opener one for the arm its own `Open`
has already refused. A composed C `Update` can return one after a sub-stream has
advanced (`TA_APO_StepImpl` steps its first sub-stream before the second can
fail), which is why the public rH5 excludes rB8.

`ta_codegen/input/internal_error_ids.yaml` maps a function-tier id back to the
function and the state field it guards. The Abstract API hand-allocates
ids 1 to 5, most of them shared by several sites (id 2 by 13 in `ta_abstract.c`),
so an id there names a kind of check, not one guard.

### Input domain

It licenses an implementation to be correct only inside the domain, so that a
formulation which is exact for every value a caller may legally pass is not given
up for what it would do near `DBL_MAX`. RSI is the worked example: its gain/loss
split derives the loss delta by subtraction, which is exact for every finite
difference and degenerates to `Inf - Inf` only when two adjacent bars of
opposite sign are each near 9e307, some 270 orders of magnitude outside the
domain. Sizing a change against a value outside the domain is
over-engineering, and this is the citation for saying so.

The bound is not enforced: checking it would cost a pass over every input array
on every call, to reject values no caller sends. The gates exercise its edges:
`FUZZ_DOMAIN_MAX` puts most bars within 9% of +3e37 or -3e37 (volume and open
interest within reach of +3e37), with adjacent bars of opposite sign and
ordinary bars near 100 in the same windows. Every gate that walks the fuzz
shapes runs it, among them the VARIANT gate, whose calls the metadata ride
holds to finite outputs, the cross-language and stream comparisons, and the
frozen-release fuzz. Between 1e9 and the edges the domain rests on the
arithmetic rather than on measurement.
The constant is reused rather than invented: it already bounds a real optional
parameter, and it sits inside `FLT_MAX`, so a value in the domain is
representable in the `TA_S_*` variants. `DBL_MIN` would mislead, being the
smallest normalised *positive* double.

### Finite inputs: no history scan

The warm-up history is an input *array*, and the library does not scan those.
Until the openers' history scan was removed it was the only checked array in the library (every `Open`
and every `OpenAndFill`, in all four backends), which made "arrays are never
scanned" a rule with one exception. What the scan cost, and why folding it into
the fill loop was not the alternative, are in `docs/streaming-api-design.md`. rU3
is untouched: a bar handed to `Update` or `Peek` is a single value.

### Intermediate overflow

Overflow is a property of `double` rather than of any indicator, so it carries
no flag, and issue #191 settled that it gets no semantics.

### Stream opening order

They follow the batch tier's order, but are not the batch conditions read on
`[0, historyLen - 1]`: an empty history answers `TA_INSUFFICIENT_HISTORY`
where `batch(0, -1)` answers `TA_OUT_OF_RANGE_END_INDEX`, and rS5 requires each
input to equal the history's length where rB5 accepts a longer one.

### rS4

The presence checks sit on the public frame, because `<N>_OpenImpl` reads the
history's length before anything else could look at it.

### rS5

The input half is checked first, on the public frame: the core makes the test
too, but only after the capacity bound would have answered, so a short input
series was reported as an output-capacity fault.

The output half is rB5's produced count read over the same range, which collapses
it to `historyLen - lookback`, never the width of the history. It has no
legitimate zero case the way rB5 does: rS7 refuses a history shorter than
`lookback + 1`, so a fill that runs writes at least one value. A short history is
floored to zero so that it reaches rS7; a lookback of `-1` is not floored but
raised, which is what keeps rS3 ahead of the buffer rules, as the batch tier's
`clampedStart` does.

It sits on the **public** frame, never on `<N>_OpenAndFillInternal`: that seam
takes an anchor and writes `historyLen - max(lookback, startIdx)`, fewer, so the
same bound there would reject the composed sub-calls that pass a non-zero anchor.
It would also be redundant: a composed destination is proved disjoint by
`SubCallStep::is_fusable` and sized by construction. The frame reads the count
from the function's own `<N>_Lookback`, whose default substitution and range
validation come with it.

### rS6: no in-place OpenAndFill

Not because in-place would compute the wrong answer: measured, it does not. The
fill's writes stop where the handle's warm-up seeds begin, or overlap them by the
single slot the next `Update` rewrites first. The ban is there because that
margin is an accident of every body's arithmetic that nothing states or asserts,
and supporting in-place would promise it for every function in four backends,
permanently.

### rS7: short history

The warm-up check comes last because it is the one thing the batch tier has no
analogue for. All four converge on `TA_INSUFFICIENT_HISTORY`: across every
streaming function in every backend, each short-history arm reports this code
and no other. What they answered before the code existed is Appendix D item 8.

rS7 is also what a **composed** opener answers when a sub-call succeeds with zero
elements: the batch tier may report that as an empty range, but an opener has no
handle to mint over a range holding nothing. C is outside the sweep that pins it:
no fold pass runs for C, so its transcribed guard still tests both halves and
returns the sub-call's own code. No opener answers `TA_SUCCESS` over zero
elements today, but a composed indicator that made one would hand C's caller
`TA_SUCCESS` and a NULL handle where the other three answer rS7.

### rU4, rH5, rH6: advancing

rU4 is rS2 read one bar at a time: the next bar's index is `begIdx + count`, and
once that leaves `[0, INDEX_MAX]` the handle is being asked for a bar the batch
tier refuses to address, permanently. It is evaluated where the opener
evaluates rS2, ahead of every presence check with only the
handle's own null test in front of it, because it is the same fault read on the same domain,
and a caller who fixed the argument the presence check named would only get rU4
back. `Peek` is exempt for performance; it commits no bar.

A composed step drives its sub-handles through their public `Update`, so each of
them re-reads rU4. It cannot fire there first, and that is load-bearing: every
handle over one history satisfies `begIdx + count == historyLen` at open, an
accepted `Update` moves a parent and its sub-handles together, and `Advance`
moves the parent alone, so the parent is never behind and its own guard answers
before any sub-handle is stepped.

Re-feed or `Advance` is the caller's choice and neither is automatic: the error
is in hand at the moment of decision and `OutRange` is readable, so the drift
doing neither causes is detectable. No backend publishes the held value through
the call's own result: Rust's `Result<f64, RetCode>` cannot carry one beside
`Err`, and a rule three backends could honour and one could not would be worse
than the accessor. `Value` exists because a cloned stream is the one caller with
no earlier call to have handed it a value.

### rT3, rT6: bounds

Both values are added to a lookback which is then used as an index: unbounded,
the lookback overflows negative and the function indexes far past the end of its
input while still reporting success. `INDEX_MAX` is the ceiling the index domain
already enforces, and a warm-up longer than the largest addressable series could
never produce output, so nothing legitimate is refused.

An Auto level is `INDEX_MAX` plus its digit count. Above `INDEX_MAX`, so no
count is a level. Below 2^31, so a Java or C# `int` holds one and a negative C
`int` stays above it and refused. Not `INT_MAX`, which the C regtest server
uses to saturate an oversized integer on the wire. Close to the ceiling, so
that code reading a level as a count gets no output or
`TA_INSUFFICIENT_HISTORY`, never an index out of range. The offsets between
and beside the levels stay refused. A level's lookback fits an `int` at every
parameter's maximum: VIDYA's rule, the one product of two periods, saturates
at `INDEX_MAX`.

### rT12: the getter returns the level

A getter that answered 0, or the resolved count, under a level would turn the
level off, or into a fixed count, in a caller that saves a setting and restores
it. A caller that adds the getter's value to a lookback of its own gets a
number that is plainly wrong, not one that is quietly short. No call returns
the count a level resolves to: it is the lookback under the level minus the
lookback at 0, and it depends on the call's parameters, which a getter does
not take.

### rT7: finite and not negative

A factor scales a threshold (ruled 2026-10-02). NaN silences every comparison it
feeds, which is indistinguishable from "this shape never occurs". An infinity
does the same on flat bars, where it multiplies a zero average into NaN. A
negative threshold is below every range, so a test that a range exceeds it
always passes and its opposite never does. None of the three is a threshold a
caller means, and zero is the edge that is.

---

## Appendix B: How the marks were produced

Each ✅ rests on two independent checks; neither alone is enough.

1. **A runtime probe against the built artifact**: one program per backend,
   driving the scenarios through the *public* API and printing what came back.
   Representative functions: `SMA` (one input, one integer parameter, one
   output), `BBANDS` (three outputs, a real and an enum parameter), `MAMA` (real
   parameters with a narrow domain), `MININDEX` (integer output), `SQRT` (a
   documented output-domain hole). C's memory-unsafe rules are probed with
   guard-paged buffers, so a read or write past a declared length faults instead
   of silently corrupting neighbouring memory, and each such scenario runs in a
   forked child so a crash is an observation rather than the end of the run.

2. **A structural check over the whole generated corpus**: a probe on one
   function says nothing about the rest. Verified mechanically, from the
   generated sources:

   | Claim | Result |
   |---|---|
   | C batch: `startIdx` guard, then `endIdx` guard, before any other return | every function |
   | C batch: parameter validation, then every input, the `OutRange` pointers and every output null-checked, inputs before outputs | every function, both overloads |
   | Rust batch: `startIdx` guard, `endIdx` guard, lookback (which returns rB3), every input, then every output length-checked | every function |
   | Rust numerics: `startIdx` guard, `endIdx` guard, bounds asserts (following the FMA dispatcher to the real core) | every function |
   | Java batch: clamp (which raises rB3), then every length check, then the core | every function, both overloads |
   | C# batch: clamp, then every length check, then the core | every function, both overloads |
   | C# cores carrying an overlap guard wherever one is expressible | no core unguarded where the type expresses it |
   | Short-history arm reports `TA_INSUFFICIENT_HISTORY` | every streaming function, per backend, no backend mixing it with anything else |
   | Anchor guard, which answers an empty history, reports `TA_INSUFFICIENT_HISTORY` | every strided `_OpenImpl` in every backend, no backend mixing it with anything else |
   | Java public opener: the history's null test, then rS2, then every other argument | every `Open` and `OpenAndFill` |
   | C# public opener: rS2 on the history, then every other input; no emptiness check on the history | every `Open` and `OpenAndFill` |
   | Rust/Java/C# public `OpenAndFill`: every output bounded by `historyLen - <N>_Lookback(...)` | every one, per backend |

   The "both overloads" rows are every definition in `ta_codegen/input/` taken
   twice, once per overload, so the float surface rests on the same evidence.

Most of these probes are not committed. They are throwaway drivers: the shipped
gates cover values, and these cover the failure paths once, to produce this
table. Re-running them means rewriting them: cheap, and honest about the fact
that a mark is a statement about a moment. The exceptions are the tests named
under Test coverage: those cover a condition no value gate reaches, so they are
committed and run.

---

## Appendix C: Not yet specified

- **Which code the Abstract API answers for a given misuse**:
  [rA3](https://ta-lib.org/spec/abstract/#ra3) names the set and leaves the choice
  open, so a backend can become more specific. Today all four answer 10 for an
  unbound input, 11 for an unbound output and 8 for a mistyped setter.
- **JSON-RPC servers**: a test harness, not a shipped API. Their error behaviour
  is a property of the harness.

---

## Appendix D: Open items

Every ❌ above, collected, plus message-level deviations and divergences no rule
row can carry: a call two backends answer differently although a rule covers it
(items 11 and 15). Numbering is append-only: a retired item leaves a gap rather
than renumbering the rest. Each was measured, not inferred.

A `⚠️` is not tracked here. It marks a deviation that is deliberate, or a rule
implemented but not covered by a CI probe; the rule's own footnote says which.

| # | Backend | Rule | Defect |
|---|---|---|---|
| ~~1~~ | C | rB4 | *Fixed.* The `OutRange` pointers were not null-checked, so passing either as null segfaulted. The batch prologue now checks them, as the streaming `OpenAndFill` prologue always has. |
| ~~2~~ | C | rB4 | *Fixed.* Input-buffer presence was checked *before* parameter validation and output presence after, so the prologue straddled rB3. Parameter validation now precedes every presence check. |
| ~~3~~ | Java | rB4 | *Fixed.* Buffer presence was checked *before* the index and parameter rules, inverting the specified precedence: a negative `startIdx` with a null input reported the null. The wrapper now evaluates rB1, rB2 and rB3 first. |
| ~~4~~ | Java | rB3 | *Fixed.* A null enum parameter yielded a raw JVM `NullPointerException` naming neither function nor parameter; it is now a parameter outside its domain, named, and carrying `TA_BAD_PARAM`. |
| ~~5~~ | | | *Withdrawn, not fixed.* Partial output/input overlap in C. Decided in #225: detection stops at buffer identity, and partial overlap is the caller's to avoid. |
| ~~6~~ | Java | rS4 | *Fixed.* A null history, or a null `OpenAndFill` output, yielded a raw JVM exception from inside the algorithm. The public openers now check every argument, and item 13 fixed the order they are checked in. |
| ~~7~~ | C# | rS7 | *Fixed.* The empty-history *message* omitted the cross-language `<N> open: ` prefix. Taken with item 13. |
| ~~8~~ | all | rS7 | *Fixed.* `TA_RetCode` had **no member** for "history shorter than the lookback", so C and Rust fell back to the catch-all and Java and C# borrowed `TA_OUT_OF_RANGE_END_INDEX`. `TA_INSUFFICIENT_HISTORY = 17` was appended and all four now report it, which leaves rS2 as the opening tier's only producer of `TA_OUT_OF_RANGE_END_INDEX`. |
| ~~9~~ | Rust, Java, C# | rS5 | *Fixed.* `OpenAndFill` validated no output capacity, so an undersized output faulted inside the fill with the buffer already partly written. The public frame now bounds every output by `historyLen - <N>_Lookback(...)`. (C still cannot: no sizes.) |
| ~~10~~ | C | | *Obsolete.* `TA_SetCompatibility` accepted any value; #388 removed the behaviour it selected, and the pair is kept declared and inert. |
| ~~11~~ | C#, Rust | rB6 | *Fixed.* Two distinct **empty** output buffers were rejected as aliased in C# and Rust and accepted in C and Java, measured on `ACCBANDS(0, 251, …, optInTimePeriod 253, …)` with three distinct zero-length outputs. Both then accepted them (#262). Superseded 2026-10-02: an empty output is absent (rB4), so the call is refused in Rust, Java and C#. |
| ~~13~~ | all | rS7 | *Fixed.* An empty history answered `TA_BAD_PARAM` where the spec gives it a code of its own, and C checked argument presence ahead of the history bounds. Every opener now answers it with rS7's code, after the argument checks, and rS2 ahead of every presence check except the one each language makes a precondition of reading the length (footnote [4]). |
| ~~14~~ | Java | rL2, rL3, rL11 | *Fixed.* A lookback call did not check a null MA type: `maLookback(1, null)` returned 0 and `maLookback(2, null)` threw `NullPointerException` from its `switch`, and every lookback with an MA-type parameter did the same. Each now returns -1, as rB3 rejects the batch call. |
| ~~15~~ | C# | rB6, rS6 | *Fixed.* One zero-length array passed as two outputs, on a range that produces no values, answered `TA_SUCCESS` in C# (`Overlaps` is false for an empty span) and `TA_BAD_PARAM` in C and Java. Ruled 2026-10-01: outputs must be different buffers in every language. C#'s batch and `OpenAndFill` guards now also reject two empty outputs on the same non-null reference. |

Next item: 16.

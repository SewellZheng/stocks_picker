Not satisfied with the C/C++ version? Please check these alternative projects that wrap and enhance TA-Lib:

  * [ta-lib-python](https://github.com/ta-lib/ta-lib-python)
  * [pandas-ta](https://github.com/twopirllc/pandas-ta)

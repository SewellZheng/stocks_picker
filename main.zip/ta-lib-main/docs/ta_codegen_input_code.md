# ta_codegen Input: Code (`<name>.c`) Reference

Each indicator's algorithm lives in `ta_codegen/input/<name>/<name>.c`, written as
**plain, standard C** using the types and macros from `ta_defs.h` — essentially the
same code you would find in `src/ta_func`. The generator parses this C
(parser: `ta_codegen/generator/src/parser/c_source.rs`) and re-emits it for every
backend: C, Rust, Java, .NET.

There is **no bespoke DSL** — write idiomatic C. Metadata (inputs, optional params,
outputs, flags) lives in the companion `<name>.yaml`; see
[ta_codegen_input_yaml.md](ta_codegen_input_yaml.md). The generator adds parameter
validation, single-precision variants, and per-language
naming — so the `.c` file contains only the algorithm.

## File contents

Two C functions, named after the directory (`<name>`) — plus, where a function
needs one, an alternate implementation (see `PRAGMA TA_ALT` below):

```c
int <name>_lookback( /* optional params */ )
{
    return /* first valid output index */;
}

TA_RetCode <name>( int startIdx, int endIdx,
                   const double inReal[], /* optional params */,
                   int *outBegIdx, int *outNBElement, double outReal[] )
{
    /* ... algorithm ... */
    *outBegIdx    = startIdx;
    *outNBElement = outIdx;
    return TA_SUCCESS;
}
```

### Optional: `<name>_display_shift`

A function whose outputs a chart draws ahead of or behind the bar that computed
them also defines:

```c
int <name>_display_shift( /* optional params, in YAML order */, int outputIdx )
{
    return /* bars: > 0 ahead, < 0 behind, 0 at its own bar */;
}
```

`outputIdx` ranges over every output, in signature order. Write only the
calculation: before this body runs the generator rejects the parameters the
lookback rejects and an index that names no output, and answers 0 for an output
without the flag.
Define it exactly when an output carries the `display_shift` flag in the YAML;
the generator refuses either without the other. Every other function gets a
generated query that answers 0. The emitted values are never shifted.

### Complete example — `ta_codegen/input/sma/sma.c`

```c
int sma_lookback(int optInTimePeriod)
{
    return optInTimePeriod - 1;
}

TA_RetCode sma(int startIdx, int endIdx, const double *inReal, int optInTimePeriod,
               int *outBegIdx, int *outNBElement, double *outReal)
{
    double periodTotal, tempReal;
    size_t i, outIdx, trailingIdx, lookbackTotal;

    lookbackTotal = (size_t)(optInTimePeriod - 1);
    if( startIdx < lookbackTotal ) {
        startIdx = lookbackTotal;
    }
    if( startIdx > endIdx ) {
        *outBegIdx = 0;
        *outNBElement = 0;
        return TA_SUCCESS;
    }

    periodTotal = 0.0;
    trailingIdx = startIdx - lookbackTotal;
    i = trailingIdx;
    if( optInTimePeriod > 1 ) {
        while( i < startIdx ) {
            periodTotal += (double)(inReal[i]);
            i = i + 1;
        }
    }

    outIdx = 0;
    while( i <= endIdx ) {
        periodTotal += (double)(inReal[i]);
        i = i + 1;
        tempReal = periodTotal;
        periodTotal -= (double)(inReal[trailingIdx]);
        trailingIdx = trailingIdx + 1;
        outReal[outIdx] = tempReal / (double)optInTimePeriod;
        outIdx = outIdx + 1;
    }

    *outNBElement = outIdx;
    *outBegIdx    = startIdx;
    return TA_SUCCESS;
}
```

Array parameters may be written either `const double inReal[]` (the common style) or
`const double *inReal` — both parse identically.

## Types

| Type | Use |
|------|-----|
| `TA_RetCode` | main function return type |
| `double`, `const double inReal[]`, `double outReal[]` | price inputs and outputs |
| `int` | optional params, counters, `int *outBegIdx` / `int *outNBElement` |
| `size_t` | array indices and counts. Only Rust renders it unsigned (`usize`); C, Java and C# render `int`, so a `size_t` cast or declaration never widens arithmetic or guards an overflow |

Outputs are written through their pointer/array parameters: `*outBegIdx = ...`,
`*outNBElement = ...`, `outReal[outIdx] = ...`.

Return values are the real `ta_defs.h` codes: `TA_SUCCESS`, `TA_BAD_PARAM`,
`TA_ALLOC_ERR`. The generator maps these to each language's enum
(`RetCode::Success` in Rust and C#, `RetCode.SUCCESS` in Java).

## Control flow & expressions

Standard C: `if` / `else if` / `else`, `while`, `for`, `switch` / `case`; the
arithmetic (`+ - * /`), comparison (`< <= > >= == !=`), and boolean (`&& || !`)
operators; C-style casts (`(double)x`, `(size_t)(n - 1)`); and array indexing. Follow
the bracing/spacing style of the existing input files.

## Branches in a bar loop

A branch on the data, such as the sign of a change or an exact zero, mispredicts
on real prices whichever way it is laid out, and whether a ternary stays a select
is each compiler's call: gcc 13, gcc 14 and Java's x86 JIT each turn some back
into branches, a select of two constants included. Write such a choice as
arithmetic, which none of them can:

- `max(d, 0)` as `(d + fabs(d)) * 0.5`, and the other side as the remainder
  (`cmou.c`). Not `fmax`, which gcc calls in libm.
- a run of exact zeros as a masked counter:
  `live = fabs(v) <= 0.0 ? 0 : 1; run = (run + 1) & (live - 1);` (`cmf.c`).

The `fabs` form adds `+0.0` where the branch added nothing, which is exact only
into a sum that is never `-0.0`: check that before relying on it.

A max that includes an absolute value, such as a true range, is never negative
on finite input, so it goes into the masked counter as itself: through `fabs`,
gcc 13 turns that max back into a branch (`ultosc.c`).

The exception is a pick of a value against `0.0` on a strict comparison
(`x = a < b ? 0.0 : v`): C with gcc on x86 and C# lower it to a branch-free
mask, which arithmetic would lose (`mfi.c`). It needs side-effect-free operands,
a plain variable or literal `v`, and an `x` not carried to the next bar; anything
else may silently stay a ternary.

A case that is rare by construction, such as a window flat for a whole period, is
one `TA_UNLIKELY` branch. When the bar's output is written right after it, write
the dead bar's output inside the branch and the normal one in its `else`
(`cmou.c`, `er.c`): a branch that only zeroes locals can still become a select on
every bar's running sums.

Work that only prepares the next bar, such as dropping the change that leaves the
window, goes after the bar's output: a peek keeps nothing past its last output
store, so it skips that work (`cmou.c`).

## Rescan loops: write the window start INLINE

A body that rebuilds a window sum -- the periodic re-anchor `TA_VAR`,
`TA_CORREL`, `TA_BETA`, the `TA_LINEARREG` family, `TA_WMA` and `TA_HMA` all
carry -- must name the window start **in the loop init**, not through a local:

```c
/* YES -- recognised as a rescan window */
for( j = today - lookbackTotal; j <= today; j++ )
   periodTotal += inReal[j];

/* NO -- reads well, and is not recognised */
windowStart = today - lookbackTotal;
for( j = windowStart; j <= today; j++ )
   periodTotal += inReal[j];
```

`streaming.rs`'s `match_cursor_anchored_loop` matches `for( v = <cursor> - E;
v <= <cursor>; v++ )` and nothing else, and that match is what puts the rescan on
the stream classifier's primary path. The named form is not recognised as a
window at all: its index bookkeeping reads a non-index symbol, the classifier
retries in absolute-index (extrema) mode, and the loop is lowered through a
synthesised mask ring instead.

**Both spellings work for most functions, which is exactly the problem.** The
extrema fallback is refused when the body also owns a CIRCBUF, a counter, or
another window -- so a body that streams today stops streaming the moment one is
added, and the refusal names the ring rather than the spelling that caused it.
`TA_HMA` is the live instance: it keeps a CIRCBUF for its de-lagged series, so
its three fused WMA stages could only be given a re-anchor once their rescans
were written inline.

The refusal message now says this, and names the cursor for you. If you see
`extrema automaton mixed with other buffer forms`, check the loop init first.

One case cannot be written inline, and is the reason this is a convention rather
than a check: `TA_VAR` reads `inReal[windowStart]` later in the same loop, so the
local is load-bearing there and the function keeps the extrema path deliberately.

## `ta_defs.h` vocabulary

Beyond plain C, the input files use a small set of TA-Lib macros/functions that the
generator recognizes and maps per language:

| Construct | Meaning |
|---|---|
| `TA_IS_ZERO(x)` / `TA_IS_ZERO_OR_NEG(x)` | epsilon comparison against zero |
| `if( TA_UNLIKELY(c) )` | `c`, marked rarely true, as the whole condition of an `if` in a loop: C lays the guarded block out of line, Rust opens it with a call to a cold function, and Java, C# and every peek frame render `c`. See [Branches in a bar loop](#branches-in-a-bar-loop) |
| `TA_UNSTABLE( TA_FUNC_UNST_<NAME>, <count> )` | this function's unstable period: the stored count, or under an Auto level `<count>`, written with the free names `K` and `X` that each level supplies. Only in the owner's lookback, once per path |
| `TA_UNSTABLE_AUTO( TA_FUNC_UNST_<ID>, <offset> )` | `<offset>`, written from the function's parameters, `K`, `X` and constants only, while `<ID>` is on an Auto level, and 0 while it holds a count. For an id the function inherits: only in a lookback that calls that owner's lookback. The body must take its lookback from its own lookback function, or its first output and the lookback disagree |
| candle-settings access (CDL* patterns) | resolved via the generated candle helpers |
| `TA_OPAQUE(a, b, …);` | statement: the listed locals keep their values, but Rust's optimizer may not see through them there (`core::hint::black_box`; every other language emits nothing). Place it after each loop whose float accumulators LLVM would otherwise carry packed in one vector register through a later loop; see `cti.c` |
| `CIRCBUF_PROLOG_CLASS` / `CIRCBUF_INIT_CLASS` / `CIRCBUF_NEXT` / `CIRCBUF_DESTROY` | circular scratch buffer over a local `typedef struct` element type (`src/ta_common/ta_memory.h`); see `cmf.c` or `ultosc.c` for usage |

Standard math functions (`sqrt`, `floor`, `ceil`, `fabs`, `sin`, `cos`, `atan`,
`atan2`, `log`, `exp`, `pow`, `fmod`, …) are mapped to each language's math library.

## An unstable id and its Auto rule

A function that owns `TA_FUNC_UNST_<NAME>` reads it once, in its own lookback, and the
read's second argument is the id's rule. Finding, sizing, writing and recording that rule
is [`auto-stabilization-rule.md`](auto-stabilization-rule.md).

## Cross-indicator calls

Call another indicator by its **bare lowercase name** (matching its directory) — the
generator resolves it to the correct symbol per language. From
`ta_codegen/input/ma/ma.c`:

```c
retCode = sma( startIdx, endIdx, inReal, optInTimePeriod, outBegIdx, outNBElement, outReal );
```

maps to `TA_SMA(...)` in C and to the public entry point each other backend
folds that name to (`sma(...)` in Rust and Java, `Sma(...)` in C#; see
`docs/naming-spec.md`), which is what C has always done (#236 step 3, #267). Its
rejection surfaces as a throw in Java and C# and as an `Err(RetCode)` in Rust.
`sma_lookback(...)` maps the same way: `TA_SMA_Lookback(...)` in C,
`self.sma_lookback(...)` in Rust, `smaLookback(...)` in Java, `SmaLookback(...)`
in C#.

## What the generator adds (do NOT write these)

- Parameter validation (NULL checks, range checks, `INTEGER_DEFAULT` substitution)
- Single-precision (`TA_S_*`) variants — generated automatically with `(double)` casts
  on inputs
- Per-language function signatures/naming, doc comments, file headers, imports

## Alternate implementations — `PRAGMA TA_ALT`

Alongside `<name>`, a file may declare `<name>_ALT1`, `<name>_ALT2`, … — whole
alternative bodies for the same function, each under one or more **single-line**
decorations:

```c
/* PRAGMA TA_ALT={<api>,<lang>} free text after the brace is ignored */
TA_RetCode <name>_ALT<n>( /* the same parameters as <name> */ )

<api>  ::= BATCH | STREAM | ALL_API
<lang> ::= C | RUST | JAVA | CSHARP | ALL_LANGUAGES
```

An alternate claims the union of its decorations, so `{ALL_API,JAVA}` plus
`{ALL_API,CSHARP}` is one body for both managed languages; their order decides
nothing. **Later declarations override earlier ones for every cell they claim**,
with the base as the implicit first entry claiming `{ALL_API,ALL_LANGUAGES}` — so
"everyone but C" is `ALL_LANGUAGES` followed by `C`, and there is no specificity
table to learn. An alternate that ends up winning no cell is a hard error, as is a
decoration that decides none (a duplicate, one its alternate's other decorations
already cover, or one a later alternate overrides), a second claim on one line, a
claim with no `=`, an unrecognized directive name, a `PRAGMA TA_ALT` on the base,
an `_ALT<n>` with no decoration, numbering that is not ascending and contiguous
from 1 in file order, and a signature that differs from the base's.

An alternate must be **strictly functionally identical** to the base (some may
differ within `TA_STABLE_EPSILON`; none may compute something else), and the
accepted reason to carry one is a significant performance gain — a second copy of
an algorithm is a maintenance cost. There is no alternate lookback: one
`<name>_lookback` serves every cell.

A language-scoped claim answers to `--xlang-hash`, which holds every language
server bit-identical to the in-process C library (Java and C# to a relative 1e-9
on calls that reach a transcendental), with C as the golden. So a `{...,C}`
alternate that is not bit-identical to the others moves the reference and fails
Rust, and Java and C# beyond that tolerance. That is a loud failure, not a silent
one, but it is the gate such a change has to answer for.

`_ALT<n>` is **generator input only and never becomes a symbol**. There is still
one `TA_MIN`, one `TA_MIN_Open`; the claim decides only which body the generator
transcribes into them. Calling `min(...)` from another indicator resolves exactly
as it always did, and naming `min_ALT1` in a call is an error. Where an alternate
wins, the generated file says so: `/* Using min_ALT1 for TA_ALT={STREAM,ALL_LANGUAGES} */`.

`PRAGMA` is the general mechanism, not a `TA_ALT` mechanism: any comment whose
first word is `PRAGMA` addresses the generator and is stripped from every backend's
output, several may precede one signature, and an unrecognized name **without** an
`=` is free-form prose the generator ignores.

## Opting out of an optimization — `PRAGMA TA_OPT_OUT`

```c
/* PRAGMA TA_OPT_OUT=RANGE_TYPE_COPY timed slower with it: ... */
TA_RetCode cdlunique3river(int startIdx, int endIdx, ...
```

Above the shipped function's signature, it turns off one generator optimization
for this function. The `OptOut` enum in `ta_codegen/generator/src/ir.rs` is the
complete list of what can be turned off; `git grep 'PRAGMA TA_OPT_OUT'
ta_codegen/input` lists every function that does. There is no opt-in: an
optimization that pays only for a named set of functions is not general enough
to ship. Give the measured reason after the value, and keep the list short.

## What the logic file is NOT

- Not a macro template — no `#include`, no preprocessor `#if defined(_RUST)`, no
  `GENCODE` markers
- Not language-specific in the small — the same `.c` file produces all four target
  languages. A *whole* alternative algorithm may be selected per language (see
  `PRAGMA TA_ALT` above): self-contained, co-located, skippable in one read.
  Scattering per-language conditionals through a single body is still forbidden.

#!/bin/sh
autoreconf -fi

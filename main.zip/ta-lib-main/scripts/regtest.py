#!/usr/bin/env python3
"""One-command regression testing and benchmarking.

Build control:
  --no-build                 Skip cmake (ta_regtest, ta_bench)
  --no-generate              Skip indicator AND server regeneration
  --no-generate-indicators   Skip indicator regeneration only
  --no-generate-servers      Skip server regeneration only

Test control:
  --no-regtest               Skip correctness verification
  --no-perftest              Skip performance benchmark
  --no-test                  Skip both regtest and perftest
  --test-only                Skip all build/generate, just run tests
  --direct-bench-only        Skip build/generate/regtest/perftest, just run direct bench

Filters (applied to generate AND test):
  --language=c,rust          Filter languages
  --function=SMA,RSI         Filter indicators

Perftest options:
  --points=5000              Data points (default 5000)
  --iters=20                 Iterations (default 20)
  --shape=trend-chop-1p      Benchmark input class (default randwalk;
                             ta_bench --list-shapes prints them)
  --seed=42                  Corpus seed (default 42)
  --regime-period=30         Reference window for the trend/chop regime length
  --trend-strength=0.5       Trend-leg drift, in per-bar standard deviations

Examples:
  scripts/regtest.py                                             # full pipeline
  scripts/regtest.py --no-build --function=SMA                   # regen SMA + test
  scripts/regtest.py --no-build --no-generate-servers --function=SMA
                                                                 # regen SMA indicator + test
  scripts/regtest.py --no-regtest --language=c --function=STOCH  # build + perftest only
  scripts/regtest.py --test-only --no-regtest --function=STOCH   # just perftest, no build
  scripts/regtest.py --test-only --no-regtest --function=WILLR --shape=trend-chop-1p
                                                                 # perftest on trending input
"""

import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utilities.common import (
    check_prerequisites, prereqs_for_languages, backends_for_languages,
)
import serve_version

OUR_FLAGS = {
    "--no-build", "--no-generate", "--no-generate-indicators", "--no-generate-servers",
    "--no-regtest", "--no-perftest", "--no-test", "--no-direct-bench",
    "--test-only", "--direct-bench-only", "--rust-debug",
}


def find_repo_root():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        check=True, capture_output=True, text=True, cwd=script_dir,
    )
    return result.stdout.strip()


def get_filter(args, prefix):
    for a in args:
        if a.startswith(prefix + "="):
            return a.split("=", 1)[1]
    return None


# LANG_PREREQS / prereqs_for_languages moved to utilities/common.py so that
# scripts/build.py enforces the same rule — a machine that can reach
# `--language=c,rust` here must be able to reach it there too (issue #150).


# Reference-as-server: the reference C library is frozen at this immutable tag
# and checked out in a sibling git worktree, so ta_ref_serve stays a true oracle
# now that src/ta_func holds the generated code (comparing against an in-process
# baseline built from the same tree would be circular).
REF_TAG = "reference-pre-cutover"


def _ta_ref_serve_paths(src_root, build_dir):
    """(serve_src, lib_a, include_dirs) for building ta_ref_serve from a given
    checkout (src_root) whose static lib lives in build_dir."""
    c_out = os.path.join(src_root, "ta_codegen", "output", "c")
    c_tools = os.path.join(c_out, "tools")
    return (
        os.path.join(c_tools, "ta_codegen_serve.c"),
        os.path.join(build_dir, "libta-lib.a"),
        [
            c_tools,
            os.path.join(src_root, "include"),
            os.path.join(c_out, "ta_common"),
            os.path.join(c_out, "ta_abstract"),
            os.path.join(c_out, "ta_abstract", "frames"),
            # ta_def_ui.h does `#include "ta_frame.h"` (frames/) and pulls in
            # ta_abstract_serve.c, which lives under ta_codegen/generator/templates/c.
            os.path.join(src_root, "ta_codegen", "generator", "templates", "c"),
            # Current-tree layout: ta_memory.h / ta_utility.h live with the
            # library sources, not under ta_codegen/output/c, and the server
            # includes "ta_func/ta_func_stream_private.h" relative to src/.
            os.path.join(src_root, "src", "ta_common"),
            os.path.join(src_root, "src", "ta_func"),
            os.path.join(src_root, "src"),
            os.path.join(src_root, "src", "ta_abstract"),
            os.path.join(src_root, "src", "ta_abstract", "frames"),
        ],
    )


def _compile_ta_ref_serve(serve_src, lib_a, include_dirs, bin_dir, post_funcs=()):
    """Turn the generated C server source into the reference server: strip the
    generated indicator + ta_common .c includes (libta-lib.a provides those),
    add the reference headers + TA_Initialize, and link against lib_a. Returns
    the cc exit code.

    `post_funcs` are functions the current tree has but the frozen reference lib
    does not (see serve_version): they are dropped from list_functions and their
    symbols aliased to a stub so this current-transport serve links against the
    frozen library. See serve_version for the rationale."""
    import re
    with open(serve_src) as f:
        src_text = f.read()
    # VALUES only. ta_func/ and ta_common/ come from the frozen lib_a, but
    # ta_abstract_all.c / ta_func_api.c are NOT stripped and resolve against the
    # CURRENT src/ta_abstract via -I, so this serve's metadata answers are the
    # generator compared against itself. Never build a metadata gate on it (#161).
    src_text = re.sub(r'#include "ta_func/[^"]*\.c"\n', '', src_text)
    src_text = re.sub(r'#include "ta_common/[^"]*\.c"\n', '', src_text)
    src_text = src_text.replace(
        '#include <stdio.h>',
        '#include <stdio.h>\n'
        '#include "ta_func.h"\n'
        '#include "ta_memory.h"\n'
        '#include "ta_utility.h"\n'
    )
    if post_funcs:
        src_text = serve_version.filter_list_functions(src_text, post_funcs)
        stubs = serve_version.stub_definitions(post_funcs,
                                               serve_version.header_path(include_dirs))
        src_text = src_text.replace('int main(void) {', stubs + 'int main(void) {', 1)
    src_text = src_text.replace(
        'int main(void) {',
        'int main(void) { TA_Initialize(); TA_RestoreCandleDefaultSettings(TA_AllCandleSettings);'
    )
    tmp_ref = os.path.join(bin_dir, "_ta_ref_serve.c")
    with open(tmp_ref, "w") as f:
        f.write(src_text)
    cmd = ["cc", "-O3", "-flto", "-DNDEBUG", "-DTA_REF_SERVE", "-Wno-everything",
           serve_version.FP_CONTRACT_FLAG]
    cmd += [f"-I{d}" for d in include_dirs]
    cmd += ["-o", os.path.join(bin_dir, "ta_ref_serve"), tmp_ref, lib_a, "-lm"]
    rc = subprocess.run(cmd).returncode
    os.unlink(tmp_ref)
    return rc


def ensure_reference_serve(root, bin_dir):
    """Build bin/ta_ref_serve, the frozen reference oracle for ta_regtest's
    cross-language codegen verification (canonical cutover task #7).

    Builds from the pinned-tag worktree (../ta-lib-ref @ REF_TAG), so the
    oracle is independent of this tree. The tag is immutable, so the reference
    lib + server are built once and reused.

    If the tag is unavailable the script ABORTS: post-cutover there is no
    valid substitute — building the "reference" from the current tree would
    compare the generated code against itself."""
    print("=== Building ta_ref_serve (frozen reference oracle) ===")
    ref_root = os.path.join(os.path.dirname(root), "ta-lib-ref")
    ref_build = os.path.join(ref_root, "cmake-build")
    bin_serve = os.path.join(bin_dir, "ta_ref_serve")

    tag_ok = subprocess.run(
        ["git", "rev-parse", "--verify", "--quiet", f"refs/tags/{REF_TAG}"],
        cwd=root, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    ).returncode == 0

    # Create the worktree once, from the tag.
    if tag_ok and not os.path.isdir(ref_root):
        print(f"  Creating reference worktree {ref_root} @ {REF_TAG}")
        subprocess.run(["git", "worktree", "add", ref_root, REF_TAG],
                       check=True, cwd=root)

    if tag_ok and os.path.isdir(ref_root):
        # Transport (server source + headers) comes from the CURRENT tree so the
        # JSON-RPC protocol never drifts from what ta_regtest speaks (e.g. the
        # use_float leg); the ORACLE property lives in lib_a, which stays the
        # frozen pinned-tag build. The two trees' public C API declarations are
        # identical (audited), so current headers link cleanly against the
        # frozen library.
        serve_src, _lib_ignored, includes = _ta_ref_serve_paths(root, os.path.join(root, "cmake-build"))
        # Build the frozen reference static lib (the tag is immutable, but the
        # FP-contraction setting must match this tree's — see build_frozen_lib).
        lib_a = serve_version.build_frozen_lib(ref_root, ref_build, "ta_ref_serve")
        if not os.path.exists(serve_src):
            print(f"  ta_ref_serve: FAILED — {serve_src} missing in worktree")
            return
        # Rebuild if missing, or older than the frozen lib OR the current
        # transport source (the server template evolves with the protocol).
        if (os.path.exists(bin_serve)
                and os.path.getmtime(bin_serve) >= os.path.getmtime(lib_a)
                and os.path.getmtime(bin_serve) >= os.path.getmtime(serve_src)):
            print("  ta_ref_serve: up to date (frozen reference unchanged)")
            return
        # Functions added since the pinned tag are absent from the frozen lib;
        # drop them from list_functions + stub their symbols so the current
        # transport links (the codegen sweep's subset gate skips them).
        post_funcs = serve_version.post_version_funcs(root, ref_root)
        if post_funcs:
            print(f"  post-reference functions (skipped by the subset gate): {', '.join(post_funcs)}")
        # Self-heal a stale transport: a post-reference function with no
        # list_functions entry means `generate` ran without `generate-servers`
        # (a brand-new function's first regtest.py run). Regenerate the server
        # sources here rather than letting filter_list_functions assert; if an
        # entry is still missing after regeneration, that assert still fires.
        with open(serve_src) as f:
            serve_text = f.read()
        stale = [n for n in post_funcs if ('\\"TA_%s\\"' % n) not in serve_text]
        if stale:
            print(f"  transport stale (no list_functions entry for: {', '.join(stale)}) — regenerating server sources")
            subprocess.run(["cargo", "run", "--release", "--", "generate-servers"],
                           check=True, cwd=os.path.join(root, "ta_codegen", "generator"))
        rc = _compile_ta_ref_serve(serve_src, lib_a, includes, bin_dir, post_funcs)
        print("  ta_ref_serve:",
              "OK (from pinned-tag worktree)" if rc == 0 else f"FAILED (exit {rc})")
        if rc != 0:
            sys.exit(1)
        return

    # --- No tag: fail loudly. Post-cutover, building the "reference" from the
    # CURRENT tree is circular (the generated code would be compared against
    # itself) and its include layout no longer matches — CI must fetch the
    # pinned tag (actions/checkout fetch-depth: 0 + the tag pushed upstream).
    print(f"  ERROR: tag '{REF_TAG}' unavailable — cannot build the frozen")
    print(f"  ERROR: reference oracle. Fetch tags (git fetch --tags) or push")
    print(f"  ERROR: the tag upstream. Aborting: codegen verification without")
    print(f"  ERROR: the reference oracle would silently self-compare.")
    sys.exit(1)


def main():
    if "--help" in sys.argv or "-h" in sys.argv:
        print(__doc__.strip())
        sys.exit(0)

    argv = sys.argv[1:]
    test_only      = "--test-only" in argv
    direct_only    = "--direct-bench-only" in argv
    no_build       = "--no-build" in argv or test_only or direct_only
    no_gen         = "--no-generate" in argv or test_only or direct_only
    no_gen_ind     = "--no-generate-indicators" in argv or no_gen
    no_gen_srv     = "--no-generate-servers" in argv or no_gen
    no_test        = "--no-test" in argv
    no_regtest     = "--no-regtest" in argv or no_test or direct_only
    no_perftest    = "--no-perftest" in argv or no_test or direct_only
    # Build the Rust server with the debug profile (overflow checks on) so the
    # codegen run traps the IMI/APO/PPO-class arithmetic overflow that a release
    # build wraps away. CI runs this as a Rust-only gate.
    rust_debug     = "--rust-debug" in argv

    # Alias --indicator(s) and --functions to --function
    def normalize_flag(a):
        for prefix in ("--indicators=", "--indicator=", "--functions="):
            if a.startswith(prefix):
                return "--function=" + a.split("=", 1)[1]
        return a
    passthrough = [normalize_flag(a) for a in argv if a not in OUR_FLAGS]

    # Reject unknown argv up front. The downstream steps filter `passthrough`
    # by allowlist before handing it to ta_regtest / ta_bench / ta_bench_direct,
    # because those binaries reject argv they do not recognise. Filtering alone
    # would turn a typo into a SILENT default -- `--shpae=constant` would exit 0
    # having benchmarked randwalk -- which is exactly the failure mode the
    # binaries were made strict to prevent. So validate here, once, loudly.
    KNOWN_PASSTHROUGH = (
        "--function=", "--language=", "--points=", "--iters=", "--period=",
        "--shape=", "--seed=", "--regime-period=", "--trend-strength=",
        "--codegen=",
        "--fuzz-064", "--xlang-hash", "--no-guarded",
    )
    # --codegen is EXACT, not a prefix: a bare `startswith("--codegen")` accepts
    # any `--codegen<anything>` and forwards the typo to ta_regtest, which is a
    # louder failure than it needs to be and a quieter one than it looks.
    EXACT_PASSTHROUGH = ("-p", "--codegen")
    unknown = [a for a in passthrough
               if a not in EXACT_PASSTHROUGH and not a.startswith(KNOWN_PASSTHROUGH)]
    if unknown:
        print("regtest.py: unknown option(s): " + " ".join(unknown))
        print(__doc__)
        sys.exit(2)

    func_filter = get_filter(passthrough, "--function")
    lang_filter = get_filter(passthrough, "--language")

    # Must follow --language parsing: the prerequisite set depends on it.
    # The ta_codegen `--backend=` value for this run. Derived from --language,
    # but only real backend names survive: ta_bench also accepts "cref" (a frozen
    # prebuilt binary that is never generated or built here), and forwarding that
    # verbatim made the generator hard-error on an otherwise valid invocation.
    backend_filter = backends_for_languages(lang_filter)
    # Derived from the RESOLVED backend list, not the raw filter, so the tools we
    # demand always match the backends we go on to build. `--language=cref` names
    # no backend, so it resolves to None = "build everything" — and then the full
    # toolchain is required rather than a short list followed by a Java compile.
    check_prerequisites(prereqs_for_languages(backend_filter))

    root = find_repo_root()
    build_dir = os.path.join(root, "cmake-build")
    bin_dir = os.path.join(root, "bin")
    codegen_dir = os.path.join(root, "ta_codegen", "generator")
    jobs = str(os.cpu_count() or 4)

    # 1. cmake
    if not no_build:
        os.makedirs(build_dir, exist_ok=True)
        # BUILD_BENCHMARKS is OFF by default (developer-only), and steps 6/7 run
        # the benches. Reconfigure when it is missing OR cached OFF — an existing
        # cmake-build/ from a plain `cmake ..` would otherwise have no ta_bench
        # target and fail the build below.
        cache = os.path.join(build_dir, "CMakeCache.txt")
        needs_cmake = not os.path.exists(cache)
        if not needs_cmake:
            with open(cache, encoding="utf-8", errors="replace") as fh:
                needs_cmake = "BUILD_BENCHMARKS:BOOL=ON" not in fh.read()
        if needs_cmake:
            subprocess.run(["cmake", root, "-DCMAKE_BUILD_TYPE=Release",
                            "-DBUILD_BENCHMARKS=ON"],
                           check=True, cwd=build_dir)
        print("=== Building ta_regtest + ta_bench ===")
        subprocess.run(["cmake", "--build", ".", "--target",
                        "ensure_ta_regtest_in_bin", "ta_bench", "ta_bench_direct",
                        "-j", jobs],
                       check=True, cwd=build_dir)
        for name in ("ta_bench", "ta_bench_direct"):
            src = os.path.join(build_dir, "bin", name)
            dst = os.path.join(bin_dir, name)
            if os.path.exists(src):
                try:
                    shutil.copy2(src, dst)
                except OSError:
                    if os.path.exists(dst):
                        os.remove(dst)
                    shutil.copy2(src, dst)

        # Build ta_ref_serve from the FROZEN pinned-tag reference worktree
        # (canonical cutover task #7, reference-as-server). See ensure_reference_serve.
        ensure_reference_serve(root, bin_dir)

    # 2. generate indicators
    if not no_gen_ind:
        print("\n=== Regenerating indicator files ===")
        cmd = ["cargo", "run", "--release", "--", "generate"]
        if backend_filter:
            cmd.append(f"--backend={backend_filter}")
        if func_filter:
            cmd.append(f"--function={func_filter}")
        subprocess.run(cmd, check=True, cwd=codegen_dir)

    # 3a. generate servers
    if not no_gen_srv:
        print("\n=== Regenerating server files ===")
        cmd = ["cargo", "run", "--release", "--", "generate-servers"]
        if backend_filter:
            cmd.append(f"--backend={backend_filter}")
        subprocess.run(cmd, check=True, cwd=codegen_dir)

    # 3b. generate bench binary source
    if not no_gen_srv:
        print("\n=== Regenerating bench binary ===")
        cmd = ["cargo", "run", "--release", "--", "generate-bench", "--backend=c"]
        subprocess.run(cmd, check=True, cwd=codegen_dir)

    # 4. compile servers (only if something was regenerated)
    did_generate = not no_gen_ind or not no_gen_srv
    if did_generate:
        print("\n=== Compiling servers ===")
        cmd = ["cargo", "run", "--release", "--", "build"]
        if backend_filter:
            cmd.append(f"--backend={backend_filter}")
        subprocess.run(cmd, check=True, cwd=codegen_dir)

        # Debug-profile Rust server: rebuild just the Rust server bin without
        # --release (overflow checks on) and install it over the release one, so
        # the codegen run below crashes on an arithmetic overflow instead of
        # wrapping it away. See run_edge_range_sweep in test_codegen.c.
        if rust_debug:
            print("\n=== Rebuilding Rust server (debug profile) ===")
            rust_dir = os.path.join(root, "ta_codegen", "output", "rust")
            subprocess.run(["cargo", "build", "--bin", "ta_codegen_serve"],
                           check=True, cwd=rust_dir)
            shutil.copy2(
                os.path.join(rust_dir, "target", "debug", "ta_codegen_serve"),
                os.path.join(bin_dir, "ta_codegen_serve_rust"),
            )

    # 5. regtest — ONE invocation. --codegen runs the C reference tests and the
    #    cross-language verification in the same process, which is what lets
    #    server_verify ride the hand-written tests (it is gated on them running).
    rc = 0
    if not no_regtest:
        print("\n" + "=" * 60)
        print("REGTEST — C reference tests + cross-language codegen verification")
        print("=" * 60)
        # Allowlist, not passthrough: ta_regtest exits with BAD_USER_PARAM on any
        # argv it does not know (ta_regtest.c, the trailing else of the option
        # chain). Forwarding the perftest/bench-only flags — --points=, --iters=
        # and the corpus selectors — aborted this step before the bench in step
        # 6/7 ever ran. An allowlist keeps a future bench flag from breaking it.
        REGTEST_FLAGS = ("--function=", "--language=", "--codegen", "--codegen=",
                         "--fuzz-064", "--xlang-hash", "--no-guarded", "-p")
        codegen_args = [a for a in passthrough
                        if a == "-p" or a.startswith(tuple(
                            f for f in REGTEST_FLAGS if f != "-p"))]
        if not any(a.startswith("--codegen") for a in codegen_args):
            codegen_args = ["--codegen"] + codegen_args
        rc = subprocess.run(
            [os.path.join(bin_dir, "ta_regtest")] + codegen_args,
            cwd=bin_dir,
        ).returncode
        if rc != 0:
            print(f"\nRegtest FAILED (exit {rc})")
            sys.exit(rc)

    # 6. perftest
    if not no_perftest:
        print("\n" + "=" * 60)
        print("PERFTEST — performance (large dataset, averaged)")
        print("=" * 60, flush=True)
        # Allowlist for the same reason as step 5b: ta_bench now rejects unknown
        # argv instead of ignoring it, so flags only ta_regtest knows (--codegen,
        # --xlang-hash, ...) must not reach it.
        BENCH_FLAGS = ("--points=", "--iters=", "--language=", "--function=",
                       "--period=", "--shape=", "--seed=", "--regime-period=",
                       "--trend-strength=")
        # Always include cref for comparison, even when --language= filters
        bench_args = [a for a in passthrough if a.startswith(BENCH_FLAGS)]
        if lang_filter and "cref" not in lang_filter:
            for i, a in enumerate(bench_args):
                if a.startswith("--language="):
                    bench_args[i] = a + ",cref"
                    break
        bench_rc = subprocess.run(
            [os.path.join(bin_dir, "ta_bench")] + bench_args,
            cwd=bin_dir,
        ).returncode
        if bench_rc != 0 and rc == 0:
            rc = bench_rc

    # 7. direct bench (in-process libta-lib.a vs the single-TU ta_bench_cg)
    # Runs unless --no-test; independent of --no-perftest
    if (not no_test or direct_only) and "--no-direct-bench" not in argv:
        bench_direct = os.path.join(bin_dir, "ta_bench_direct")
        bench_cg = os.path.join(bin_dir, "ta_bench_cg")
        missing = []
        if not os.path.exists(bench_direct):
            missing.append("ta_bench_direct")
        if not os.path.exists(bench_cg):
            missing.append("ta_bench_cg")
        if missing:
            print(f"\n  Skipping direct bench (missing: {', '.join(missing)})")
            print("  Run without --direct-bench-only to build them first.")
        else:
            print("\n" + "=" * 60)
            print("DIRECT BENCH — libta-lib.a vs ta_bench_cg (different builds)")
            print("=" * 60, flush=True)
            direct_args = [a for a in passthrough
                           if a.startswith("--function=")
                           or a.startswith("--iters=")
                           or a.startswith("--points=")
                           or a.startswith("--shape=")
                           or a.startswith("--seed=")
                           or a.startswith("--regime-period=")
                           or a.startswith("--trend-strength=")]
            direct_rc = subprocess.run(
                [bench_direct] + direct_args, cwd=bin_dir,
            ).returncode
            if direct_rc != 0 and rc == 0:
                rc = direct_rc

    sys.exit(rc)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""One-command regression testing and benchmarking.

Build control:
  --no-build                 Skip cmake (ta_regtest, ta_bench)
  --no-generate              Skip indicator AND server regeneration
  --no-generate-indicators   Skip indicator regeneration only
  --no-generate-servers      Skip the separate server/bench regeneration step. An
                             unfiltered indicator regeneration writes those too, so
                             pair it with --no-generate-indicators or --function=

Test control:
  --no-regtest               Skip correctness verification
  --no-perftest              Skip performance benchmark
  --no-test                  Skip both regtest and perftest
  --test-only                Skip all build/generate, just run tests
  --direct-bench-only        Skip build/generate/regtest/perftest, just run direct bench

Filters (applied to generate AND test):
  --language=c,rust          Filter languages
  --function=SMA,RSI         Filter indicators

Perftest options:
  --points=5000              Data points (default 5000)
  --iters=20                 Iterations (default 20)
  --shape=trend-chop-1p      Benchmark input class (default randwalk;
                             ta_bench --list-shapes prints them)
  --seed=42                  Corpus seed (default 42)
  --regime-period=30         Reference window for the trend/chop regime length
  --trend-strength=0.5       Trend-leg drift, in per-bar standard deviations

Examples:
  scripts/regtest.py                                             # full pipeline
  scripts/regtest.py --no-build --function=SMA                   # regen SMA + test
  scripts/regtest.py --no-build --no-generate-servers --function=SMA
                                                                 # regen SMA indicator + test
  scripts/regtest.py --no-regtest --language=c --function=STOCH  # build + perftest only
  scripts/regtest.py --test-only --no-regtest --function=STOCH   # just perftest, no build
  scripts/regtest.py --test-only --no-regtest --function=WILLR --shape=trend-chop-1p
                                                                 # perftest on trending input
"""

import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utilities.common import (
    check_prerequisites, prereqs_for_languages, backends_for_languages,
)
import serve_version
from utilities import ref_serve

OUR_FLAGS = {
    "--no-build", "--no-generate", "--no-generate-indicators", "--no-generate-servers",
    "--no-regtest", "--no-perftest", "--no-test", "--no-direct-bench",
    "--test-only", "--direct-bench-only", "--rust-debug",
}


def find_repo_root():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        check=True, capture_output=True, text=True, cwd=script_dir,
    )
    return result.stdout.strip()


def get_filter(args, prefix):
    for a in args:
        if a.startswith(prefix + "="):
            return a.split("=", 1)[1]
    return None


# LANG_PREREQS / prereqs_for_languages moved to utilities/common.py so that
# scripts/build.py enforces the same rule — a machine that can reach
# `--language=c,rust` here must be able to reach it there too (issue #150).


# Reference-as-server: the reference C library is frozen at this immutable tag
# and checked out in a sibling git worktree, so ta_ref_serve stays a true oracle
# now that src/ta_func holds the generated code (comparing against an in-process
# baseline built from the same tree would be circular).
# ta_ref_serve construction lives in utilities/ref_serve.py: BUILDING the oracle
# is build.py's job (`build.py ta_ref_serve`), and this module is what both call
# so the two cannot drift.
REF_TAG = ref_serve.REF_TAG
ensure_reference_serve = ref_serve.ensure_reference_serve


def main():
    if "--help" in sys.argv or "-h" in sys.argv:
        print(__doc__.strip())
        sys.exit(0)

    argv = sys.argv[1:]
    test_only      = "--test-only" in argv
    direct_only    = "--direct-bench-only" in argv
    no_build       = "--no-build" in argv or test_only or direct_only
    no_gen         = "--no-generate" in argv or test_only or direct_only
    no_gen_ind     = "--no-generate-indicators" in argv or no_gen
    no_gen_srv     = "--no-generate-servers" in argv or no_gen
    no_test        = "--no-test" in argv
    no_regtest     = "--no-regtest" in argv or no_test or direct_only
    no_perftest    = "--no-perftest" in argv or no_test or direct_only
    # Build the Rust server with the debug profile (overflow checks on) so the
    # codegen run traps the IMI/APO/PPO-class arithmetic overflow that a release
    # build wraps away. CI runs this as a Rust-only gate.
    rust_debug     = "--rust-debug" in argv

    # Alias --indicator(s) and --functions to --function
    def normalize_flag(a):
        for prefix in ("--indicators=", "--indicator=", "--functions="):
            if a.startswith(prefix):
                return "--function=" + a.split("=", 1)[1]
        return a
    passthrough = [normalize_flag(a) for a in argv if a not in OUR_FLAGS]

    # Reject unknown argv up front. The downstream steps filter `passthrough`
    # by allowlist before handing it to ta_regtest / ta_bench / ta_bench_direct,
    # because those binaries reject argv they do not recognise. Filtering alone
    # would turn a typo into a SILENT default -- `--shpae=constant` would exit 0
    # having benchmarked randwalk -- which is exactly the failure mode the
    # binaries were made strict to prevent. So validate here, once, loudly.
    KNOWN_PASSTHROUGH = (
        "--function=", "--language=", "--points=", "--iters=", "--period=",
        "--shape=", "--seed=", "--regime-period=", "--trend-strength=",
        "--codegen=",
        "--no-guarded",
    )
    # --fuzz-064 and --xlang-hash are deliberately NOT accepted. This pipeline
    # has one ta_regtest invocation and it always carries --codegen; ta_regtest
    # now rejects that combination outright, and before it did the two modes
    # returned first, so `regtest.py --xlang-hash` printed the REGTEST banner
    # and then ran none of it. They are their own runs -- scripts/build.py
    # xlang-hash / fuzz-064 -- and the report below names them every time.
    # --codegen is EXACT, not a prefix: a bare `startswith("--codegen")` accepts
    # any `--codegen<anything>` and forwards the typo to ta_regtest, which is a
    # louder failure than it needs to be and a quieter one than it looks.
    EXACT_PASSTHROUGH = ("--codegen",)
    unknown = [a for a in passthrough
               if a not in EXACT_PASSTHROUGH and not a.startswith(KNOWN_PASSTHROUGH)]
    if unknown:
        print("regtest.py: unknown option(s): " + " ".join(unknown))
        print(__doc__)
        sys.exit(2)

    func_filter = get_filter(passthrough, "--function")
    lang_filter = get_filter(passthrough, "--language")

    # Must follow --language parsing: the prerequisite set depends on it.
    # The ta_codegen `--backend=` value for this run. Derived from --language,
    # but only real backend names survive: ta_bench also accepts "cref" (a frozen
    # prebuilt binary that is never generated or built here), and forwarding that
    # verbatim made the generator hard-error on an otherwise valid invocation.
    backend_filter = backends_for_languages(lang_filter)
    # Derived from the RESOLVED backend list, not the raw filter, so the tools we
    # demand always match the backends we go on to build. `--language=cref` names
    # no backend, so it resolves to None = "build everything" — and then the full
    # toolchain is required rather than a short list followed by a Java compile.
    check_prerequisites(prereqs_for_languages(backend_filter))

    root = find_repo_root()
    build_dir = os.path.join(root, "cmake-build")
    bin_dir = os.path.join(root, "bin")
    codegen_dir = os.path.join(root, "ta_codegen", "generator")
    jobs = str(os.cpu_count() or 4)

    # 1. cmake
    if not no_build:
        os.makedirs(build_dir, exist_ok=True)
        # BUILD_BENCHMARKS is OFF by default (developer-only), and steps 6/7 run
        # the benches. Reconfigure when it is missing OR cached OFF — an existing
        # cmake-build/ from a plain `cmake ..` would otherwise have no ta_bench
        # target and fail the build below.
        cache = os.path.join(build_dir, "CMakeCache.txt")
        needs_cmake = not os.path.exists(cache)
        if not needs_cmake:
            with open(cache, encoding="utf-8", errors="replace") as fh:
                needs_cmake = "BUILD_BENCHMARKS:BOOL=ON" not in fh.read()
        if needs_cmake:
            subprocess.run(["cmake", root, "-DCMAKE_BUILD_TYPE=Release",
                            "-DBUILD_BENCHMARKS=ON"],
                           check=True, cwd=build_dir)
        print("=== Building ta_regtest + ta_bench ===")
        subprocess.run(["cmake", "--build", ".", "--target",
                        "ensure_ta_regtest_in_bin", "ta_bench", "ta_bench_direct",
                        "-j", jobs],
                       check=True, cwd=build_dir)
        for name in ("ta_bench", "ta_bench_direct"):
            src = os.path.join(build_dir, "bin", name)
            dst = os.path.join(bin_dir, name)
            if os.path.exists(src):
                try:
                    shutil.copy2(src, dst)
                except OSError:
                    if os.path.exists(dst):
                        os.remove(dst)
                    shutil.copy2(src, dst)

        # Build ta_ref_serve from the FROZEN pinned-tag reference worktree
        # (canonical cutover task #7, reference-as-server). See ensure_reference_serve.
        ensure_reference_serve(root, bin_dir)

    # 2. generate indicators
    if not no_gen_ind:
        print("\n=== Regenerating indicator files ===")
        cmd = ["cargo", "run", "--release", "--", "generate"]
        if backend_filter:
            cmd.append(f"--backend={backend_filter}")
        if func_filter:
            cmd.append(f"--function={func_filter}")
        subprocess.run(cmd, check=True, cwd=codegen_dir)

    # 3a. generate servers — skipped when step 2 already wrote them: a full
    # `generate` owns every committed source, the servers and benches included
    # (it skips them only under --func, where they would lose every other
    # function).
    covered_by_generate = not no_gen_ind and not func_filter
    if not no_gen_srv and not covered_by_generate:
        print("\n=== Regenerating server files ===")
        cmd = ["cargo", "run", "--release", "--", "generate-servers"]
        if backend_filter:
            cmd.append(f"--backend={backend_filter}")
        subprocess.run(cmd, check=True, cwd=codegen_dir)

    # 3b. generate bench binary source. The benches are C, so step 2 covers them
    # only when it actually ran the C backend — `--language=rust` narrows it to
    # `generate --backend=rust`, which writes no bench at all.
    c_covered = covered_by_generate and (
        not backend_filter or 'c' in [b.strip() for b in backend_filter.split(',')])
    if not no_gen_srv and not c_covered:
        print("\n=== Regenerating bench binary ===")
        cmd = ["cargo", "run", "--release", "--", "generate-bench", "--backend=c"]
        subprocess.run(cmd, check=True, cwd=codegen_dir)

    # 4. compile servers (only if something was regenerated)
    did_generate = not no_gen_ind or not no_gen_srv
    if did_generate:
        print("\n=== Compiling servers ===")
        cmd = ["cargo", "run", "--release", "--", "build"]
        if backend_filter:
            cmd.append(f"--backend={backend_filter}")
        subprocess.run(cmd, check=True, cwd=codegen_dir)

        # Debug-profile Rust server: rebuild just the Rust server bin without
        # --release (overflow checks on) and install it over the release one, so
        # the codegen run below crashes on an arithmetic overflow instead of
        # wrapping it away. See run_edge_range_sweep in test_codegen.c.
        if rust_debug:
            print("\n=== Rebuilding Rust server (debug profile) ===")
            rust_dir = os.path.join(root, "ta_codegen", "output", "rust")
            subprocess.run(["cargo", "build", "--bin", "ta_codegen_serve"],
                           check=True, cwd=rust_dir)
            shutil.copy2(
                os.path.join(rust_dir, "target", "debug", "ta_codegen_serve"),
                os.path.join(bin_dir, "ta_codegen_serve_rust"),
            )

    # 5. regtest — ONE invocation. --codegen runs the C reference tests and the
    #    cross-language verification in the same process, which is what lets
    #    server_verify ride the hand-written tests (it is gated on them running).
    rc = 0
    if not no_regtest:
        print("\n" + "=" * 60)
        print("REGTEST — C reference tests + cross-language codegen verification")
        print("=" * 60)
        # Allowlist, not passthrough: ta_regtest exits with BAD_USER_PARAM on any
        # argv it does not know (ta_regtest.c, the trailing else of the option
        # chain). Forwarding the perftest/bench-only flags — --points=, --iters=
        # and the corpus selectors — aborted this step before the bench in step
        # 6/7 ever ran. An allowlist keeps a future bench flag from breaking it.
        REGTEST_FLAGS = ("--function=", "--language=", "--codegen", "--codegen=",
                         "--no-guarded")
        codegen_args = [a for a in passthrough
                        if a.startswith(REGTEST_FLAGS)]
        if not any(a.startswith("--codegen") for a in codegen_args):
            codegen_args = ["--codegen"] + codegen_args
        rc = subprocess.run(
            [os.path.join(bin_dir, "ta_regtest")] + codegen_args,
            cwd=bin_dir,
        ).returncode
        if rc != 0:
            print(f"\nRegtest FAILED (exit {rc})")
            sys.exit(rc)

    # 6. perftest
    if not no_perftest:
        print("\n" + "=" * 60)
        print("PERFTEST — performance (large dataset, averaged)")
        print("=" * 60, flush=True)
        # Allowlist for the same reason as step 5b: ta_bench now rejects unknown
        # argv instead of ignoring it, so flags only ta_regtest knows (--codegen,
        # --no-guarded, ...) must not reach it.
        BENCH_FLAGS = ("--points=", "--iters=", "--language=", "--function=",
                       "--period=", "--shape=", "--seed=", "--regime-period=",
                       "--trend-strength=")
        # Always include cref for comparison, even when --language= filters
        bench_args = [a for a in passthrough if a.startswith(BENCH_FLAGS)]
        if lang_filter and "cref" not in lang_filter:
            for i, a in enumerate(bench_args):
                if a.startswith("--language="):
                    bench_args[i] = a + ",cref"
                    break
        bench_rc = subprocess.run(
            [os.path.join(bin_dir, "ta_bench")] + bench_args,
            cwd=bin_dir,
        ).returncode
        if bench_rc != 0 and rc == 0:
            rc = bench_rc

    # 7. direct bench (in-process libta-lib.a vs the single-TU ta_bench_cg)
    # Runs unless --no-test; independent of --no-perftest
    if (not no_test or direct_only) and "--no-direct-bench" not in argv:
        bench_direct = os.path.join(bin_dir, "ta_bench_direct")
        bench_cg = os.path.join(bin_dir, "ta_bench_cg")
        missing = []
        if not os.path.exists(bench_direct):
            missing.append("ta_bench_direct")
        if not os.path.exists(bench_cg):
            missing.append("ta_bench_cg")
        if missing:
            print(f"\n  Skipping direct bench (missing: {', '.join(missing)})")
            print("  Run without --direct-bench-only to build them first.")
        else:
            print("\n" + "=" * 60)
            print("DIRECT BENCH — libta-lib.a vs ta_bench_cg (different builds)")
            print("=" * 60, flush=True)
            direct_args = [a for a in passthrough
                           if a.startswith("--function=")
                           or a.startswith("--iters=")
                           or a.startswith("--points=")
                           or a.startswith("--shape=")
                           or a.startswith("--seed=")
                           or a.startswith("--regime-period=")
                           or a.startswith("--trend-strength=")]
            direct_rc = subprocess.run(
                [bench_direct] + direct_args, cwd=bin_dir,
            ).returncode
            if direct_rc != 0 and rc == 0:
                rc = direct_rc

    # Name what this pipeline did NOT run.
    #
    # CI decomposes the cross-language legs into their own jobs, so this script
    # is not a superset of CI even when every step above passes. A run that says
    # nothing here reads exactly like one that ran everything and agreed -- the
    # same failure mode the codegen leg avoids by naming its skips ("no
    # frozen-reference baseline (post-cutover): ...") instead of omitting them
    # silently.
    #
    # Scope: only the legs THIS pipeline can run and didn't. Enumerating every
    # nightly job here would go stale the first time one is added, so point at
    # the workflow for the full list rather than copying it.
    if not no_regtest:
        # Unconditional, because neither is reachable from here any more. A
        # predicate over `passthrough` would be a constant that reads like a
        # check -- and the one it replaced went the wrong way: passing
        # --xlang-hash suppressed this warning about xlang while the run it
        # produced skipped the codegen step as well.
        skipped = [
            (
                "--xlang-hash",
                "every language server bitwise vs the in-process C library "
                "(zero tolerance, all shapes)",
                "scripts/build.py xlang-hash",
                "~3 min, 176 functions",
            ),
            (
                "--fuzz-064",
                "differential against the frozen v0.6.4 oracle",
                "scripts/build.py fuzz-064",
                "",
            ),
        ]
        if skipped or func_filter or lang_filter:
            print("\n" + "=" * 60)
            print("NOT RUN BY THIS PIPELINE (CI runs each as its own job)")
            print("=" * 60)
            for flag, what, how, cost in skipped:
                print(f"  {flag}  --  {what}")
                print(f"      {how}" + (f"   ({cost})" if cost else ""))
            if func_filter:
                print(f"  --function={func_filter} narrowed every step above; "
                      "CI runs the full corpus.")
            if lang_filter:
                print(f"  --language={lang_filter} narrowed every step above; "
                      "CI runs all four backends.")
            print("  Full nightly job list: .github/workflows/dev-nightly-tests.yml")

    sys.exit(rc)


if __name__ == "__main__":
    main()

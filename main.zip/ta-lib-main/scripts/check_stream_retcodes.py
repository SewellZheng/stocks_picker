#!/usr/bin/env python3
"""Every history-length arm, in every backend, must report the same code.

One rule, two scans.

Rule rS7 (https://ta-lib.org/spec/streaming/#rs7): a streaming
`Open`/`OpenAndFill` given fewer than `lookback + 1` bars reports
`TA_INSUFFICIENT_HISTORY`. It is the library's one RECOVERABLE condition, so it
must be distinguishable from `TA_BAD_PARAM`, which always means the call itself
is wrong.

An EMPTY history is rS7 too. No arm of its own answers it: the anchor guard
`startIdx >= historyLen`, after every argument check, does, so that guard is
scanned separately.

Why a structural check and not a probe. The condition is emitted from every
backend independently at half a dozen sites each -- a transcribed early return, an
explicit `historyLen < lookback + 1` guard, the composed capture guard, the
identity fast path, the period bank -- and a probe reaches only the shapes
someone thought to write one for. When TA_INSUFFICIENT_HISTORY was introduced,
two C sites were missed (the identity fast path and the period-bank OpenAndFill);
the hand-written probe covered six shapes and neither of those was among them,
and no value gate can see a return code that no test provokes. This reads the
generated output instead, so it covers every function and every shape at once,
and a new indicator or a new emission site is covered the day it lands.

The count of arms inspected is printed and floored per backend, so a pattern that
stops matching fails loudly rather than passing over nothing.
"""

import os
import re
import sys

# One row per backend. Two independent arm shapes are matched, because the
# generator emits the condition two ways and the miss that motivated this check
# was in the first kind while the bulk of the arms are the second:
#
#   EXPLICIT  an `historyLen < <lookback> + 1` precheck, or the composed capture
#             guard (`dummyNBElement < 1` / `outNBElement < 1`). This is where the
#             identity fast path and the period bank live -- the two C sites that
#             were missed.
#   EARLY     the transcribed batch early return, under `startIdx > endIdx`. In
#             the BATCH tier that arm answers success; in a stream it means the
#             history is short. Either way it is never the catch-all, which is
#             what makes this a non-circular invariant rather than a restatement
#             of whatever the emitter happens to produce.
#
# The anchor guard -- what answers an EMPTY history -- is a different emission
# and is scanned separately below.
#
# The floors are LITERAL, and per backend and per shape. A floor derived from
# what the scan finds moves with it, and would let every arm vanish while still
# "passing its floor". They are minimums, so adding an indicator only raises the
# real count; a DROP means the emitted shape changed and this check is now
# looking at less than it was written to look at.
BACKENDS = [
    ("C", os.path.join("src", "ta_func"), ".c",
     r"TA_BAD_PARAM", r"TA_INSUFFICIENT_HISTORY",
     re.compile(r"(?:historyLen\s*<\s*(?!1\s*\))[^;\n]*?\+\s*1|dummyNBElement\s*<\s*1)\s*\)"
                r"[^\n]*?return\s+(TA_BAD_PARAM|TA_INSUFFICIENT_HISTORY)\s*;"), 11,
     re.compile(r"if\(\s*startIdx\s*>\s*endIdx\s*\)[\s\S]{0,220}?return\s+(TA_\w+)\s*;"), 400),

    ("Rust", os.path.join("ta_codegen", "output", "rust", "library", "src", "ta_func"), ".rs",
     r"BadParam", r"InsufficientHistory",
     re.compile(r"(?:historyLen\s*<\s*(?!1\s*\{)[^\n{]*?\+\s*1|\*outNBElement\s*<\s*1)\s*\{\s*\n\s*"
                r"return\s+Err\(RetCode::(BadParam|InsufficientHistory)\)\s*;"), 11,
     re.compile(r"if\s+startIdx\s*>\s*endIdx\s*\{[\s\S]{0,220}?return\s+(\w+(?:\(RetCode::\w+\))?)"), 100),

    ("Java", os.path.join("ta_codegen", "output", "java", "fragments"), ".java",
     r"RetCode.BAD_PARAM", r"RetCode.INSUFFICIENT_HISTORY",
     re.compile(r"(?:historyLen\s*<\s*(?!1\s*\))[^\n)]*?\+\s*1|outNBElement\.value\s*<\s*1)\s*\)\s*\{\s*\n\s*"
                r"return\s+RetCode\.(BAD_PARAM|INSUFFICIENT_HISTORY)\s*;"), 11,
     None, 0),

    ("C#", os.path.join("ta_codegen", "output", "csharp", "library", "src"), ".cs",
     r"RetCode.BadParam", r"RetCode.InsufficientHistory",
     re.compile(r"(?:historyLen\s*<\s*(?!1\s*\))[^\n)]*?\+\s*1|outNBElement\s*<\s*1)\s*\)\s*\{\s*\n\s*"
                r"return\s+RetCode\.(BadParam|InsufficientHistory)\s*;"), 11,
     None, 0),

    ("TypeScript", os.path.join("ta_codegen", "output", "ts", "library", "src", "func"), ".ts",
     r"RetCode.BAD_PARAM", r"RetCode.INSUFFICIENT_HISTORY",
     re.compile(r"(?:historyLen\s*<\s*(?!1\s*\))[^\n)]*?\+\s*1|outNBElement\.value\s*<\s*1)\s*\)\s*\{\s*\n\s*"
                r"return\s+RetCode\.(BAD_PARAM|INSUFFICIENT_HISTORY)\s*;"), 11,
     None, 0),

    ("Go", os.path.join("ta_codegen", "output", "go"), ".go",
     r"BadParam", r"InsufficientHistory",
     re.compile(r"(?:historyLen\s*<\s*(?!1\s*\{)[^\n{]*?\+\s*1|\*outNBElement\s*<\s*1)\s*\{\s*\n\s*"
                r"return\s+(BadParam|InsufficientHistory)\b"), 11,
     re.compile(r"if\s+startIdx\s*>\s*endIdx\s*\{[\s\S]{0,220}?return\s+(\w+)"), 100),
]


# The same idea over the anchor guard, which is what answers an EMPTY history:
# it is emitted once per strided `_OpenImpl` in every backend, so a site that
# answers anything but rS7's code has to be loud. Same literal floors, same
# reason.
EMPTY_ARMS = [
    ("C", os.path.join("src", "ta_func"), ".c", "TA_INSUFFICIENT_HISTORY",
     re.compile(r"if\(\s*startIdx\s*>=\s*historyLen\s*\)[\s\S]{0,120}?return\s+(TA_\w+)\s*;"), 230),

    ("Rust", os.path.join("ta_codegen", "output", "rust", "library", "src", "ta_func"), ".rs",
     "InsufficientHistory",
     re.compile(r"if\s+startIdx\s*>=\s*historyLen\s*\{[\s\S]{0,160}?return\s+Err\(RetCode::(\w+)\)\s*;"), 230),

    ("Java", os.path.join("ta_codegen", "output", "java", "fragments"), ".java",
     "INSUFFICIENT_HISTORY",
     re.compile(r"if\(\s*startIdx\s*>=\s*historyLen\s*\)\s*\{[\s\S]{0,160}?return\s+RetCode\.(\w+)\s*;"), 220),

    ("C#", os.path.join("ta_codegen", "output", "csharp", "library", "src"), ".cs",
     "InsufficientHistory",
     re.compile(r"if\(\s*startIdx\s*>=\s*historyLen\s*\)\s*\{[\s\S]{0,160}?return\s+RetCode\.(\w+)\s*;"), 220),

    ("TypeScript", os.path.join("ta_codegen", "output", "ts", "library", "src", "func"), ".ts",
     "INSUFFICIENT_HISTORY",
     re.compile(r"if\s*\(\s*startIdx\s*>=\s*historyLen\s*\)\s*\{[\s\S]{0,160}?return\s+RetCode\.(\w+)\s*;"), 220),

    ("Go", os.path.join("ta_codegen", "output", "go"), ".go",
     "InsufficientHistory",
     re.compile(r"if\s+startIdx\s*>=\s*historyLen\s*\{[\s\S]{0,160}?return\s+(\w+)"), 220),
]


CATCH_ALL = ("TA_BAD_PARAM", "BadParam", "BAD_PARAM", "Err(RetCode::BadParam)")


def _scan(root_dir, subdir, suffix, arm_re, is_wrong):
    """(count, [`path:line -> code` for every arm `is_wrong` rejects])."""
    d = os.path.join(root_dir, subdir)
    if not os.path.isdir(d):
        return None, [f"{d} does not exist"]
    found, wrong = 0, []
    for name in sorted(os.listdir(d)):
        if not name.endswith(suffix):
            continue
        path = os.path.join(d, name)
        with open(path, encoding="utf-8") as f:
            text = f.read()
        for m in arm_re.finditer(text):
            found += 1
            code = m.group(m.lastindex) if m.lastindex else ""
            if is_wrong(code):
                wrong.append(f"{os.path.join(subdir, name)}:"
                             f"{text.count(chr(10), 0, m.start()) + 1} -> {code}")
    return found, wrong


def check_stream_retcodes(root_dir: str) -> bool:
    ok = True
    for (label, subdir, suffix, catch_all, expected,
         explicit_re, explicit_floor, early_re, early_floor) in BACKENDS:
        for shape, arm_re, floor in (("explicit", explicit_re, explicit_floor),
                                     ("early-return", early_re, early_floor)):
            if arm_re is None:
                continue
            found, wrong = _scan(root_dir, subdir, suffix, arm_re,
                                 lambda code: code in CATCH_ALL)
            if found is None:
                print(f"Error: {label}: {wrong[0]}")
                return False
            if found < floor:
                print(f"Error: {label} {shape}: {found} arm(s) matched, expected at least "
                      f"{floor}. The emitted shape changed and this check is now looking at "
                      f"less than it was written to look at -- fix the pattern, do not lower "
                      f"the floor.")
                ok = False
                continue
            if wrong:
                print(f"Error: {label} {shape}: {len(wrong)} short-history arm(s) answer "
                      f"{catch_all} instead of {expected} (rule rS7):")
                for w in wrong[:12]:
                    print(f"         {w}")
                if len(wrong) > 12:
                    print(f"         ... and {len(wrong) - 12} more")
                ok = False
                continue
            print(f"  {label} {shape}: {found} arm(s), none on {catch_all}. OK.")
    return ok


def check_empty_history_retcodes(root_dir: str) -> bool:
    ok = True
    for label, subdir, suffix, expected, arm_re, floor in EMPTY_ARMS:
        found, wrong = _scan(root_dir, subdir, suffix, arm_re,
                             lambda code, want=expected: code != want)
        if found is None:
            print(f"Error: {label}: {wrong[0]}")
            return False
        if found < floor:
            print(f"Error: {label}: {found} anchor guard(s) matched, expected at "
                  f"least {floor}. The emitted shape changed and this check is now "
                  f"looking at less than it was written to look at -- fix the pattern, "
                  f"do not lower the floor.")
            ok = False
            continue
        if wrong:
            print(f"Error: {label}: {len(wrong)} anchor guard(s) do not answer "
                  f"{expected} (rule rS7):")
            for w in wrong[:12]:
                print(f"         {w}")
            if len(wrong) > 12:
                print(f"         ... and {len(wrong) - 12} more")
            ok = False
            continue
        print(f"  {label}: {found} guard(s), all on {expected}. OK.")
    return ok


def main() -> int:
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    print("Short-history return code (rule rS7) across every backend:")
    ok = check_stream_retcodes(root)
    print("Empty-history return code (rule rS7) across every backend:")
    ok = check_empty_history_retcodes(root) and ok
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

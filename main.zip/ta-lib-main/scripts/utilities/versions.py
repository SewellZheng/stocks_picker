import hashlib
import os
import re
import subprocess
import sys
from typing import Tuple

from .common import expand_globs
from .files import path_join

def _read_version_info(version_file_path: str, version_pattern: str) -> dict:
    """
    Read a version string from a file.

    version_pattern must be a regular expression with a first group
    that includes MAJOR, MINOR, PATCH tokens. In other words, the
    keys must be present on the line being selected by the pattern.

    The second regex group must be the value of the token.

    Returns a dictionary with the keys 'MAJOR', 'MINOR', 'PATCH'.
    """
    version_info = {'MAJOR': None, 'MINOR': None, 'PATCH': None}

    with open(version_file_path, 'r') as file:
        for line in file:
            match = version_pattern.search(line)
            if match:
                key = match.group(1)
                value = match.group(2).strip('"')
                version_info[key] = value

    if None in version_info.values():
        print(f"Error: MAJOR, MINOR, and PATCH must be defined in {version_file_path}")
        sys.exit(1)

    return version_info

def _version_info_to_string(version_info: dict) -> str:
    """
    Convert a version information dictionary to a version string.

    The dictionary must have the keys 'MAJOR', 'MINOR', 'PATCH'.
    """
    # Verify that all keys are defined.
    if None in version_info.values():
        print(f"Error: MAJOR, MINOR, and PATCH must be defined in {version_info}")
        sys.exit(1)

    return f"{version_info.get('MAJOR', '0')}.{version_info.get('MINOR', '0')}.{version_info.get('PATCH', '0')}"

def _split_version_string(version: str) -> dict:
    """
    Split a version string into its components.

    The version string must be in the format "0.0.0"

    Returns a dictionary with the keys 'MAJOR', 'MINOR', 'PATCH'
    """
    version_info = {'MAJOR': None, 'MINOR': None, 'PATCH': None}

    dot_parts = version.split('.')
    if len(dot_parts) != 3:
        print(f"Error: version must be in format '0.0.0' got instead [{version}]")
        sys.exit(1)

    version_info['MAJOR'], version_info['MINOR'], version_info['PATCH'] = dot_parts

    return version_info

def get_version_string(root_dir: str) -> str:
    """
    Parse the file VERSION to get the version string.

    The file contains a single line with the version string "major.minor.patch"

    One number, every backend. C, the Rust crate and the Java artifact all carry
    this version, because a release in practice changes something all of them
    share — they are one generated library, not four that happen to ship
    together. Publishing is not in lockstep, though: cutting a release ships the
    C assets, and each binding goes out on its own path.

    The obligation that buys: **bump MINOR whenever any backend breaks its API**,
    even if the change that motivated the release was a C patch. Cargo reads 0.x
    minor as the breaking position, so `ta-lib = "0.8"` silently accepts every
    0.8.x — a break shipped in a patch upgrades itself into consumers' builds
    with no signal. `cargo-semver-checks` in the dev nightly is the mechanical
    guard, once a published version exists to compare against.

    Exit on any error.
    """
    version_file_path = path_join(root_dir, "VERSION")

    try:
        with open(version_file_path, 'r') as version_file:
            version_string = version_file.readline().strip()
        # Validate the "0.0.0" format.
        if not re.match(r'^\d+\.\d+\.\d+$', version_string):
            print(f"Error: VERSION file must contain a valid version string in the format '0.0.0'. Got instead [{version_string}]")
            sys.exit(1)
    except Exception as e:
        print(f"Error reading version file: {e}")
        sys.exit(1)

    return version_string

def set_version_string(root_dir: str, new_version:str):
    """
    Counterpart to get_version_string() that updates the VERSION file with the
    provided new_version string.
    """
    version_file_path = path_join(root_dir, "VERSION")

    current_version = get_version_string(root_dir)

    if current_version == new_version:
        return # No changes needed. The version is already up to date.

    with open(version_file_path, 'w') as version_file:
        version_file.write(new_version + '\n')

def get_version_string_source_code(root_dir: str) -> str:
    """
    Parse the file src/ta_common/ta_version.c to build a version string.

    The file contains the following C definitions:
        #define MAJOR "0"
        #define MINOR "6"
        #define PATCH "0"

    These become the string "0.6.1".
    """

    version_file_path = path_join(root_dir, "src", "ta_common", "ta_version.c")
    version_pattern = re.compile(r'#define\s+(MAJOR|MINOR|PATCH)\s+"(.*?)"')

    version_info = _read_version_info(version_file_path, version_pattern)

    return _version_info_to_string(version_info)

def set_version_string_source_code(root_dir: str, new_version:str):
    """
    Counterpart to get_version_string_source_code() that updates the src/ta_common/ta_version.c
    """
    version_file_path = path_join(root_dir, "src", "ta_common", "ta_version.c")

    current_version = get_version_string_source_code(root_dir)

    if current_version == new_version:
        return # No changes needed. The version is already up to date.

    version_info = _split_version_string(new_version)

    # Read the ta_version.c file
    with open(version_file_path, 'r') as version_file:
        lines = version_file.readlines()

    # Update the version information in the lines
    version_pattern = re.compile(r'#define\s+(MAJOR|MINOR|PATCH)\s+"(.*?)"')
    found_keys = set()
    for i, line in enumerate(lines):
        match = version_pattern.search(line)
        if match:
            key = match.group(1)
            if key in version_info:
                value = version_info[key]
                lines[i] = f'#define {key} "{value}"\n'
                found_keys.add(key)

    # Check if all required keys were found
    if not all(k in found_keys for k in ['MAJOR', 'MINOR', 'PATCH']):
        print(f"Error: MAJOR, MINOR, and PATCH must be defined in {version_file_path}")
        sys.exit(1)

    # Write the updated lines back to the ta_version.c file
    with open(version_file_path, 'w') as version_file:
        version_file.writelines(lines)

def get_version_string_cmake(root_dir: str) -> str:
    """
    Similar to get_version_string_source_code() but parse CMakeLists.txt instead of ta_version.c

    Excerpt of the file:
        SET(TA_LIB_VERSION_MAJOR 0)
        SET(TA_LIB_VERSION_MINOR 6)
        SET(TA_LIB_VERSION_PATCH 0)
    """
    version_file_path = path_join(root_dir, "CMakeLists.txt")
    version_pattern = re.compile(r'set\s*\(\s*TA_LIB_VERSION_(MAJOR|MINOR|PATCH)\s+(\d+)\s*\)', re.IGNORECASE)

    version_info = _read_version_info(version_file_path, version_pattern)

    return _version_info_to_string(version_info)


def set_version_string_cmake(root_dir: str, new_version:str):
    """
    Counterpart to get_version_string_cmake() that updates the
    file with the provided new_version string.

    The SET(TA_LIB_VERSION_XXXXXX, VALUE) pattern must already be present in the file,
    so only the VALUE portion need to be modified.

    If a given TA_LIB_VERSION_XXXXXX is not found in the file, the function will
    fail with a sys.exit(1).

    Excerpt of the file:
        SET(TA_LIB_VERSION_MAJOR 0)
        SET(TA_LIB_VERSION_MINOR 6)
        SET(TA_LIB_VERSION_PATCH 0)

    Example of new_version: "0.12.2"
    """

    version_file_path = path_join(root_dir, "CMakeLists.txt")

    current_version = get_version_string_cmake(root_dir)

    if current_version == new_version:
        return # No changes needed. The version is already up to date.

    version_info = _split_version_string(new_version)

    # Read the CMakeLists.txt file
    with open(version_file_path, 'r') as cmake_file:
        lines = cmake_file.readlines()

    # Update the version information in the lines
    version_pattern = re.compile(r'set\s*\(\s*TA_LIB_VERSION_(MAJOR|MINOR|PATCH)\s+.*\)', re.IGNORECASE)
    found_keys = set()
    for i, line in enumerate(lines):
        match = version_pattern.search(line)
        if match:
            key = match.group(1)
            if key in version_info:
                value = version_info[key]
                lines[i] = f'set(TA_LIB_VERSION_{key} {value})\n'
                found_keys.add(key)

    # Check if all required keys were found
    if not all(k in found_keys for k in ['MAJOR', 'MINOR', 'PATCH']):
        print(f"Error: MAJOR, MINOR, and PATCH must be defined in {version_file_path}")
        sys.exit(1)

    # Write the updated lines back to the CMakeLists.txt file
    with open(version_file_path, 'w') as cmake_file:
        cmake_file.writelines(lines)

def get_version_string_spec_in(root_dir: str) -> str:
    """
    Reads the version string from the ta-lib.spec.in file.
    """
    filepath = path_join(root_dir, "ta-lib.spec.in")
    version_pattern = re.compile(r'%define\s+ta_ver\s+(\d+\.\d+\.\d+)')

    with open(filepath, 'r') as file:
        for line in file:
            match = version_pattern.search(line)
            if match:
                return match.group(1)

    raise ValueError(f"ta_ver string not found in {filepath}")

def set_version_string_spec_in(root_dir: str, new_version:str):
    """
    Updates the version string in the ta-lib.spec.in file.
    """
    current_version = get_version_string_spec_in(root_dir)
    if current_version == new_version:
        print(f"No change needed. Current version is already {new_version}.")
        return

    filepath = path_join(root_dir, "ta-lib.spec.in")
    version_pattern = re.compile(r'%define\s+ta_ver\s+(\d+\.\d+\.\d+)')

    with open(filepath, 'r') as file:
        lines = file.readlines()

    updated = False
    for i, line in enumerate(lines):
        match = version_pattern.search(line)
        if match:
            current_version = match.group(1)
            if current_version != new_version:
                lines[i] = f'%define ta_ver {new_version}\n'
                updated = True
            break

    if updated:
        with open(filepath, 'w') as file:
            file.writelines(lines)
    else:
        print(f"Error: ta_ver string not found in {filepath}")
        sys.exit(1)

def get_version_string_cargo(root_dir: str) -> str:
    """
    Parse the Rust library crate manifest
    ta_codegen/output/rust/library/Cargo.toml to get the version string. Example:
      version = "0.6.4"

    Only `library` and `tools` track VERSION. The third workspace member,
    ta-lib-dispatch, is versioned independently — it changes when its one macro
    does, not when TA-Lib releases — so it is deliberately absent here. Its
    number lives in the generator (`DISPATCH_VERSION`, ta_codegen/generator/src/main.rs),
    which writes both the manifest and the `=` pin ta-lib depends on; bump it
    there.
    """
    cargo_file_path = path_join(root_dir, "ta_codegen/output", "rust", "library", "Cargo.toml")

    if not os.path.exists(cargo_file_path):
        print(f"Error: Cargo.toml not found at {cargo_file_path}")
        sys.exit(1)

    version_pattern = re.compile(r'version\s*=\s*"(\d+\.\d+\.\d+)"')

    try:
        with open(cargo_file_path, 'r') as cargo_file:
            for line in cargo_file:
                match = version_pattern.search(line)
                if match:
                    return match.group(1)

        print(f"Error: Version not found in {cargo_file_path}")
        sys.exit(1)
    except Exception as e:
        print(f"Error reading Cargo.toml file: {e}")
        sys.exit(1)

def set_version_string_cargo(root_dir: str, new_version: str):
    """
    Update the version in both Rust workspace member manifests
    (ta_codegen/output/rust/{library,tools}/Cargo.toml) — kept in lockstep.
    """
    if get_version_string_cargo(root_dir) == new_version:
        return  # No changes needed. The version is already up to date.

    version_pattern = re.compile(r'version\s*=\s*"(\d+\.\d+\.\d+)"')
    for member in ("library", "tools"):
        cargo_file_path = path_join(root_dir, "ta_codegen/output", "rust", member, "Cargo.toml")

        if not os.path.exists(cargo_file_path):
            print(f"Warning: Cargo.toml not found at {cargo_file_path}")
            continue

        with open(cargo_file_path, 'r') as cargo_file:
            lines = cargo_file.readlines()

        # Update the first `version = "x.y.z"` (the [package] version) in the member.
        updated = False
        for i, line in enumerate(lines):
            if version_pattern.search(line):
                lines[i] = re.sub(version_pattern, f'version = "{new_version}"', line)
                updated = True
                break

        if not updated:
            print(f"Warning: Version line not found in {cargo_file_path}")
            continue

        with open(cargo_file_path, 'w') as cargo_file:
            cargo_file.writelines(lines)

# The workspace members whose version tracks the repo VERSION. ta-lib-dispatch is
# deliberately absent: it versions on its own cadence, independent of a release.
_CARGO_LOCK_MEMBERS = ("ta-lib", "ta-lib-tools")

def get_version_string_cargo_lock(root_dir: str) -> str:
    """
    Parse ta_codegen/output/rust/Cargo.lock for the version it records against
    the members that track VERSION. Example:
      [[package]]
      name = "ta-lib"
      version = "0.8.1"

    The LOWEST of them is returned, so a lock lagging on any one member reads as
    stale. A missing entry exits rather than returning None: this value decides
    whether the lock gets refreshed at all, so failing soft here would put the
    stale lock back in a release, which is the whole reason it is read.
    """
    lock_path = path_join(root_dir, "ta_codegen/output", "rust", "Cargo.lock")

    if not os.path.exists(lock_path):
        print(f"Error: Cargo.lock not found at {lock_path}")
        sys.exit(1)

    with open(lock_path, 'r') as lock_file:
        lock_text = lock_file.read()

    lowest = None
    for member in _CARGO_LOCK_MEMBERS:
        match = re.search(r'name = "%s"\nversion = "(\d+\.\d+\.\d+)"' % re.escape(member),
                          lock_text)
        if not match:
            print(f"Error: no [[package]] entry for '{member}' in {lock_path}")
            sys.exit(1)
        if lowest is None or compare_version(lowest, match.group(1)) > 0:
            lowest = match.group(1)

    return lowest

def refresh_cargo_lock(root_dir: str):
    """
    Bring ta_codegen/output/rust/Cargo.lock back in step with its manifests.

    RESOLVES, never edits. `cargo metadata` rewrites only what the manifests now
    demand -- here, the members' own version lines -- and leaves every dependency
    on the version the lock already pinned. Editing the file by hand would forge
    a generated artifact, and `cargo update` would float the whole dependency set
    off the versions the release is meant to freeze.
    """
    manifest = path_join(root_dir, "ta_codegen/output", "rust", "Cargo.toml")
    try:
        returncode = subprocess.run(
            ["cargo", "metadata", "--format-version", "1", "--manifest-path", manifest],
            stdout=subprocess.DEVNULL).returncode
    except FileNotFoundError:
        print("Error: cargo is required to refresh Cargo.lock after a version bump.")
        sys.exit(1)

    if returncode != 0:
        print(f"Error: could not refresh Cargo.lock from {manifest} "
              f"(cargo's own message is above).")
        sys.exit(1)

def get_version_string_pom(root_dir: str) -> str:
    """
    Parse the shipped Java library manifest
    ta_codegen/output/java/library/pom.xml to get the project version. Example:
      <version>0.6.4</version>

    Anchored on the two-space indent, which is the project-level coordinate: the
    plugin <version> tags are nested far deeper. Matching the first <version>
    anywhere would work today only because the coordinate happens to come first.
    """
    pom_path = path_join(root_dir, "ta_codegen/output", "java", "library", "pom.xml")

    if not os.path.exists(pom_path):
        print(f"Error: pom.xml not found at {pom_path}")
        sys.exit(1)

    version_pattern = re.compile(r'^  <version>(\d+\.\d+\.\d+)</version>')

    try:
        with open(pom_path, 'r') as pom_file:
            for line in pom_file:
                match = version_pattern.search(line)
                if match:
                    return match.group(1)

        print(f"Error: Project version not found in {pom_path}")
        sys.exit(1)
    except Exception as e:
        print(f"Error reading pom.xml file: {e}")
        sys.exit(1)

def set_version_string_pom(root_dir: str, new_version: str):
    """
    Update the project version in the shipped Java library's pom.xml.
    """
    if get_version_string_pom(root_dir) == new_version:
        return  # No changes needed. The version is already up to date.

    pom_path = path_join(root_dir, "ta_codegen/output", "java", "library", "pom.xml")
    version_pattern = re.compile(r'^  <version>(\d+\.\d+\.\d+)</version>')

    with open(pom_path, 'r') as pom_file:
        lines = pom_file.readlines()

    updated = False
    for i, line in enumerate(lines):
        if version_pattern.search(line):
            lines[i] = f'  <version>{new_version}</version>\n'
            updated = True
            break

    if not updated:
        print(f"Error: Project version line not found in {pom_path}")
        sys.exit(1)

    with open(pom_path, 'w') as pom_file:
        pom_file.writelines(lines)

def get_version_string_conanfile(root_dir: str) -> str:
    """
    Parse the file conanfile.py to get the version string. Example:
      version = "0.6.4"
    """
    conanfile_path = path_join(root_dir, "conanfile.py")

    if not os.path.exists(conanfile_path):
        print(f"Error: conanfile.py not found at {conanfile_path}")
        sys.exit(1)

    version_pattern = re.compile(r'^\s+version\s*=\s*"(\d+\.\d+\.\d+)"')

    try:
        with open(conanfile_path, 'r') as conanfile:
            for line in conanfile:
                match = version_pattern.search(line)
                if match:
                    return match.group(1)

        print(f"Error: Version not found in {conanfile_path}")
        sys.exit(1)
    except Exception as e:
        print(f"Error reading conanfile.py: {e}")
        sys.exit(1)

def set_version_string_conanfile(root_dir: str, new_version: str):
    """
    Update the version in conanfile.py.
    """
    conanfile_path = path_join(root_dir, "conanfile.py")

    if not os.path.exists(conanfile_path):
        print(f"Warning: conanfile.py not found at {conanfile_path}")
        return  # No action if file doesn't exist

    current_version = get_version_string_conanfile(root_dir)

    if current_version == new_version:
        return  # No changes needed. The version is already up to date.

    # Read the conanfile.py file
    with open(conanfile_path, 'r') as conanfile:
        lines = conanfile.readlines()

    # Update the version information in the lines
    version_pattern = re.compile(r'^\s+version\s*=\s*"(\d+\.\d+\.\d+)"')
    updated = False

    for i, line in enumerate(lines):
        match = version_pattern.search(line)
        if match:
            lines[i] = line[:match.start(1)] + new_version + line[match.end(1):]
            updated = True
            break

    # Check if version was found and updated
    if not updated:
        print(f"Warning: Version line not found in {conanfile_path}")
        return

    # Write the updated lines back to the conanfile.py file
    with open(conanfile_path, 'w') as conanfile:
        conanfile.writelines(lines)

def compare_version(version1: str, version2: str) -> int:
    """
    Compare two version strings.

    The format is 0.0.0

    Returns:
        -1 if version1 < version2
         0 if version1 == version2
         1 if version1 > version2
    """

    # Compare the parts as integer values
    v1_parts = list(map(int, version1.split('.')))
    v2_parts = list(map(int, version2.split('.')))
    for v1_part, v2_part in zip(v1_parts, v2_parts):
        if v1_part > v2_part:
            return 1
        elif v1_part < v2_part:
            return -1

    return 0 # Identical versions


def sync_versions(root_dir: str) -> Tuple[bool,str]:
    """
    Synchronize the version between:
          src/ta_common/ta_version.c
          ta_codegen/output/rust/library/Cargo.toml
          ta_codegen/output/rust/Cargo.lock (refreshed by cargo, not edited)
          ta_codegen/output/java/library/pom.xml
          CMakeLists.txt (root of repos)
          VERSION file (root of repos)
          conanfile.py (root of repos)

    The versions are first read from all. The highest version is selected.

    If the versions are all the same, this function will touch nothing.

    When a file has a lower version, it is updated with the highest version.

    Return true if any file was updated.
    """
    version_file = get_version_string(root_dir)
    version_c = get_version_string_source_code(root_dir)
    version_cmake = get_version_string_cmake(root_dir)
    version_spec_in = get_version_string_spec_in(root_dir)
    version_cargo = get_version_string_cargo(root_dir)
    version_pom = get_version_string_pom(root_dir)
    version_conanfile = get_version_string_conanfile(root_dir)

    # Identify the highest version among all sources.
    # Put the highest in the variable highest_version
    highest_version = version_file
    if compare_version(highest_version, version_cmake) < 0:
        highest_version = version_cmake
    if compare_version(highest_version, version_c) < 0:
        highest_version = version_c
    if compare_version(highest_version, version_spec_in) < 0:
        highest_version = version_spec_in
    if compare_version(highest_version, version_cargo) < 0:
        highest_version = version_cargo
    if compare_version(highest_version, version_pom) < 0:
        highest_version = version_pom
    if compare_version(highest_version, version_conanfile) < 0:
        highest_version = version_conanfile

    # Update files with a lower version.
    is_updated = False
    compare_result: int = compare_version(highest_version, version_file)
    if compare_result > 0:
        print(f"Updating VERSION to [{highest_version}]")
        set_version_string(root_dir, highest_version)
        is_updated = True

    compare_result: int = compare_version(highest_version, version_c)
    if compare_result > 0:
        print(f"Updating ta_version.c to [{highest_version}]")
        set_version_string_source_code(root_dir, highest_version)
        is_updated = True

    compare_result: int = compare_version(highest_version, version_cmake)
    if compare_result > 0:
        print(f"Updating CMakeLists.txt to [{highest_version}]")
        set_version_string_cmake(root_dir, highest_version)
        is_updated = True

    compare_result: int = compare_version(highest_version, version_spec_in)
    if compare_result > 0:
        print(f"Updating ta-lib.spec.in to [{highest_version}]")
        set_version_string_spec_in(root_dir, highest_version)
        is_updated = True

    compare_result: int = compare_version(highest_version, version_cargo)
    if compare_result > 0:
        print(f"Updating Cargo.toml to [{highest_version}]")
        set_version_string_cargo(root_dir, highest_version)
        is_updated = True

    compare_result: int = compare_version(highest_version, version_pom)
    if compare_result > 0:
        print(f"Updating pom.xml to [{highest_version}]")
        set_version_string_pom(root_dir, highest_version)
        is_updated = True

    compare_result: int = compare_version(highest_version, version_conanfile)
    if compare_result > 0:
        print(f"Updating conanfile.py to [{highest_version}]")
        set_version_string_conanfile(root_dir, highest_version)
        is_updated = True

    # Last, because cargo derives the lock from the manifests set_version_string_cargo()
    # has just written. The lock carries each member's own version, so a bump strands it
    # a release behind, and cargo repairs it silently on the next unrelated cargo call --
    # so nothing surfaces the drift until someone clones the tag and builds --locked.
    # Not part of the highest_version election above: the lock is derived, never a source.
    version_cargo_lock = get_version_string_cargo_lock(root_dir)
    if compare_version(highest_version, version_cargo_lock) > 0:
        print(f"Refreshing Cargo.lock to [{highest_version}]")
        refresh_cargo_lock(root_dir)
        is_updated = True

    # NOTE: website/src/install/c/README.md (the website install page) is
    # intentionally NOT synced here. It must advertise the latest *published*
    # release, not this in-development VERSION, so rewriting it from
    # `highest_version` would leak a not-yet-released version onto the live website
    # (which deploys from main on every push). That sync lives in
    # scripts/sync-website.py (GitHub-API driven) and runs only where CI commits
    # back to the repo (dev-nightly-tests.yml).

    # highest_version, not version_c: that was read before the updates above, so a
    # run that DID bump handed its caller the version it had just replaced --
    # package.py builds the release artifacts from this value.
    return is_updated, highest_version

def check_versions(root_dir: str) -> str:
    # Similar to sync_versions() but only checks if the versions are in sync, do not modify anything.
    version_file = get_version_string(root_dir)
    version_c = get_version_string_source_code(root_dir)
    version_cmake = get_version_string_cmake(root_dir)
    version_spec_in = get_version_string_spec_in(root_dir)
    version_conanfile = get_version_string_conanfile(root_dir)
    # Cargo.toml and pom.xml matter most here even though sync_versions() would
    # already have fixed them: crates.io and Maven Central are immutable, so a
    # version published from a stale manifest cannot be withdrawn.
    version_cargo = get_version_string_cargo(root_dir)
    version_pom = get_version_string_pom(root_dir)
    # The lock is not published -- `cargo package` synthesises a fresh one into the
    # tarball -- but it is what the git tag carries, so a stale one is a tagged tree
    # that fails `cargo build --locked` for anyone who clones it.
    version_cargo_lock = get_version_string_cargo_lock(root_dir)

    if version_file != version_c:
        print(f"Error: VERSION [{version_file}] does not match ta_version.c [{version_c}]")
        return None

    if version_file != version_cmake:
        print(f"Error: VERSION [{version_file}] does not match CMakeLists.txt [{version_cmake}]")
        return None

    if version_file != version_spec_in:
        print(f"Error: VERSION [{version_file}] does not match ta-lib.spec.in [{version_spec_in}]")
        return None

    if version_file != version_conanfile:
        print(f"Error: VERSION [{version_file}] does not match conanfile.py [{version_conanfile}]")
        return None

    if version_file != version_cargo:
        print(f"Error: VERSION [{version_file}] does not match Cargo.toml [{version_cargo}]")
        return None

    if version_file != version_pom:
        print(f"Error: VERSION [{version_file}] does not match pom.xml [{version_pom}]")
        return None

    if version_file != version_cargo_lock:
        print(f"Error: VERSION [{version_file}] does not match Cargo.lock "
              f"[{version_cargo_lock}]. Did you forget to run scripts/sync.py?")
        return None

    return version_file

def write_sources_digest(root_dir: str, new_digest: str) -> bool:
    """Update the ta_common.h file with the new digest."""
    ta_common_h_path = path_join(root_dir, 'include', 'ta_common.h')
    updated = False
    try:
        with open(ta_common_h_path, 'r') as f:
            lines = f.readlines()

        with open(ta_common_h_path, 'w') as f:
            for line in lines:
                if line.startswith('#define TA_LIB_SOURCES_DIGEST'):
                    if line.strip() != f'#define TA_LIB_SOURCES_DIGEST {new_digest}':
                        f.write(f'#define TA_LIB_SOURCES_DIGEST {new_digest}\n')
                        updated = True
                    else:
                        f.write(line)
                else:
                    f.write(line)
            if not updated:
                print(f"Error: Missing TA_LIB_SOURCES_DIGEST in ta_common.h")
                sys.exit(1)

        # Read it back to confirm the change
        written_digest = read_sources_digest(root_dir)
        if written_digest != new_digest:
            print(f"Error: Failed to update TA_LIB_SOURCES_DIGEST in ta_common.h")
            sys.exit(1)

    except IOError as e:
        print(f"Error updating file {ta_common_h_path}: {e}")
        raise
    return updated

def read_sources_digest(root_dir: str) -> str:
    # Read the value of the TA_LIB_SOURCES_DIGEST. Return None if not found.
    ta_common_h_path = path_join(root_dir, 'include', 'ta_common.h')
    try:
        with open(ta_common_h_path, 'r') as f:
            for line in f:
                if line.startswith('#define TA_LIB_SOURCES_DIGEST'):
                    return line.split()[2].strip()
    except IOError as e:
        print(f"Error reading file {ta_common_h_path}: {e}")
        sys.exit(1)

    return None

def calculate_sources_digest(root_dir: str, silent: bool = False) -> str:
    # This is for a calculated digest of all source file contant relevant
    # to packaging. It helps to trig CI repackaging when a change
    # is detected.
    #
    # The digest is written as a "#define TA_LIB_SOURCE_DIGEST XXXXXXXX"
    # in ta_common.h
    #
    # Return true when ta_common.h was updated with a new digest.
    file_patterns = [
        "CMakeLists.txt",
        "configure.ac",
        "ta-lib.*.in",
        "cmake/*",
        "include/ta_abstract.h",
        "include/ta_defs.h",
        "include/ta_func.h",
        "include/ta_libc.h",
        "src/**/*.c",
        "src/**/*.h",
        "src/**/*.am",
        # The linker map decides what the shipped library EXPORTS, so a change
        # here changes the artifact without touching a single .c -- and every
        # other pattern would miss it.
        "src/*.map",
        "*.am",
        "ta_func_api.xml",
        "ta_func_list.txt",
        # NOTE: the Java and C# library sources are deliberately NOT listed.
        #
        # This digest exists to trigger repackaging of the assets in
        # get_release_assets() -- and not one of them contains a byte of Java or C#.
        # Verified against the built artifacts: src.tar.gz is autotools + include/ +
        # src/ (319 entries, zero .java/.cs), the .deb is 5 headers plus
        # libta-lib.{a,so}, and the Windows .zip is ta-lib.dll + 2 .lib + 5 headers.
        # Java ships via Maven and C# via NuGet, on their own release paths.
        #
        # Listing them meant every ta_codegen Java/C# regeneration bumped this digest
        # and forced a rebuild + repack + commit of all 8 C packages -- ~15 MB of
        # non-deltable bytes each time, for a change that cannot reach any of them.
        # Only re-add a binding here if a release asset actually starts carrying it.
        #
        # The packaging scripts decide package CONTENT, so a change to them must
        # invalidate the digest exactly like a source change does. get_src_generated_files()
        # literally defines what lands in src.tar.gz, and package.py picks the CPack
        # generator and assembles the zip/tarball.
        #
        # Without these, editing the packaging and then cutting a release ships a stale
        # package with a green digest: scheduled nightlies always rebuild and would
        # self-correct within a day, but the release path is a MANUAL dispatch
        # (README-DEVS.md step 6), which takes the build-SKIP branch of
        # is_build_skipping_allowed().
        "scripts/package.py",
        "scripts/utilities/common.py",
        "scripts/utilities/files.py",
        "LICENSE",
        "VERSION",
    ]

    file_list = expand_globs(root_dir, file_patterns)

    # Remove potential duplicate entries
    file_list = list(set(file_list))

    # Normalize file paths by removing the root directory prefix (for portable sorting).
    normalized_file_list = [os.path.relpath(file_path, root_dir) for file_path in file_list]

    # Sort lower case to ensure consistent across platforms
    sorted_files = sorted(normalized_file_list, key=lambda x: x.lower())

    running_hash = hashlib.md5()
    n_lines = 0
    n_files = 0
    n_opens = 0
    n_chars = 0
    for file_path in sorted_files:
        try:
            n_files += 1
            full_file_path = path_join(root_dir, file_path)
            with open(full_file_path, 'r', encoding='utf-8') as f:
                n_opens += 1
                for line in f:
                    # Normalize line endings to Unix-style LF, remove leading/trailing whitespace
                    normalized_line = line.replace('\r\n', '\n').replace('\r', '\n').strip()
                    utf8_line = normalized_line.encode('utf-8')
                    n_chars += len(utf8_line)
                    running_hash.update(normalized_line.encode('utf-8'))
                    n_lines += 1
                #print(f" Hash: {running_hash.hexdigest()}, File: {file_path}, Lines: {n_lines}, Opens: {n_opens}, Chars: {n_chars}")
        except Exception as e:
            print(f"Error reading file while updating source digest [{file_path}]: {e}")
            sys.exit(1)

    if not silent:
        print(f"Digest input is n_files: {n_files}, n_lines: {n_lines}, n_opens: {n_opens}, n_chars: {n_chars}")
    return running_hash.hexdigest()

def sync_sources_digest(root_dir: str) -> Tuple[bool,str]:

    calculated_digest = calculate_sources_digest(root_dir, silent=True)
    # Update ta_common.h (touch only if different)
    current_digest = read_sources_digest(root_dir)
    if current_digest == calculated_digest:
        return False, calculated_digest

    print(f"Difference detected in source digest. Updating ta_common.h")
    print(f"Old source digest: {current_digest}")
    print(f"New source digest: {calculated_digest}")

    write_sources_digest(root_dir, calculated_digest)
    return True, calculated_digest


def check_sources_digest(root_dir: str) -> str:
    # Similar to sync_sources_digest() but only checks if the digests are in sync, do not modify anything.
    current_digest = read_sources_digest(root_dir)
    if current_digest is None:
        print(f"Error: TA_LIB_SOURCES_DIGEST not found in ta_common.h")
        return None

    calculated_digest = calculate_sources_digest(root_dir, silent=True)
    if current_digest != calculated_digest:
        print(f"Error: TA_LIB_SOURCES_DIGEST [{current_digest}] does not match calculated digest [{calculated_digest}]")
        return None

    return calculated_digest


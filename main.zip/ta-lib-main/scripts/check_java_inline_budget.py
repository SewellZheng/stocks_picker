#!/usr/bin/env python3
"""MA's dispatch frames must stay inside HotSpot C2's inlining budget.

`MaStream.peek` and `Core.maStepImpl` switch over the arm MA's open picked,
and they sit under every handle that holds an MA sub-handle -- APO, BBANDS,
MACDEXT, MAVP, PPO, PVO, STOCH, STOCHF, and KDJ and STOCHRSI through those.
`Core.maStepTape` and `Core.maPeekTape` are the same switches under every slot
of an MAVP handle, which steps one per period in its range on every bar. C2
refuses to inline a hot method whose bytecode exceeds `FreqInlineSize`, so
crossing that budget costs those callers roughly a third of their per-bar
time, measured. It costs nothing visible: no test fails, no output changes.

The step and tape frames route the MATypes the enum opens with and hand the
rest to a `...Rest` frame, which C2 must inline too. New MATypes append to the
enum, so each adds 14 bytes to peek and 18 to 22 to every Rest frame: these
are the frames that expire, and the enum is live.

325 is C2's DEFAULT, not a law. It moves between JDK versions and any
deployment can override it. This gate says the frames left the budget the
arm-return shape was measured against, not that the code is wrong.

Usage: check_java_inline_budget.py <classes-dir>
"""

import re
import subprocess
import sys

# `-XX:FreqInlineSize`, the HotSpot default for a hot call site.
BUDGET = 325

TAPE_SIG = r"\(io\.github\.talib\.Core\$MaStream, double\[\], int, int, double\);"
FRAMES = [
    ("Core$MaStream", "peek", re.compile(r"^\s+public double peek\(double\);")),
    ("Core", "maStepImpl", re.compile(r"^\s+private void maStepImpl\(io\.github\.talib\.Core\$MaStream, double\);")),
    ("Core", "maStepTape", re.compile(r"^\s+private double maStepTape" + TAPE_SIG)),
    ("Core", "maPeekTape", re.compile(r"^\s+private double maPeekTape" + TAPE_SIG)),
    ("Core", "maStepImplRest", re.compile(r"^\s+private void maStepImplRest\(io\.github\.talib\.Core\$MaStream, double\);")),
    ("Core", "maStepTapeRest", re.compile(r"^\s+private double maStepTapeRest" + TAPE_SIG)),
    ("Core", "maPeekTapeRest", re.compile(r"^\s+private double maPeekTapeRest" + TAPE_SIG)),
]

# A method's last instruction is always a 1-byte return or throw, so the final
# offset plus one is the Code attribute's length -- the number C2 compares.
# Asserted rather than assumed: a multi-byte last instruction would silently
# undercount and this gate would read green while the frame was over.
LAST_OPS = {"return", "ireturn", "lreturn", "freturn", "dreturn", "areturn", "athrow"}


def die(msg: str):
    print("::error::%s" % msg)
    sys.exit(1)


def disassemble(classes: str) -> dict:
    """One javap call for every frame -- one per class would be a JVM startup each.

    Returned per class, NOT as one blob: the signatures are distinct across
    classes today only by luck, and a search over the concatenation would happily answer for
    the wrong class. javap also exits 0 when only SOME of the named classes
    resolve, reporting the rest on stderr, so its status says nothing and the
    stderr has to be read.
    """
    names = ["io.github.talib." + c for c in dict.fromkeys(c for c, _, _ in FRAMES)]
    try:
        p = subprocess.run(["javap", "-p", "-c", "-cp", classes] + names,
                           capture_output=True, text=True)
    except FileNotFoundError as e:
        die("javap is not on PATH: %s" % e)
    if p.returncode != 0:
        die("javap failed on %s: %s" % (classes, p.stderr.strip() or p.stdout.strip()))
    if p.stderr.strip():
        die("javap could not read every class from %s -- it exits 0 for this, so "
            "the gate must reject it explicitly: %s" % (classes, p.stderr.strip()))

    # Split on the class header javap emits once per class.
    sections, cur = {}, None
    for line in p.stdout.splitlines():
        m = re.match(r"(?:public |final |abstract )*class io\.github\.talib\.(\S+) ", line)
        if m:
            cur = m.group(1).rstrip("{").strip()
            sections[cur] = []
        elif cur is not None:
            sections[cur].append(line)
    for cls, _, _ in FRAMES:
        if cls not in sections:
            die("javap printed no section for io.github.talib.%s -- it was asked "
                "for it and did not refuse, so the disassembly parse moved." % cls)
    return sections


def code_length(sections: dict, cls: str, sig: re.Pattern) -> int:
    lines = sections[cls]
    matches = [i for i, l in enumerate(lines) if sig.match(l)]
    if len(matches) > 1:
        die("%s: %d methods match %s -- the gate cannot tell which frame it is "
            "measuring." % (cls, len(matches), sig.pattern))
    start = matches[0] if matches else None
    if start is None:
        die("%s: no method matching %s -- the signature moved, so this gate "
            "measured NOTHING. Fix the pattern in this script rather than "
            "deleting the check." % (cls, sig.pattern))

    last_off, last_op = None, None
    for l in lines[start + 1:]:
        m = re.match(r"\s+(\d+): (\S+)", l)
        if m:
            last_off, last_op = int(m.group(1)), m.group(2)
        elif last_off is not None and not l.strip():
            break
    if last_off is None:
        die("%s: matched the signature but found no bytecode under it." % cls)
    if last_op not in LAST_OPS:
        die("%s: last instruction is %r, not a 1-byte return/throw, so "
            "offset+1 is not the code length. Teach this script the real "
            "length before trusting it." % (cls, last_op))
    return last_off + 1


def main():
    if len(sys.argv) != 2:
        die("usage: check_java_inline_budget.py <classes-dir>")
    classes = sys.argv[1]

    sections = disassemble(classes)
    over = []
    for cls, method, sig in FRAMES:
        n = code_length(sections, cls, sig)
        name = "%s.%s" % (cls, method)
        print("%-24s %3d bytes (budget %d, %+d)" % (name, n, BUDGET, n - BUDGET))
        if n > BUDGET:
            over.append((name, n))

    if over:
        die("%s over C2's %d-byte FreqInlineSize: %s. Every caller holding an MA "
            "sub-handle just lost inlining on that frame, worth ~a third of its "
            "per-bar time. An N-way switch cannot stay under a fixed budget as N "
            "grows. Split an unsplit frame at FRAME_ARMS. For a Rest frame, raise "
            "FRAME_ARMS while every head frame has room, else add a third frame. "
            "Emitter: "
            "build_dispatch_peek_frame / emit_dispatch / emit_dispatch_tape in "
            "ta_codegen/generator/src/backends/java_stream.rs."
            % ("Frame" if len(over) == 1 else "Frames", BUDGET,
               ", ".join("%s at %d" % (n, b) for n, b in over)))
    print("Every MA dispatch frame is inside the %d-byte budget." % BUDGET)


if __name__ == "__main__":
    main()

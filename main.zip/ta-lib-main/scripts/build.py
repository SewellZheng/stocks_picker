#!/usr/bin/env python3

# Developer build helper for TA-Lib.
#
# The C library + C tools build with CMake (this wraps it); the Rust ta_codegen
# tool and the JSON-RPC servers build with cargo directly. The C build systems
# (CMake/autotools) never invoke cargo — building ta_codegen and the dev tools is
# this script's job.
#
# Usage:
#   scripts/build.py                Build library + all C tools (CMake)
#   scripts/build.py ta_regtest     Build the regression test runner (CMake)
#   scripts/build.py ta_codegen     Build the Rust codegen tool (cargo)
#   scripts/build.py generate       Generate every committed source for all backends (cargo)
#   scripts/build.py regen-check    The PR gate: regenerating must change nothing (cargo)
#   scripts/build.py servers        Generate + compile JSON-RPC language servers (cargo),
#                                   plus bin/ta_regtest so bin/ is runnable by hand
#   scripts/build.py libraries      Build + test the publishable Java/C#/TypeScript/Go libraries (cargo)
#   scripts/build.py wasm           Build and check bin/ta_lib.wasm (cargo)
#   scripts/build.py test           C reference regression tests
#   scripts/build.py regtest        Full cross-language regression tests
#   scripts/build.py clean          Remove build directory
#   scripts/build.py help           Show all targets

import argparse
import concurrent.futures
import json
import os
import re
import shlex
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utilities.common import (
    check_prerequisites,
    PREREQS_BUILD_BASIC, PREREQS_BUILD_CODEGEN, PREREQS_BUILD_SERVERS,
    PREREQS_CARGO, PREREQS_CMAKE, PREREQS_GCC, PREREQS_JAVAC, PREREQS_JAVA,
    PREREQS_DOTNET, PREREQS_NODE, PREREQS_GO, LIBRARY_PREREQS,
    prereqs_for_languages, backends_for_languages,
    default_build_jobs, JobServer,
)

BUILD_DIR_NAME = "cmake-build"
SANITIZE_DIR_NAME = "cmake-build-asan"
DEFAULT_BUILD_TYPE = "Release"
DEFAULT_JOBS = default_build_jobs()
JOBS = JobServer(DEFAULT_JOBS)

def positive_int(text: str) -> int:
    n = int(text)
    if n < 1:
        raise argparse.ArgumentTypeError(f"must be at least 1, got {n}")
    return n

def find_repo_root() -> str:
    """Find the git repository root, regardless of where the script is called from."""
    # Use the script's own location to find the repo, so it works even
    # when cwd is outside the repository.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--show-toplevel'],
            check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            cwd=script_dir
        )
        root = result.stdout.strip().decode('utf-8')
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("Error: Must be run from within a TA-Lib Git repository.")
        sys.exit(1)

    # Sanity check
    if not os.path.isdir(os.path.join(root, 'src', 'ta_func')):
        print("Error: Not a complete TA-Lib repository (src/ta_func missing).")
        sys.exit(1)

    return root

def ensure_configured(root_dir: str, build_dir: str, build_type: str, cmake_args: str):
    """Ensure cmake-build exists and is configured. Reconfigure if CMakeLists.txt is newer."""
    cmake_cache = os.path.join(build_dir, "CMakeCache.txt")
    cmakelists = os.path.join(root_dir, "CMakeLists.txt")
    needs_configure = False

    if not os.path.exists(cmake_cache):
        needs_configure = True
    elif os.path.getmtime(cmakelists) > os.path.getmtime(cmake_cache):
        needs_configure = True

    if needs_configure:
        os.makedirs(build_dir, exist_ok=True)
        # This script is the TA-Lib developer entry point, so it opts into the
        # benchmarks. A library consumer running cmake directly gets the default
        # (OFF) and never compiles them.
        cmd = ['cmake', root_dir, f'-DCMAKE_BUILD_TYPE={build_type}',
               '-DBUILD_BENCHMARKS=ON']
        if cmake_args:
            cmd.extend(shlex.split(cmake_args))
        subprocess.run(cmd, check=True, cwd=build_dir)

def make_joins_jobserver(build_dir: str) -> bool:
    """True when cmake --build drives GNU make 4+, the one generator here that
    reads a pipe jobserver's --jobserver-auth. Any other one gets -j instead."""
    if not JOBS.active:
        return False
    cache = {}
    try:
        with open(os.path.join(build_dir, "CMakeCache.txt"), encoding="utf-8",
                  errors="replace") as f:
            for line in f:
                key, sep, val = line.partition('=')
                if sep:
                    cache[key.split(':')[0]] = val.strip()
    except OSError:
        return False
    if cache.get('CMAKE_GENERATOR') != 'Unix Makefiles':
        return False
    try:
        out = subprocess.run([cache.get('CMAKE_MAKE_PROGRAM', 'make'), '--version'],
                             capture_output=True, text=True).stdout
    except OSError:
        return False
    m = re.match(r'GNU Make (\d+)', out)
    return bool(m) and int(m.group(1)) >= 4

def cmake_build(build_dir: str, target: str = None, jobs: int = DEFAULT_JOBS,
                config: str = None):
    """Run cmake --build, optionally for a specific target and configuration."""
    cmd = ['cmake', '--build', '.']
    if target:
        cmd.extend(['--target', target])
    if config:
        cmd.extend(['--config', config])
    if make_joins_jobserver(build_dir):
        JOBS.run(cmd, check=True, cwd=build_dir)
    else:
        subprocess.run(cmd + ['-j', str(jobs)], check=True, cwd=build_dir)

def show_help():
    print("""TA-Lib Build Targets

  Building (C, via CMake):
    (default)           Build library + all C tools
    ta_regtest          Build the regression test runner
    ta_bench_icount     Build the instruction-count bench dev-nightly's icount job runs
                        (scripts/bench_icount.py). Needs valgrind's headers to
                        measure anything; without them it still builds and only
                        --dry-run works.

  Building (Rust ta_codegen, via cargo — CMake never invokes cargo):
    ta_codegen          Build the Rust codegen tool
    generate            Generate every committed source for all backends —
                        the libraries, the JSON-RPC servers and the benches.
                        Writing only: no JDK or .NET SDK needed for the Java
                        and C# sources, only cargo.
    servers             Generate all source + compile JSON-RPC language servers,
                        and bring bin/ta_regtest — the only thing that drives
                        them — up to date, so bin/ can be run by hand
    libraries           Build the publishable Java jars, C# library, npm
                        package and Go module from the committed source and
                        run their suites against them. Generates nothing; needs
                        a JDK + unzip, the .NET SDK, Node with npm and/or Go,
                        narrowed by --language. --node=22,24,26 (or all) runs
                        the TypeScript suite once per pinned Node major
                        instead. Go runs with the module's floor toolchain
                        (scripts/go_toolchain.py 1.22) and with the Go on PATH.
    wasm                Build bin/ta_lib.wasm from the committed ta_codegen/output/wasm
                        crate for wasm32-unknown-unknown, then fail unless it
                        imports nothing and its only relaxed-SIMD instruction
                        is f64x2.relaxed_madd. Generates nothing; needs the
                        pinned toolchain's wasm32-unknown-unknown target.
    format              Re-indent the ta_codegen/input/ C source of truth
    format-check        Verify inputs are formatted (fails if not); writes nothing
    clippy              Lint both Rust crates as the dev nightly does
                        (--all-targets -D warnings). Dev profile, so it shares
                        no artifacts with the --release targets and does not
                        trigger rebuilds.

  Testing:
    test                C reference regression tests
    regen-check         The gate every PR runs: input formatted, source lists
                        agree, and regenerating changes nothing that is
                        committed. Cargo + Python only — no JDK, no .NET SDK.
                        Only drift this run introduces fails it, so it is
                        usable on a dirty working tree.
    check-stream-retcodes
                        Verify every history-length arm, in all four backends,
                        answers TA_INSUFFICIENT_HISTORY (rS7), for a short
                        history and for an empty one. Pure text; also run as
                        part of regen-check.
    check-source-lists  Verify the CMake and autotools ta_regtest source
                        lists agree and every test group they compile is
                        called by ta_regtest.c (no build; pure text check)
    check-cargo-lock    Verify both committed Cargo.lock files still satisfy
                        their manifests (resolve only, no build). Also the
                        first thing regen-check does, because any later cargo
                        call repairs a stale lock silently.
    check-mcdc          Verify each MC/DC builder's pb_conditions(N) matches the
                        conjunct count of the indicator it tests (no build; pure
                        text check). Catches a builder that under-declares, and
                        a conjunct added to an indicator that no case covers.
    check-candle-windows
                        Verify every candlestick reads each trailing total at the
                        bar it accumulates (no build; pure text check). Catches a
                        crossed window -- the right setting averaged over the
                        wrong ten bars -- which MC/DC cannot see (pb_primer's
                        bars are identical) and the differential gates see only
                        where the data happens to straddle.
    regtest             Full pipeline: servers (cargo) + C tests + codegen verification
    refdata             Build ta_refdata and refresh the reference CSVs the
                        function pages chart (website/src/.vuepress/public/
                        functions/<name>.csv) from src/tools/ta_refdata/corpus.
                        A file is rewritten only when missing or out of
                        tolerance; a CSV naming no function is removed.
                        --check writes nothing there and fails on a file
                        out of tolerance, missing or stale, then writes a
                        fresh set under the build dir and replays each from
                        its own rows (ta_refdata --replay), failing on a cell
                        that does not reproduce bit for bit.
    ref                 Differential fuzz of the current library vs each frozen
                        release in ta_ref/ (builds bin/ta_ref_<X_Y_Z>_serve, then
                        runs ta_regtest --ref=<X_Y_Z> per member). C-only; needs
                        the release tags. --versions=0_8_1[,...] narrows it;
                        --build-only stops after the serves.
    xlang-hash          Cross-language BITWISE parity gate (opt-in; issue #113):
                        builds the Rust + Java + C# + TypeScript + Go servers +
                        ta_regtest, then runs ta_regtest --xlang-hash — diffs each
                        language server vs the in-process C library (Rust and Go
                        via seed inputs, the others via lossless hex inputs) with
                        no tolerance, except the Java, C#, TypeScript and Go calls
                        that reach a transcendental (their math is not the C libm).
                        Needs the JDK, the .NET SDK, Node and Go.

  Other:
    clean               Remove cmake-build/ and cmake-build-asan/
    help                Show this message

  Options:
    --build-type=Debug  Set cmake build type (default: Release)
    --jobs=8            Parallel jobs shared by cargo and make; gcc's LTO
                        takes a share of the same count (default: up to 16,
                        fewer on a small or busy host)
    --cmake-args="..."  Extra arguments passed to cmake configure
    --language=c,rust   For servers/regtest/xlang-hash: build only
                        these backends (c, rust, java, csharp, ts, go), and require
                        only their toolchains (tswasm builds ts and selects
                        ta_regtest's WASM-engine run of its server). A machine
                        with no JDK, .NET SDK or Node can still run
                        `servers --language=c,rust`. Omit
                        it and every backend is built, which needs all of them
                        (a missing Go is fetched by scripts/go_toolchain.py).
    --node=all          For libraries: run the TypeScript suite once per listed
                        Node major, each from scripts/node_toolchain.py (fetched
                        on first use), so no system Node is needed
    --sanitize          Build with AddressSanitizer + UBSan into cmake-build-asan
                        (Debug, static-only; e.g. build.py ta_regtest --sanitize)
    --check             For refdata: compare the committed CSVs, write nothing
""")

def run_codegen(root_dir: str, *cargo_args: str, path_prefix: str = None):
    """Run a cargo command in the ta_codegen generator crate.

    This is how ta_codegen (Rust) is built/run — directly via cargo, never through
    CMake. Keeps the C build systems free of any Rust/cargo dependency.
    """
    codegen_dir = os.path.join(root_dir, "ta_codegen", "generator")
    if path_prefix is None:
        JOBS.run(['cargo', *cargo_args], check=True, cwd=codegen_dir)
        return
    env = dict(JOBS.env, PATH=path_prefix + os.pathsep + JOBS.env.get('PATH', ''))
    subprocess.run(['cargo', *cargo_args], env=env, pass_fds=JOBS.fds, check=True,
                   cwd=codegen_dir)

def run_clippy(root_dir: str):
    """Lint both Rust crates exactly as the dev nightly's clippy job does.

    `-D warnings` is not optional here. The generator already denies
    clippy::pedantic on itself, but the remaining lints are warn-level: without
    the flag a local run prints them and still exits 0, so it would not be the
    same gate CI applies and a "clean" local run could still fail the nightly.

    Deliberately the dev profile, not --release. Clippy fingerprints differ from
    a plain build, so `cargo clippy --release` would share target/release with
    `build.py generate` and force a full rebuild on every alternation between
    the two. On the dev profile they use separate trees and neither invalidates
    the other (measured: build/clippy/build alternates in well under a second
    when nothing changed).
    """
    for manifest in ('ta_codegen/generator/Cargo.toml',
                     'ta_codegen/output/rust/Cargo.toml'):
        print(f"  Clippy {manifest} ...")
        JOBS.run(
            ['cargo', 'clippy', '--all-targets', '--manifest-path', manifest,
             '--', '-D', 'warnings'],
            check=True, cwd=root_dir)
    print("  Clippy clean (generator + generated crate).")


def build_servers(root_dir: str, lang_filter=None, alongside=None):
    """Generate the JSON-RPC language servers and compile them (cargo).

    With a --language filter only those backends are generated and built, so a
    machine without the JDK or the .NET SDK is not forced to have them just to
    exercise C and Rust (issue #150, extended from regtest.py to build.py).

    `alongside` runs while the servers compile. It must not read what
    generate-servers writes or write what the server builds read."""
    backends = backends_for_languages(lang_filter)
    extra = [f'--backend={backends}'] if backends else []
    run_codegen(root_dir, 'run', '--release', '--', 'generate-servers', *extra)
    # The TypeScript server's build refuses a stale bin/ta_lib.wasm.
    if 'ts' in (backends or 'ts').split(',') and build_wasm(root_dir) != 0:
        sys.exit(1)
    if alongside is None:
        run_codegen(root_dir, 'run', '--release', '--', 'build', *extra)
        return
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        servers = pool.submit(run_codegen, root_dir, 'run', '--release', '--',
                              'build', *extra)
        alongside()
        servers.result()

def pinned_node_majors(root_dir: str, node: str):
    """The majors `--node` names, or None after printing why it is invalid."""
    with open(os.path.join(root_dir, 'scripts', 'node_toolchain.json'), encoding='utf-8') as f:
        pinned = sorted(json.load(f)['versions'], key=int)
    majors = pinned if node == 'all' else [m.strip() for m in node.split(',') if m.strip()]
    unknown = [m for m in majors if m not in pinned]
    if not majors or unknown:
        print(f"Error: --node={node} names no pinned Node major "
              f"(pinned: {', '.join(pinned)}, or all).", flush=True)
        return None
    return majors

def build_go_library(root_dir: str) -> int:
    """The Go module with its floor toolchain, then with the Go on PATH when that
    is another one."""
    found = subprocess.run([sys.executable, os.path.join(root_dir, 'scripts', 'go_toolchain.py'), '1.22'],
                           stdout=subprocess.PIPE, text=True, check=False)
    floor = found.stdout.strip()
    if found.returncode or not floor:
        print("Error: scripts/go_toolchain.py 1.22 found no floor toolchain.", flush=True)
        return 1
    path_go = shutil.which('go')
    toolchains = [('floor toolchain', floor)]
    if path_go and os.path.realpath(os.path.dirname(path_go)) != os.path.realpath(floor):
        toolchains.append(('Go on PATH', os.path.dirname(path_go)))
    for label, prefix in toolchains:
        print(f"\n--- Go library, {label} ({prefix})", flush=True)
        try:
            run_codegen(root_dir, 'run', '--release', '--', 'build-libraries', '--backend=go',
                        path_prefix=prefix)
        except subprocess.CalledProcessError:
            return 1
    return 0

def build_libraries(root_dir: str, lang_filter=None, node=None) -> int:
    """Build the publishable Java/C#/TypeScript/Go libraries and run their suites (issue #428).

    Builds the COMMITTED source and generates nothing, so after editing
    ta_codegen/input/ run `generate` first or this tests the previous tree."""
    picked = library_backends(lang_filter)
    if not picked:
        print(f"Error: --language={lang_filter} selects no backend with a publishable "
              f"library (valid: {', '.join(LIBRARY_PREREQS)}).", flush=True)
        return 2
    if 'go' in picked:
        if build_go_library(root_dir) != 0:
            return 1
        picked = [b for b in picked if b != 'go']
        if not picked:
            return 0
    # The npm package carries bin/ta_lib.wasm, and its build refuses a stale one.
    if 'ts' in picked and build_wasm(root_dir) != 0:
        return 1
    if not node:
        run_codegen(root_dir, 'run', '--release', '--', 'build-libraries',
                    f'--backend={",".join(picked)}')
        return 0
    if 'ts' not in picked:
        print(f"Error: --node selects Node versions for the TypeScript library, and "
              f"--language={lang_filter} does not build it.", flush=True)
        return 2
    majors = pinned_node_majors(root_dir, node)
    if majors is None:
        return 2
    others = [b for b in picked if b != 'ts']
    if others:
        run_codegen(root_dir, 'run', '--release', '--', 'build-libraries',
                    f'--backend={",".join(others)}')
    failed = []
    for major in majors:
        found = subprocess.run([sys.executable, os.path.join(root_dir, 'scripts', 'node_toolchain.py'),
                                major], stdout=subprocess.PIPE, text=True, check=False)
        node_bin = found.stdout.strip()
        if found.returncode or not node_bin:
            failed.append(major)
            continue
        print(f"\n--- TypeScript library, pinned Node {major} ({node_bin})", flush=True)
        try:
            run_codegen(root_dir, 'run', '--release', '--', 'build-libraries', '--backend=ts',
                        path_prefix=node_bin)
        except subprocess.CalledProcessError:
            failed.append(major)
    if failed:
        print(f"\nError: the TypeScript library FAILED on Node {', '.join(failed)}.", flush=True)
        return 1
    return 0
    return 0

WASM_TARGET = 'wasm32-unknown-unknown'
# The no-vectorize flags are load-bearing for values, not a performance choice.
WASM_RUSTFLAGS = ['-C', 'target-feature=+simd128,+relaxed-simd',
                  '-C', 'no-vectorize-loops', '-C', 'no-vectorize-slp',
                  '-C', 'link-arg=--compress-relocations']

def build_wasm(root_dir: str) -> int:
    """Builds bin/ta_lib.wasm from the committed crate and checks it."""
    def target_installed():
        sysroot = subprocess.run(['rustc', '--print', 'sysroot'], cwd=root_dir,
                                 capture_output=True, text=True)
        return sysroot.returncode == 0 and os.path.isdir(
            os.path.join(sysroot.stdout.strip(), 'lib', 'rustlib', WASM_TARGET, 'lib'))
    # A toolchain installed before rust-toolchain.toml listed the target lacks it.
    if not target_installed() and shutil.which('rustup'):
        subprocess.run(['rustup', 'target', 'add', WASM_TARGET], cwd=root_dir)
    if not target_installed():
        print(f"Error: the Rust target {WASM_TARGET} is not installed for the toolchain "
              f"rust-toolchain.toml pins. Install it with 'rustup target add {WASM_TARGET}' "
              f"from the repository root.", flush=True)
        return 1
    crate = os.path.join(root_dir, 'ta_codegen', 'output', 'wasm')
    # Panic locations embed source paths; the shipped module must not carry the build machine's.
    rustflags = WASM_RUSTFLAGS + [f'--remap-path-prefix={root_dir}=/ta-lib']
    env = dict(JOBS.env, CARGO_ENCODED_RUSTFLAGS='\x1f'.join(rustflags))
    env.pop('RUSTFLAGS', None)
    out = os.path.join(root_dir, 'bin', 'ta_lib.wasm')
    # Whatever fails below, no earlier module stays behind looking fresher than the sources.
    if os.path.exists(out):
        os.remove(out)
    try:
        subprocess.run(['cargo', 'build', '--release', '--target', WASM_TARGET,
                        '--manifest-path', os.path.join(crate, 'Cargo.toml')],
                       env=env, pass_fds=JOBS.fds, check=True, cwd=root_dir)
    except subprocess.CalledProcessError:
        return 1
    built = os.path.join(crate, 'target', WASM_TARGET, 'release', 'ta_lib_wasm.wasm')
    staged = out + '.tmp'
    os.makedirs(os.path.dirname(out), exist_ok=True)
    shutil.copyfile(built, staged)
    os.replace(staged, out)
    rc = subprocess.run([sys.executable, os.path.join(root_dir, 'scripts', 'check_wasm_module.py'),
                         out]).returncode
    if rc:
        os.remove(out)
    return rc

def build_ref(root_dir: str, build_dir: str, jobs: int, versions, build_only: bool) -> int:
    """Builds the serve of every selected member of ta_ref/ (all by default),
    then runs `ta_regtest --ref=<v>` once per member: one process each, so no
    driver state carries from one release to the next. C-only."""
    from utilities import ta_ref
    try:
        selected = ta_ref.select(root_dir, versions)
        for v in selected:
            ta_ref.build_serve(root_dir, build_dir, v)
    except ta_ref.RefError as e:
        print(f"Error: {e}")
        return 1
    if build_only:
        return 0
    cmake_build(build_dir, target='ensure_ta_regtest_in_bin', jobs=jobs)
    failed = []
    for v in selected:
        print(f"=== ta_regtest --ref={v} ===", flush=True)
        # The serve's argv is relative ("./ta_ref_<v>_serve"): cwd must be bin/.
        if subprocess.run([os.path.join(root_dir, "bin", "ta_regtest"), f"--ref={v}"],
                          cwd=os.path.join(root_dir, "bin")).returncode != 0:
            failed.append(v)
    print(f"ref: {len(selected) - len(failed)}/{len(selected)} member(s) passed"
          + (f"; FAILED: {', '.join(failed)}" if failed else ""))
    return 1 if failed else 0

REFDATA_CORPUS = os.path.join('src', 'tools', 'ta_refdata', 'corpus')
REFDATA_OUT = os.path.join('website', 'src', '.vuepress', 'public', 'functions')

def build_refdata(root_dir: str, build_dir: str, jobs: int, build_type: str,
                  check: bool) -> int:
    """Builds ta_refdata and runs it over the committed corpus into the website's
    public/functions directory; --check compares and writes nothing there, then
    replays a freshly written set from its own rows."""
    if not os.path.isfile(os.path.join(root_dir, 'src', 'tools', 'ta_refdata', 'ta_refdata.c')):
        print("Error: src/tools/ta_refdata is not in this tree (it is not part of the "
              "released source tarball); refdata needs a git checkout.")
        return 1
    cmake_build(build_dir, target='ta_refdata', jobs=jobs, config=build_type)
    exe = 'ta_refdata' + ('.exe' if os.name == 'nt' else '')
    candidates = [os.path.join(build_dir, 'bin', exe),
                  os.path.join(build_dir, 'bin', build_type, exe)]
    binary = next((c for c in candidates if os.path.exists(c)), None)
    if binary is None:
        print(f"Error: ta_refdata was built but not found at {' or '.join(candidates)}")
        return 1
    out_dir = os.path.join(root_dir, REFDATA_OUT)
    os.makedirs(out_dir, exist_ok=True)
    cmd = [binary] + (['--check'] if check else []) + \
          [os.path.join(root_dir, REFDATA_CORPUS), out_dir]
    print(f"=== {' '.join(os.path.relpath(c, root_dir) if c.startswith(root_dir) else c for c in cmd)} ===",
          flush=True)
    rc = subprocess.run(cmd).returncode
    if rc != 0:
        return rc
    if not check:
        # The pages and charts are rendered from the CSVs just written.
        run_codegen(root_dir, 'run', '--release', '--', 'generate')
        return 0
    # The committed CSVs were computed on another machine, and replay compares
    # bits, so it replays a set written here; --check above holds the committed
    # ones to the tolerance.
    fresh = os.path.join(build_dir, 'refdata-replay')
    shutil.rmtree(fresh, ignore_errors=True)
    os.makedirs(fresh)
    p = subprocess.run([binary, os.path.join(root_dir, REFDATA_CORPUS), fresh],
                       capture_output=True, text=True)
    if p.returncode != 0:
        print(p.stdout + p.stderr, end='')
        return p.returncode
    csvs = sorted(os.path.join(fresh, f) for f in os.listdir(fresh) if f.endswith('.csv'))
    print(f"=== ta_refdata --replay ({len(csvs)} files) ===", flush=True)
    for i in range(0, len(csvs), 50):
        p = subprocess.run([binary, '--replay'] + csvs[i:i + 50], capture_output=True, text=True)
        if p.returncode != 0:
            print(p.stdout + p.stderr, end='')
            print("Error: a reference CSV does not reproduce from its own rows.")
            return 1
    return 0

def build_xlanghash(root_dir: str, build_dir: str, jobs: int, lang_filter=None) -> int:
    """Cross-language BITWISE parity gate (issue #113). Diffs each generated
    language server against the shipped in-process C library, comparing
    full-precision output hashes with NO tolerance. Builds the Rust + Java + C#
    + TypeScript servers + ta_regtest, then runs `ta_regtest --xlang-hash`.
    Returns ta_regtest's exit code (non-zero on any divergence). Rust crosses the
    JSON boundary with a seed (gen_present); Java, C# and TypeScript cross it with
    lossless hex-bits inputs (#114). Those three relax their transcendental-using
    calls to their language's bound (fdlibm != the C libm; neither .NET nor a JS
    engine guarantees Math.* reaches the platform libm). Needs the JDK, the .NET
    SDK and Node.

    --language narrows the gate to a subset of those rows, so a machine with no
    JDK, .NET SDK or Node can still run the Rust leg. C is never a COMPARISON row here
    — it is the in-process golden every row is compared against — so it is
    dropped from the filter rather than being diffed against itself.
    The filter is ALSO forwarded to ta_regtest: without it the runner would try
    to spawn the servers we deliberately did not build and merely print that
    they are unavailable, turning a narrowed run into a quietly vacuous one.
    CI passes no filter, so the nightly always runs every row.

    The C SERVER is nonetheless built on an unfiltered run, because one leg of
    the gate does consult it: the array-transport self-check (#257/#258) asks
    each server for a plain array and re-hashes it against that same server's
    own out_hash — a property of the server's wire format, which for C is
    reachable no other way. A narrowed run skips it along with everything else
    the filter excludes.
    """
    rows = [b for b in (backends_for_languages(lang_filter) or 'rust,java,csharp,ts,go').split(',')
            if b in ('rust', 'java', 'csharp', 'ts', 'go')]
    if not rows:
        print(f"Error: --language={lang_filter} selects no xlang-hash row "
              f"(valid: rust, java, csharp, ts, tswasm, go; C is the in-process golden).", flush=True)
        return 2
    backends = ','.join(rows)
    servers = ','.join(t for t in dict.fromkeys(s.strip().lower() for s in (lang_filter or '').split(','))
                       if t in ('rust', 'java', 'csharp', 'ts', 'tswasm', 'go'))
    if lang_filter:
        # flush: this script's stdout is block-buffered when CI captures it,
        # while the cargo/ta_regtest subprocesses write straight to the pipe —
        # without it these lines land after the output they are labelling.
        print(f"=== xlang-hash limited to: {servers} ===", flush=True)
    # 1. Generate + compile the language servers into bin/ — plus the C server
    #    for the array-transport leg (see the note above). --servers-only
    #    because the C backend arm otherwise also builds ta_bench_cg and
    #    ta_bench_stream: two more whole-library -flto compiles this gate never
    #    talks to, on the same failure counter, so a bench-only break would
    #    fail the parity nightly.
    built = backends if lang_filter else backends + ',c'
    run_codegen(root_dir, 'run', '--release', '--', 'generate-servers', f'--backend={built}')
    if 'ts' in rows and build_wasm(root_dir) != 0:
        return 1
    run_codegen(root_dir, 'run', '--release', '--', 'build', f'--backend={built}',
                '--servers-only')
    # 2. The C test runner links the in-process C golden; stage it into bin/.
    cmake_build(build_dir, target='ensure_ta_regtest_in_bin', jobs=jobs)
    # 3. Run the gate (server argv is relative "./", so cwd must be bin/).
    print("=== Running ta_regtest --xlang-hash ===", flush=True)
    cmd = [os.path.join(root_dir, "bin", "ta_regtest"), "--xlang-hash"]
    if lang_filter:
        cmd.append(f"--language={servers}")
    return subprocess.run(cmd, cwd=os.path.join(root_dir, "bin")).returncode

# The two cargo workspaces with a committed Cargo.lock. Both manifests are
# themselves generated (the generator writes ta_codegen/output/rust/**), so a
# dependency edit in the generator lands as a manifest change with no lock to
# match it.
CARGO_LOCK_MANIFESTS = (
    os.path.join('ta_codegen', 'generator', 'Cargo.toml'),
    os.path.join('ta_codegen', 'output', 'rust', 'Cargo.toml'),
)

def check_cargo_locks(root_dir: str) -> bool:
    """Verify each committed Cargo.lock still satisfies its manifests.

    Must run BEFORE any other cargo command: cargo repairs a stale lock in
    place and says nothing, so once `format --check` or a `cargo test` has run
    the drift is gone from the tree and the answer is always yes. That is why
    the drift survived every gate until now -- regen-check's own baseline is
    taken after its first cargo call, so a repaired lock lands in the
    "already modified" set and is excluded from the comparison.

    `cargo metadata` only resolves; it compiles nothing.
    """
    ok = True
    for rel in CARGO_LOCK_MANIFESTS:
        print(f"  {rel}", flush=True)
        if subprocess.run(
                ['cargo', 'metadata', '--locked', '--format-version', '1',
                 '--manifest-path', os.path.join(root_dir, rel)],
                stdout=subprocess.DEVNULL).returncode != 0:
            lock = os.path.join(os.path.dirname(rel), 'Cargo.lock')
            print(f"Error: {lock} does not match {rel} (cargo's own message is "
                  f"above). Refresh it with 'cargo metadata --manifest-path "
                  f"{rel} >/dev/null' -- which updates nothing but what the "
                  f"manifests now demand -- and commit the result.")
            ok = False
    return ok

def check_regtest_source_lists(root_dir: str) -> bool:
    """Verify the two hand-maintained ta_regtest source lists agree.

    ta_regtest is built by BOTH build systems: CMake (TA_REGTEST_SOURCES in
    CMakeLists.txt, used by the local dev loop and the cross-language CI job)
    and autotools (ta_regtest_SOURCES in src/tools/ta_regtest/Makefile.am,
    used by the dist "end-user simulation" nightly). The lists are maintained
    by hand in parallel: a file added to only one of them compiles fine under
    CMake locally and then breaks the autotools nightly. Returns True when
    the lists are identical, cover ta_test_func/, and every test group they
    compile has its DO_TEST row.
    """
    import re

    cmake_path = os.path.join(root_dir, 'CMakeLists.txt')
    with open(cmake_path, encoding='utf-8') as f:
        cmake_text = f.read()
    m = re.search(r'set\(TA_REGTEST_SOURCES\n(.*?)\n\s*\)', cmake_text, re.S)
    if not m:
        print("Error: TA_REGTEST_SOURCES block not found in CMakeLists.txt")
        return False
    cmake_set = set()
    for line in m.group(1).splitlines():
        entry = line.strip().strip('"')
        if not entry:
            continue
        cmake_set.add(entry.replace(
            '${CMAKE_CURRENT_SOURCE_DIR}/src/tools/ta_regtest/', ''))

    am_path = os.path.join(root_dir, 'src', 'tools', 'ta_regtest', 'Makefile.am')
    am_set = set()
    with open(am_path, encoding='utf-8') as f:
        lines = f.readlines()
    i = 0
    while i < len(lines):
        if lines[i].lstrip().startswith('ta_regtest_SOURCES'):
            block = lines[i].split('=', 1)[1]
            while block.rstrip().endswith('\\') and i + 1 < len(lines):
                block = block.rstrip().rstrip('\\') + ' '
                i += 1
                block += lines[i]
            am_set.update(block.rstrip().rstrip('\\').split())
            break
        i += 1
    if not am_set:
        print(f"Error: ta_regtest_SOURCES block not found in {am_path}")
        return False

    ok = True
    lists = [('CMakeLists.txt TA_REGTEST_SOURCES', cmake_set),
             ('src/tools/ta_regtest/Makefile.am ta_regtest_SOURCES', am_set)]
    union = set()
    for _, entries in lists:
        union |= entries
    for name, entries in lists:
        missing = sorted(union - entries)
        for entry in missing:
            print(f"Error: missing from {name}: {entry}")
            ok = False
    if not ok:
        print("Add the missing entries so all build systems compile the same files.")
        return False

    # A file in NEITHER list compiles nowhere and runs nowhere, so every
    # runtime floor in ta_regtest is blind to it by construction -- including
    # the one that requires each test group to reach server_verify. The two
    # lists agreeing is not enough; they have to cover the directory.
    func_dir = os.path.join(root_dir, 'src', 'tools', 'ta_regtest', 'ta_test_func')
    on_disk = {f'ta_test_func/{name}'
               for name in os.listdir(func_dir) if name.endswith('.c')}
    orphans = sorted(on_disk - union)
    if orphans:
        for entry in orphans:
            print(f"Error: {entry} exists but is in no ta_regtest source list, "
                  f"so nothing compiles or runs it")
        return False

    # A group that is compiled and never called links cleanly and fails
    # nothing: the runtime floors only judge a group that ran.
    regtest_dir = os.path.dirname(func_dir)
    with open(os.path.join(regtest_dir, 'ta_regtest.c'), encoding='utf-8') as f:
        runner = re.sub(r'"(?:\\.|[^"\\\n])*"|/\*.*?\*/|//[^\n]*',
                        lambda m: m.group(0) if m.group(0)[0] == '"' else '',
                        f.read(), flags=re.S)
    registered = set(re.findall(r'\bDO_TEST\w*\(\s*(\w+)\s*,', runner))
    groups = 0
    for entry in sorted(e for e in union if e.endswith('.c')):
        with open(os.path.join(regtest_dir, entry), encoding='utf-8') as f:
            defined = re.findall(
                r'^(?:extern\s+)?ErrorNumber\s+(\w+)\s*'
                r'\(\s*(?:const\s+)?TA_History\b[^;{,)]*\)[^;{]*\{',
                f.read(), re.M)
        if not defined and entry in on_disk:
            print(f"Error: {entry} defines no group this check can see. A group "
                  f"is a non-static 'ErrorNumber <name>( TA_History * )'.")
            ok = False
        for name in defined:
            groups += 1
            if name not in registered:
                print(f"Error: {entry} defines {name}, which no DO_TEST row in "
                      f"ta_regtest.c calls, so the group never runs")
                ok = False
    if not ok:
        return False

    print(f"ta_regtest source lists agree across CMake and autotools "
          f"({len(cmake_set)} files) and cover every ta_test_func/*.c; "
          f"each of their {groups} groups has a DO_TEST row. OK.")
    return True


# --- The regeneration gate ------------------------------------------------
#
# `ta_codegen/input/` is the source of truth; everything it produces is
# committed. The gate is therefore: regenerate, and the tree must not move.
#
# It runs on every PR (.github/workflows/pr-codegen-gate.yml) and again nightly
# on dev — the nightly still matters because dev also takes direct pushes, which
# no pull_request trigger sees. Cargo and Python only: writing a .java or .cs
# source is text emission, so no contributor needs a JDK or the .NET SDK to pass
# this (compiling those servers does, and that stays in the nightly).
PROBE_MARK = '/* regen-gate probe */'

# One file per generated tier, dirtied BEFORE regenerating. "Tree still clean"
# is otherwise silent about a file the generator never writes at all: that is
# exactly how a stale TaCodegenServe.java passed this gate for months (#211),
# back when `generate` did not own the servers. A surviving probe means the
# generator dropped that path.
REGEN_PROBE_FILES = (
    'src/ta_func/ta_SMA.c',
    'src/ta_abstract/tables/table_s.c',
    'ta_codegen/output/rust/library/src/ta_func/sma.rs',
    'ta_codegen/output/csharp/library/src/Core_SMA.cs',
    'ta_codegen/output/ts/library/src/func/sma.ts',
    'ta_codegen/output/ts/library/src/engine/func/sma.ts',
    'ta_codegen/output/wasm/src/lib.rs',
    'ta_codegen/output/go/sma.go',
    'ta_codegen/output/go/enums.go',
    'ta_codegen/output/go/example_test.go',
    'ta_codegen/output/go/metadata/functions.go',
    'ta_codegen/output/c/tools/ta_codegen_serve.c',
    'ta_codegen/output/java/tools/TaCodegenServe.java',
    'ta_codegen/output/csharp/tools/TaCodegenServe.cs',
    'ta_codegen/output/rust/tools/src/bin/ta_codegen_serve.rs',
    'ta_codegen/output/ts/tools/taCodegenServe.ts',
    'ta_codegen/output/go/tools/ta_codegen_serve.go',
    'ta_codegen/output/go/tools/go.mod',
    'ta_codegen/output/c/tools/ta_bench_cg.c',
    'ta_codegen/output/c/tools/ta_bench_stream.c',
    'ta_codegen/output/c/tools/ta_bench_icount.c',
    'website/src/functions/sma.md',
    'website/src/.vuepress/public/functions/sma.svg',
    'src/tools/ta_refdata/ta_refdata_domains.h',
    'src/tools/ta_examples/ta_examples.c',
    'ta_codegen/output/java/library/src/test/java/io/github/talib/test/ExamplesTest.java',
    'ta_codegen/output/csharp/library/test/ExamplesTest.g.cs',
)

# These two are SPLICED, not rewritten: everything outside the GENCODE markers
# is hand-written and preserved on purpose, so a probe appended at EOF survives
# a perfectly healthy generator and the gate would be red forever. Probe inside
# the section instead.
REGEN_PROBE_SPLICED = (
    'ta_codegen/output/java/library/src/main/java/io/github/talib/Core.java',
    'include/ta_defs.h',
)
GENCODE_START = 'START GENCODE SECTION 1'

def _git_dirty(root_dir: str) -> set:
    """Repo-relative paths git currently reports as modified/untracked."""
    out = subprocess.run(['git', 'status', '--porcelain'], cwd=root_dir,
                         capture_output=True, text=True, check=True).stdout
    return {line[3:].strip().strip('"') for line in out.splitlines() if line.strip()}

def _write_probes(root_dir: str) -> bool:
    """Dirty one file per generated tier. False if a probe path has moved."""
    for rel in REGEN_PROBE_FILES:
        path = os.path.join(root_dir, rel)
        if not os.path.isfile(path):
            print(f"Error: regen-gate probe {rel} does not exist — the path moved; "
                  f"update REGEN_PROBE_FILES.")
            return False
        with open(path, 'a', encoding='utf-8') as f:
            f.write(f"\n{PROBE_MARK}\n")
    for rel in REGEN_PROBE_SPLICED:
        path = os.path.join(root_dir, rel)
        try:
            with open(path, encoding='utf-8') as f:
                lines = f.readlines()
        except OSError:
            print(f"Error: regen-gate probe {rel} does not exist — the path moved; "
                  f"update REGEN_PROBE_SPLICED.")
            return False
        for i, line in enumerate(lines):
            if GENCODE_START in line:
                lines.insert(i + 1, PROBE_MARK + '\n')
                break
        else:
            print(f"Error: regen-gate probe: no '{GENCODE_START}' marker in {rel} — "
                  f"update REGEN_PROBE_SPLICED.")
            return False
        with open(path, 'w', encoding='utf-8') as f:
            f.writelines(lines)
    return True

def _surviving_probes(root_dir: str, was_dirty: set) -> list:
    """Probed files the generator did not rewrite. Restores the ones it is safe
    to restore — a file already dirty before the run is the developer's, not
    ours, so that one is reported instead of reverted."""
    survivors = []
    for rel in REGEN_PROBE_FILES + REGEN_PROBE_SPLICED:
        path = os.path.join(root_dir, rel)
        try:
            with open(path, encoding='utf-8') as f:
                if PROBE_MARK not in f.read():
                    continue
        except OSError:
            continue
        survivors.append(rel)
        if rel in was_dirty:
            print(f"  NOTE: {rel} was already modified before this run — remove the "
                  f"'{PROBE_MARK}' line by hand.")
        else:
            subprocess.run(['git', 'checkout', '--', rel], cwd=root_dir, check=False)
    return survivors

def check_stream_retcodes(root_dir: str) -> bool:
    """The two history-length rules answer the same code in all four backends.

    A separate script because it reads the GENERATED output rather than the
    input, and because it is the only check here that is cross-backend by
    construction. See its docstring for why it is structural and not a probe.
    """
    return subprocess.run(
        [sys.executable, os.path.join(root_dir, 'scripts', 'check_stream_retcodes.py')]
    ).returncode == 0


def regen_check(root_dir: str) -> int:
    """Verify the committed generated output matches ta_codegen/input/.

    The same gate CI runs, runnable locally before you commit. Only drift this
    run INTRODUCES fails it: whatever was already modified in the working tree
    stays out of the comparison, so a dirty tree does not make it useless (CI
    checks out clean, where the baseline is empty and every path is gated).
    """
    # First, and before any cargo call -- see check_cargo_locks' docstring.
    print("=== Committed Cargo.lock files ===")
    if not check_cargo_locks(root_dir):
        return 1

    if not check_regtest_source_lists(root_dir):
        return 1

    print("\n=== History-length return codes (rule rS7) ===")
    if not check_stream_retcodes(root_dir):
        return 1

    print("\n=== ta_codegen/input formatting ===")
    if subprocess.run(['cargo', 'run', '--release', '--', 'format', '--check'],
                      cwd=os.path.join(root_dir, 'ta_codegen', 'generator')).returncode != 0:
        print("Error: ta_codegen/input is not formatted. "
              "Run 'scripts/build.py format' and commit the result.")
        return 1

    was_dirty = _git_dirty(root_dir)
    if was_dirty:
        print(f"\nNote: {len(was_dirty)} path(s) already modified — excluded from the "
              f"comparison below.")

    print("\n=== Regenerating every backend ===")
    if not _write_probes(root_dir):
        return 1
    # From here the tree carries probe lines, so every exit has to go through the
    # cleanup — including a generator that fails (the likeliest reason to be
    # running this) and a Ctrl-C. Otherwise the run leaves 13 stray comments
    # behind, two of them spliced INTO Core.java and ta_defs.h.
    generate_failed = False
    try:
        run_codegen(root_dir, 'run', '--release', '--', 'generate')
    except subprocess.CalledProcessError:
        generate_failed = True
    finally:
        survivors = _surviving_probes(root_dir, was_dirty)

    if generate_failed:
        # Every probe survives a generator that never ran, so the survivor list
        # says nothing here — don't read it as the #211 blindness below.
        print("\nError: `generate` failed (see its output above). The probe lines are "
              "reverted, but a failed run can leave the rest of the tree half-written — "
              "it cleans stale output before it writes — so re-run "
              "'scripts/build.py generate' once the generator is fixed.")
        return 1

    rc = 0
    if survivors:
        print("\nError: 'generate' does not write these files at all, so the "
              "regeneration gate is blind to them (#211):")
        for rel in survivors:
            print(f"  {rel}")
        print("Fix the generator — not the file.")
        rc = 1

    new_drift = sorted(_git_dirty(root_dir) - was_dirty - set(survivors))
    if new_drift:
        print("\nError: regenerating changed the committed output. Run "
              "'scripts/build.py generate' and commit the result:")
        for rel in new_drift:
            print(f"  {rel}")
        print("\n----- git diff -----")
        subprocess.run(['git', '--no-pager', 'diff', '--'] + new_drift, cwd=root_dir,
                       check=False)
        rc = 1

    if rc == 0:
        print("\nta_codegen output matches the committed source. OK.")
    return rc

# Rust targets run cargo directly (no CMake).
CARGO_TARGETS = {'ta_codegen', 'generate', 'format', 'format-check', 'clippy',
                 'regen-check', 'libraries', 'wasm'}

# C targets map to a cmake target.
#
# `servers` is here rather than in CARGO_TARGETS because it stages bin/: it
# compiles the language servers with cargo AND brings bin/ta_regtest — the only
# thing that ever drives them — up to date, so bin/ is never left holding fresh
# servers next to a runner built before the function list changed. `xlang-hash`
# and `ref` already pair the two the same way. CMake decides whether there
# is anything to rebuild, so the added step is a no-op on an unchanged tree, and
# cmake was already a prerequisite of `servers` for every --language filter.
SIMPLE_TARGETS = {
    'ta_regtest':      'ensure_ta_regtest_in_bin',
    'servers':         'ensure_ta_regtest_in_bin',
    'test':            'ensure_ta_regtest_in_bin',
    'regtest':         'regtest',
    # stage_benchmarks, not the raw target: bin/ is where bench_icount.py looks.
    'ta_bench_icount': 'stage_benchmarks',
}

# Targets that build language servers and therefore honour --language, both for
# which backends get built and for which toolchains must be present.
LANG_FILTERED_TARGETS = ('servers', 'regtest', 'xlang-hash')

def library_backends(lang_filter):
    """The backends with a publishable library that this --language selects."""
    resolved = backends_for_languages(lang_filter) or ','.join(LIBRARY_PREREQS)
    return [b for b in resolved.split(',') if b in LIBRARY_PREREQS]

# Map each target to the prerequisite set it requires. These are the
# no---language defaults; see LANG_FILTERED_TARGETS above for the narrowed path.
TARGET_PREREQS = {
    'all':          PREREQS_BUILD_BASIC,
    'ta_regtest':   PREREQS_BUILD_BASIC,
    'ta_bench_icount': PREREQS_BUILD_BASIC,
    'ta_codegen':   PREREQS_BUILD_CODEGEN,
    'generate':     PREREQS_BUILD_CODEGEN,
    # Cargo only, deliberately: the point of this gate is that anyone can run
    # it. It builds nothing C, so cmake is not a prerequisite either.
    'regen-check':  [PREREQS_CARGO],
    'wasm':         [PREREQS_CARGO],
    'format':       PREREQS_BUILD_CODEGEN,
    'format-check': PREREQS_BUILD_CODEGEN,
    'clippy':       PREREQS_BUILD_CODEGEN,
    'servers':      PREREQS_BUILD_SERVERS,
    'test':         PREREQS_BUILD_BASIC,
    'regtest':      PREREQS_BUILD_SERVERS,
    'ref':          [PREREQS_CMAKE, PREREQS_GCC],
    'refdata':      PREREQS_BUILD_BASIC,
    # build_xlanghash builds --backend=rust,java,csharp,ts,go, so the .NET SDK,
    # Node and Go are as required here as the JDK. Without one, that server
    # silently never builds.
    'xlang-hash':   PREREQS_BUILD_CODEGEN + [PREREQS_GCC, PREREQS_JAVAC, PREREQS_JAVA,
                                             PREREQS_DOTNET, PREREQS_NODE, PREREQS_GO],
}

def main():
    # Refuse to run as root/sudo (Unix only).
    if hasattr(os, 'getuid') and os.getuid() == 0:
        print("Error: Do not run this script as root or with sudo.")
        sys.exit(1)

    parser = argparse.ArgumentParser(
        description="TA-Lib developer build helper",
        add_help=False,
    )
    parser.add_argument('target', nargs='?', default='all')
    parser.add_argument('--build-type', default=DEFAULT_BUILD_TYPE)
    parser.add_argument('--jobs', '-j', type=positive_int, default=DEFAULT_JOBS)
    parser.add_argument('--cmake-args', default='')
    # Narrows BOTH the prerequisite check and the backends actually built, so a
    # machine without a JDK or the .NET SDK can still do `servers`/`regtest`
    # for the backends it does have. Same tokens as regtest.py / ta_regtest.
    parser.add_argument('--language', default=None,
                        help='c,rust,java,csharp,ts,go — limit which servers are built')
    parser.add_argument('--versions', default=None,
                        help='ref: the ta_ref members to build and run (default: all)')
    parser.add_argument('--build-only', action='store_true',
                        help='ref: build the serves, run nothing')
    parser.add_argument('--node', default=None,
                        help='libraries: 22,24,26 or all — run the TypeScript suite once per '
                             'pinned Node major')
    parser.add_argument('--sanitize', action='store_true',
                        help='Build with AddressSanitizer + UBSan into cmake-build-asan (issue #94)')
    parser.add_argument('--check', action='store_true',
                        help='refdata: compare the committed CSVs, write nothing')
    parser.add_argument('--help', '-h', action='store_true')
    args = parser.parse_args()
    global JOBS
    if args.jobs != DEFAULT_JOBS:
        JOBS = JobServer(args.jobs)

    if args.help or args.target == 'help':
        show_help()
        return

    root_dir = find_repo_root()
    build_dir = os.path.join(root_dir, BUILD_DIR_NAME)

    # ASan/UBSan builds go to a separate directory (Debug, static-only) so they
    # never share object files or the CMake cache with the Release tree.
    if args.sanitize:
        build_dir = os.path.join(root_dir, SANITIZE_DIR_NAME)
        if args.build_type == DEFAULT_BUILD_TYPE:
            args.build_type = 'Debug'
        args.cmake_args = (
            args.cmake_args + ' -DENABLE_SANITIZERS=ON -DBUILD_SHARED_LIBS=OFF'
        ).strip()

    if args.target == 'clean':
        removed = False
        for d in (os.path.join(root_dir, BUILD_DIR_NAME),
                  os.path.join(root_dir, SANITIZE_DIR_NAME)):
            try:
                shutil.rmtree(d)
                print(f"Removed {d}")
                removed = True
            except FileNotFoundError:
                pass
        if not removed:
            print("Nothing to clean.")
        return

    # Pure text check — no build prerequisites.
    if args.target == 'check-source-lists':
        sys.exit(0 if check_regtest_source_lists(root_dir) else 1)

    if args.target == 'check-cargo-lock':
        check_prerequisites([PREREQS_CARGO])
        sys.exit(0 if check_cargo_locks(root_dir) else 1)

    if args.target == 'check-stream-retcodes':
        sys.exit(0 if check_stream_retcodes(root_dir) else 1)

    if args.target == 'check-mcdc':
        sys.exit(subprocess.call(
            [sys.executable, os.path.join(root_dir, 'scripts',
                                          'check_mcdc_conditions.py')]))

    if args.target == 'check-candle-windows':
        sys.exit(subprocess.call(
            [sys.executable, os.path.join(root_dir, 'scripts',
                                          'check_candle_windows.py')]))

    # Targets that build language servers narrow their prerequisites to the
    # backends actually requested: `servers --language=c,rust` must not demand a
    # JDK or the .NET SDK.
    #
    # The prerequisites are derived from the RESOLVED backend list, not from the
    # raw filter, so the check can never disagree with what gets built. A filter
    # naming no real backend (`--language=cref`, or a typo) resolves to None,
    # meaning "build everything" — and then the full toolchain is required,
    # rather than promising a short tool list and building all four anyway.
    if args.node and args.target != 'libraries':
        print(f"Error: --node applies only to the libraries target.")
        sys.exit(2)
    if args.check and args.target != 'refdata':
        print(f"Error: --check applies only to the refdata target.")
        sys.exit(2)
    _backends = backends_for_languages(args.language)
    if args.target == 'libraries':
        # cargo runs the generator; everything else comes from the backends that
        # actually have a publishable library. --node brings its own node and npm.
        _prereqs = [PREREQS_CARGO]
        for _b in library_backends(args.language):
            _prereqs += [t for t in LIBRARY_PREREQS[_b]
                         if t not in _prereqs and not (args.node and t is PREREQS_NODE)]
        check_prerequisites(_prereqs)
    elif args.target in LANG_FILTERED_TARGETS and _backends:
        check_prerequisites(prereqs_for_languages(_backends))
    else:
        check_prerequisites(TARGET_PREREQS.get(args.target, PREREQS_BUILD_BASIC))
    # A prerequisite check may have put a fetched toolchain first on PATH.
    JOBS.env['PATH'] = os.environ['PATH']

    # Rust ta_codegen targets build with cargo directly — no CMake involved.
    if args.target in CARGO_TARGETS:
        if args.target == 'ta_codegen':
            run_codegen(root_dir, 'build', '--release')
        elif args.target == 'generate':
            run_codegen(root_dir, 'run', '--release', '--', 'generate')
        elif args.target == 'format':
            run_codegen(root_dir, 'run', '--release', '--', 'format')
        elif args.target == 'format-check':
            run_codegen(root_dir, 'run', '--release', '--', 'format', '--check')
        elif args.target == 'clippy':
            run_clippy(root_dir)
        elif args.target == 'libraries':
            sys.exit(build_libraries(root_dir, args.language, args.node))
        elif args.target == 'regen-check':
            sys.exit(regen_check(root_dir))
        elif args.target == 'wasm':
            sys.exit(build_wasm(root_dir))
        return

    ensure_configured(root_dir, build_dir, args.build_type, args.cmake_args)

    if args.target == 'ref':
        sys.exit(build_ref(root_dir, build_dir, args.jobs, args.versions, args.build_only))

    if args.target == 'refdata':
        sys.exit(build_refdata(root_dir, build_dir, args.jobs, args.build_type, args.check))

    # Cross-language BITWISE parity gate (opt-in; issue #113). Composite: build the
    # Rust server + ta_regtest, then diff each server vs the in-process C golden.
    if args.target == 'xlang-hash':
        sys.exit(build_xlanghash(root_dir, build_dir, args.jobs, args.language))

    # The cross-language tests run the C ta_regtest binary against the language
    # servers, so build the servers (cargo) first — the CMake regtest target no
    # longer does it. `servers` runs the same cargo step and then falls through
    # to ensure_ta_regtest_in_bin, so what it leaves in bin/ can be run by hand.
    if args.target in ('servers', 'regtest'):
        regtest_bin = ('ta_regtest' if args.sanitize
                       else 'ensure_ta_regtest_in_bin')
        build_servers(root_dir, args.language, alongside=lambda: cmake_build(
            build_dir, target=regtest_bin, jobs=args.jobs))

    if args.target == 'all':
        cmake_build(build_dir, jobs=args.jobs)
    elif args.target in SIMPLE_TARGETS:
        cmake_target = SIMPLE_TARGETS[args.target]
        # Under --sanitize the binary lives only in cmake-build-asan/bin/. Build
        # the raw target rather than ensure_ta_regtest_in_bin, whose ALL-target
        # copy would overwrite the Release bin/ta_regtest with the ASan build.
        if args.sanitize and cmake_target == 'ensure_ta_regtest_in_bin':
            cmake_target = 'ta_regtest'
        if args.target == 'test':
            # CMake's own `test` target runs ctest without building first. A
            # multi-config generator registers the test per configuration, so
            # the build and ctest must name the same one.
            cmake_build(build_dir, target=cmake_target, jobs=args.jobs,
                        config=args.build_type)
            # The function pages' C samples, a CTest entry beside ta_regtest;
            # a checkout has them, the released tarball does not.
            if os.path.exists(os.path.join(root_dir, 'src', 'tools', 'ta_examples',
                                           'ta_examples.c')):
                cmake_build(build_dir, target='ta_examples', jobs=args.jobs,
                            config=args.build_type)
            subprocess.run(['ctest', '-C', args.build_type, '--output-on-failure',
                            '--no-tests=error'], check=True, cwd=build_dir)
        else:
            cmake_build(build_dir, target=cmake_target, jobs=args.jobs)
    else:
        print(f"Error: Unknown target '{args.target}'. Run with 'help' to see available targets.")
        sys.exit(1)

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Package gate for the TypeScript library: pack it, check what ships, then consume it.

  1. Pack. `scripts/build.py wasm` (cargo rebuilds bin/ta_lib.wasm only when
     its crate changed), `npm ci` in the tooling root when its lock stamp is
     stale, two `tsc` emits into an emptied library/dist (the JavaScript with
     removeComments, so only the /*! licence block stays; the declarations
     apart, with their TSDoc), scripts/ts_wasm_bytes.mjs for the engine's bytes
     module, then `npm pack`. Without --allow-dirty
     the library directory (test/ and dist/ aside) must match HEAD: a stray .ts
     under src/ compiles into dist/ and ships.

  2. Contents. The tarball holds exactly package.json, README.md, LICENSE and
     one .js plus one .d.ts per src/ module, a hand-written src/ .d.ts standing
     for a module the build writes; every packed .js opens with the
     licence and holds no other comment, and every function's .d.ts keeps its
     TSDoc; LICENSE and README are
     byte-identical to their sources; the version is VERSION; every code
     `exports` subpath, and each condition nested in one, lists "types" first
     and "default" last, and each non-root one has a typesVersions entry naming
     its types; a file subpath
     ("./package.json") ships; every target ships; "main" is the "." default
     and "react-native" the "." react-native one.
     No name tagged @internal in src/ appears in a packed .d.ts, as a member of
     its class's declaration, or among any subpath's runtime exports. When
     ta_codegen/output/ts/PublicAPI.Shipped.txt exists, every declaration line
     it records must still be packed; until the first publish it is absent and
     that diff is skipped.

  3. Consumer. scripts/ts_consumer_check/ installs the tarball into a throwaway
     project, type-checks a TypeScript caller against the packed declarations
     (skipLibCheck off), and loads every subpath by import and by require(),
     which fails on a top-level await anywhere in the graph. Both must export
     the same names and compute the same SMA. Then engine.mjs: in strict mode a
     call through the default entry must run in WASM, with the bits of
     ta-lib/js. Last, esbuild bundles four consumers for Node: through the
     default entry, and through ta-lib/abstract alone, a routed call with no
     ready() must run in WASM with no fall-through; the metafiles of the
     ta-lib/js and ta-lib/js/abstract bundles must name no engine module, not
     runtime/wasm.js and not the bytes. Then, for each engine-less condition
     (workerd, edge-light, react-native), a bundle of ta-lib and one of
     ta-lib/abstract, still for Node: each must load its plain entry and none of
     those modules, give the bits of ta-lib/js, and have ready() resolve to
     {engine: 'js', reason: 'unavailable'}.

Run:  python3 scripts/ts_package_check.py [--allow-dirty] [--output DIR]
      python3 scripts/ts_package_check.py --write-api-snapshot

`--write-api-snapshot` records the packed declarations as the shipped API; the
publish runbook runs it once per publish.
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TS_REL = "ta_codegen/output/ts"
TS_ROOT = os.path.join(ROOT, TS_REL)
LIB_REL = TS_REL + "/library"
LIB_DIR = os.path.join(ROOT, LIB_REL)
# npm and the tools it installs are .cmd shims on Windows; subprocess does not
# resolve a bare name to one.
NPM = "npm.cmd" if os.name == "nt" else "npm"
TSC = os.path.join(TS_ROOT, "node_modules", ".bin", "tsc.cmd" if os.name == "nt" else "tsc")
ESBUILD = os.path.join(TS_ROOT, "node_modules", ".bin", "esbuild.cmd" if os.name == "nt" else "esbuild")
SRC_DIR = os.path.join(LIB_DIR, "src")
CONSUMER_DIR = os.path.join(ROOT, "scripts", "ts_consumer_check")
SNAPSHOT = os.path.join(TS_ROOT, "PublicAPI.Shipped.txt")

PACKED_FROM = {
    "package/LICENSE": "LICENSE",
    "package/README.md": LIB_REL + "/README.md",
}

TOP_DECL = re.compile(
    r"^export\s+(?:declare\s+)?(?:abstract\s+)?(?:async\s+)?"
    r"(?:function\*?|const|let|var|class|interface|type)\s+([A-Za-z_$][\w$]*)")
MEMBER_DECL = re.compile(
    r"^\s+(?:(?:public|protected|static|readonly|override|abstract|declare|get|set|async)\s+)*"
    r"([A-Za-z_$][\w$]*)\s*[?!]?\s*[:=(<;]")
CLASS_START = re.compile(r"^(?:export\s+)?(?:declare\s+)?(?:abstract\s+)?class\s+([A-Za-z_$][\w$]*)")


def run(cmd, cwd=ROOT, capture=False):
    print("=== %s" % " ".join(cmd), flush=True)
    return subprocess.run(cmd, cwd=cwd, check=False, text=True,
                          stdout=subprocess.PIPE if capture else None,
                          stderr=subprocess.PIPE if capture else None)


def git(*args):
    return subprocess.run(["git", *args], cwd=ROOT, check=True,
                          capture_output=True, text=True).stdout


def version():
    with open(os.path.join(ROOT, "VERSION")) as f:
        return f.read().strip()


def src_modules(suffix=".ts"):
    """Every src/ module, as its path relative to src/ without the suffix: the
    .ts sources, or with ".d.ts" the declarations of modules the build writes."""
    found = []
    for dirpath, _dirs, files in os.walk(SRC_DIR):
        for name in files:
            if name.endswith(suffix) and (suffix != ".ts" or not name.endswith(".d.ts")):
                rel = os.path.relpath(os.path.join(dirpath, name), SRC_DIR)
                found.append(rel[:-len(suffix)].replace(os.sep, "/"))
    return sorted(found)


def ensure_tooling():
    """`npm ci` unless node_modules/.ta-lock.sha256 holds the lockfile's SHA-256,
    the stamp `ta_codegen build` keeps."""
    with open(os.path.join(TS_ROOT, "package-lock.json"), "rb") as f:
        want = hashlib.sha256(f.read()).hexdigest()
    stamp = os.path.join(TS_ROOT, "node_modules", ".ta-lock.sha256")
    try:
        with open(stamp) as f:
            if f.read().strip() == want:
                return True
    except OSError:
        pass
    if run([NPM, "ci", "--no-audit", "--no-fund"], cwd=TS_ROOT).returncode:
        return False
    with open(stamp, "w") as f:
        f.write(want)
    return True


def pack(out_dir, allow_dirty):
    if not allow_dirty:
        stray = [line for line in git("status", "--porcelain", "--ignored",
                                      "--untracked-files=all", "--", LIB_REL).splitlines()
                 if not line[3:].startswith((LIB_REL + "/test/", LIB_REL + "/dist/"))]
        if stray:
            return ["the library directory differs from HEAD, and what differs would pack "
                    "(pass --allow-dirty to pack it anyway): %s" % ", ".join(stray[:10])]
    if run([sys.executable, os.path.join(ROOT, "scripts", "build.py"), "wasm"]).returncode:
        return ["scripts/build.py wasm failed, and the package ships bin/ta_lib.wasm; see its output above"]
    if not ensure_tooling():
        return ["npm ci failed in %s; see its output above" % TS_REL]
    shutil.rmtree(os.path.join(LIB_DIR, "dist"), ignore_errors=True)
    # As build-libraries emits it: the JavaScript without comments but the /*! licence,
    # the declarations apart so they keep their TSDoc.
    if run([TSC, "-p", LIB_DIR, "--removeComments", "--declaration", "false"]).returncode:
        return ["tsc failed on the library's JavaScript; see its output above"]
    if run([TSC, "-p", LIB_DIR, "--emitDeclarationOnly"]).returncode:
        return ["tsc failed on the library's declarations; see its output above"]
    if run(["node", os.path.join(ROOT, "scripts", "ts_wasm_bytes.mjs"), LIB_DIR]).returncode:
        return ["the WASM engine's bytes module was not written; see its output above"]
    if run([NPM, "pack", "--pack-destination", out_dir], cwd=LIB_DIR).returncode:
        return ["npm pack failed; see its output above"]
    return []


def tarball_entries(path):
    with tarfile.open(path, "r:gz") as tar:
        return {m.name: tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}


def internal_names():
    """({top-level name: module}, [(module, class, member)], failures) for every
    declaration whose doc comment carries @internal."""
    tops, members, failures = {}, [], []
    for module in src_modules():
        path = os.path.join(SRC_DIR, module + ".ts")
        with open(path, encoding="utf-8") as f:
            lines = f.read().splitlines()
        cls = None
        i = 0
        while i < len(lines):
            line = lines[i]
            m = CLASS_START.match(line)
            if m:
                cls = m.group(1)
            elif line.startswith("}"):
                cls = None
            if line.lstrip().startswith("/**"):
                start = i
                while "*/" not in lines[i]:
                    i += 1
                block = "\n".join(lines[start:i + 1])
                if re.search(r"(?:^|[\s*])@internal\b", block):
                    j = i + 1
                    while j < len(lines) and not lines[j].strip():
                        j += 1
                    decl = lines[i].split("*/", 1)[1].strip() or (lines[j] if j < len(lines) else "")
                    top = TOP_DECL.match(decl)
                    reexport = re.match(r"^export\s+(?:type\s+)?\{([^}]*)\}", decl)
                    member = MEMBER_DECL.match(decl) if decl[:1].isspace() else None
                    if top:
                        tops[top.group(1)] = module
                    elif reexport:
                        for part in reexport.group(1).split(","):
                            if part.strip():
                                tops[part.split(" as ")[-1].strip()] = module
                    elif member and cls:
                        members.append((module, cls, member.group(1)))
                    elif not decl.startswith(("function ", "const ", "let ", "class ")):
                        failures.append("%s/src/%s.ts:%d: cannot read the declaration "
                                        "@internal tags: %r" % (LIB_REL, module, j + 1, decl))
            i += 1
    return tops, members, failures


def class_body(dts, cls):
    m = re.search(r"^(?:export\s+)?declare\s+(?:abstract\s+)?class\s+%s\b.*?^}" % re.escape(cls),
                  dts, re.S | re.M)
    return m.group(0) if m else ""


def declarations(entries):
    """{packed .d.ts path: its lines with comments and blank lines dropped}."""
    out = {}
    for name in sorted(n for n in entries if n.endswith(".d.ts")):
        text = re.sub(r"/\*.*?\*/", "", entries[name].decode("utf-8"), flags=re.S)
        out[name] = [line.rstrip() for line in text.splitlines()
                     if line.strip() and not line.lstrip().startswith("//")]
    return out


def write_snapshot(entries):
    with open(SNAPSHOT, "w", encoding="utf-8", newline="\n") as f:
        for name, lines in declarations(entries).items():
            f.write("// %s\n" % name)
            for line in lines:
                f.write(line + "\n")
    print("Wrote %s" % os.path.relpath(SNAPSHOT, ROOT))


def snapshot_failures(entries):
    if not os.path.exists(SNAPSHOT):
        print("--- API snapshot: %s is absent (nothing published yet); diff skipped"
              % os.path.relpath(SNAPSHOT, ROOT))
        return []
    shipped, section = {}, None
    with open(SNAPSHOT, encoding="utf-8") as f:
        for line in f.read().splitlines():
            if line.startswith("// "):
                section = line[3:]
                shipped[section] = []
            elif section is not None:
                shipped[section].append(line)
    current = declarations(entries)
    failures = []
    for name, lines in shipped.items():
        if name not in current:
            failures.append("%s shipped in the last publish and is no longer packed" % name)
            continue
        remaining = list(current[name])
        missing = []
        for line in lines:
            if line in remaining:
                remaining.remove(line)
            else:
                missing.append(line.strip())
        if missing:
            failures.append("%s no longer declares what shipped: %s"
                            % (name, "; ".join(missing[:10])))
    return failures


def check_package(out_dir, ver, diff_snapshot):
    produced = [n for n in os.listdir(out_dir) if n.endswith(".tgz")]
    if len(produced) != 1:
        return ["expected exactly one .tgz in %s, found %s" % (out_dir, produced or "nothing")], None
    entries = tarball_entries(os.path.join(out_dir, produced[0]))

    failures = []
    expected = {"package/package.json", *PACKED_FROM}
    for module in src_modules() + src_modules(".d.ts"):
        expected |= {"package/dist/%s.js" % module, "package/dist/%s.d.ts" % module}
    missing = sorted(expected - set(entries))
    extra = sorted(set(entries) - expected)
    if missing:
        failures.append("the tarball is missing %s" % ", ".join(missing[:20]))
    if extra:
        failures.append("the tarball carries unexpected %s" % ", ".join(extra[:20]))
    if failures:
        return failures, None

    for entry, source in PACKED_FROM.items():
        with open(os.path.join(ROOT, source), "rb") as f:
            if entries[entry] != f.read():
                failures.append("the packed %s differs from %s" % (entry[len("package/"):], source))

    manifest = json.loads(entries["package/package.json"])
    if manifest.get("version") != ver:
        failures.append("the packed version is %r, VERSION is %r" % (manifest.get("version"), ver))
    exports = manifest.get("exports")
    if not isinstance(exports, dict) or "." not in exports:
        return failures + ["the packed package.json has no exports \".\" entry"], None
    for subpath, conditions in exports.items():
        if isinstance(conditions, str):
            # The one file subpath: consume() loads it as JSON.
            if subpath != "./package.json" or conditions != "./package.json":
                failures.append("exports %r is the file %s; only \"./package.json\" may be a file subpath"
                                % (subpath, conditions))
            elif "package/package.json" not in entries:
                failures.append("exports %r points at %s, which is not packed" % (subpath, conditions))
            continue
        branches = [(subpath, conditions)]
        while branches:
            where, branch = branches.pop(0)
            keys = list(branch) if isinstance(branch, dict) else []
            if not keys or keys[0] != "types" or keys[-1] != "default":
                failures.append("exports %r lists %s; \"types\" must come first and \"default\" last"
                                % (where, keys))
            for condition, target in (branch.items() if isinstance(branch, dict) else []):
                if isinstance(target, dict):
                    branches.append(("%s.%s" % (where, condition), target))
                elif "package/" + target.removeprefix("./") not in entries:
                    failures.append("exports %r points at %s, which is not packed" % (where, target))
    # For a resolver that ignores "exports".
    if not isinstance(exports["."], dict) or manifest.get("main") != exports["."].get("default"):
        failures.append("the packed package.json \"main\" (%r) is not the \".\" default entry"
                        % manifest.get("main"))
    # Metro with package exports off reads this field, and otherwise "main".
    native = exports["."].get("react-native") if isinstance(exports["."], dict) else None
    if not isinstance(native, dict) or manifest.get("react-native") != native.get("default"):
        failures.append("the packed package.json \"react-native\" (%r) is not the \".\" react-native entry"
                        % manifest.get("react-native"))
    types = manifest.get("types")
    if not types or "package/" + types.removeprefix("./") not in entries:
        failures.append("the packed package.json \"types\" (%r) is not packed" % types)
    # moduleResolution node10 (TS 5.x's default under module commonjs) ignores "exports":
    # a subpath without this mapping still runs, but its import fails to type-check.
    mapped = (manifest.get("typesVersions") or {}).get("*") or {}
    for subpath, conditions in exports.items():
        if subpath == "." or not isinstance(conditions, dict):
            continue
        if mapped.get(subpath.removeprefix("./")) != [conditions.get("types")]:
            failures.append("exports %r has no typesVersions \"*\" entry naming %s"
                            % (subpath, conditions.get("types")))

    failures += dist_comment_failures(entries)

    tops, members, parse_failures = internal_names()
    failures += parse_failures
    if not tops:
        failures.append("no exported declaration in %s/src carries @internal, so the leak "
                        "check below checked nothing; its parser no longer matches" % LIB_REL)
    dts = {n: "\n".join(lines) for n, lines in declarations(entries).items()}
    for name, module in sorted(tops.items()):
        leaks = sorted(n for n, text in dts.items() if re.search(r"(?<![\w$])%s(?![\w$])"
                                                                % re.escape(name), text))
        if leaks:
            failures.append("@internal %s (src/%s.ts) appears in %s"
                            % (name, module, ", ".join(leaks[:5])))
    for module, cls, member in members:
        body = class_body(dts.get("package/dist/%s.d.ts" % module, ""), cls)
        if re.search(r"^\s+(?:(?:readonly|static|protected|public|abstract|override|get|set)\s+)*"
                     r"%s\s*[?!]?\s*[:(<]" % re.escape(member), body, re.M):
            failures.append("@internal %s.%s (src/%s.ts) is declared in dist/%s.d.ts"
                            % (cls, member, module, module))
    print("--- @internal declarations checked: %d exported, %d members" % (len(tops), len(members)))

    if diff_snapshot:
        failures += snapshot_failures(entries)
    return failures, (manifest, entries, tops)


def dist_comment_failures(entries):
    """The two emits' proof over the packed dist: every .js opens with the /*! licence
    and holds no other comment; every function's .d.ts keeps its TSDoc."""
    js = sorted(e for e in entries if e.startswith("package/dist/") and e.endswith(".js"))
    dts = sorted(e for e in entries if e.startswith("package/dist/func/") and e.endswith(".d.ts"))
    bad = [e for e in js
           if not entries[e].startswith(b"/*! TA-LIB Copyright") or entries[e].count(b"/*") != 1
           or any(line.lstrip().startswith(b"//") for line in entries[e].splitlines())]
    bad += [e for e in dts if b"/**" not in entries[e]]
    failures = []
    if bad:
        failures.append("JavaScript with a comment beyond the licence, or a function's .d.ts without TSDoc: %s"
                        % ", ".join(e[len("package/"):] for e in bad[:10]))
    print("--- comments checked: %d .js hold the licence alone, %d function .d.ts keep their TSDoc"
          % (len(js) - sum(e in bad for e in js), len(dts) - sum(e in bad for e in dts)))
    return failures


def consume(out_dir, manifest, tops):
    tarball = os.path.join(out_dir, [n for n in os.listdir(out_dir) if n.endswith(".tgz")][0])
    name = manifest["name"]
    # The loaders import the code subpaths; "./package.json" loads as a consumer loads
    # JSON: require(), and import with the json attribute.
    code = [s for s, c in manifest["exports"].items() if isinstance(c, dict)]
    files = [s for s, c in manifest["exports"].items() if isinstance(c, str)]
    specs = [name if s == "." else name + s.removeprefix(".") for s in code]
    work = tempfile.mkdtemp(prefix="talib-ts-consumer-")
    try:
        for entry in os.listdir(CONSUMER_DIR):
            shutil.copy(os.path.join(CONSUMER_DIR, entry), work)
        if run([NPM, "install", "--no-audit", "--no-fund", "--ignore-scripts", tarball],
               cwd=work).returncode:
            return ["the consumer could not install %s" % os.path.basename(tarball)]
        if run([TSC, "-p", work]).returncode:
            return ["a TypeScript consumer does not type-check against the packed declarations"]
        results = {}
        for loader in ("import.mjs", "require.cjs"):
            r = run(["node", loader, *specs], cwd=work, capture=True)
            if r.returncode:
                return ["%s failed to load %s:\n%s" % (loader, ", ".join(specs), r.stderr.strip())]
            try:
                results[loader] = json.loads(r.stdout.strip().splitlines()[-1])
            except (ValueError, IndexError):
                return ["%s printed no result: %r" % (loader, r.stdout)]
        if results["import.mjs"] != results["require.cjs"]:
            return ["import and require() disagree: %r vs %r"
                    % (results["import.mjs"], results["require.cjs"])]
        r = run(["node", "engine.mjs"], cwd=work, capture=True)
        if r.returncode:
            return ["engine.mjs: a strict-mode call through the default entry did not run in WASM "
                    "with the bits of ta-lib/js:\n%s%s" % (r.stdout, r.stderr.strip())]
        print("--- %s" % r.stdout.strip().splitlines()[-1])
        failures = bundles(work)
        if failures:
            return failures
        got = results["import.mjs"]
        for s in files:
            spec = name + s.removeprefix(".")
            want = manifest["version"]
            probes = (("require()", ["node", "-e", "console.log(require(%r).version)" % spec]),
                      ("import", ["node", "--input-type=module", "-e",
                                  "const m = await import(%r, { with: { type: 'json' } }); console.log(m.default.version)" % spec]))
            for label, cmd in probes:
                r = run(cmd, cwd=work, capture=True)
                if r.returncode or r.stdout.strip() != want:
                    failures.append("%s by %s gave %r, not the packed version %r" % (spec, label, r.stdout.strip(), want))
        if got["sma"] != [2, 8, 2, 3, 4, 5, 6, 7, 8, 9]:
            failures.append("the consumer's SMA(3) over 1..10 is %r" % got["sma"])
        for spec, keys in got["exports"].items():
            leaked = sorted(set(keys) & set(tops))
            if leaked:
                failures.append("%s exports @internal %s at run time" % (spec, ", ".join(leaked[:10])))
            if not keys:
                failures.append("%s exports nothing" % spec)
        print("--- consumer loaded %s by import and require(); %s as JSON" % (", ".join(specs), ", ".join(name + s.removeprefix(".") for s in files) or "no file subpath"))
        return failures
    finally:
        shutil.rmtree(work, ignore_errors=True)


def bundles(work):
    if not os.path.exists(ESBUILD):
        return ["no esbuild at %s after npm ci in %s" % (ESBUILD, TS_REL)]
    for consumer, out in (("bundle_node.mjs", "node.mjs"), ("bundle_abstract.mjs", "abstract.mjs")):
        if run([ESBUILD, consumer, "--bundle", "--format=esm", "--platform=node",
                "--outfile=bundled/%s" % out, "--log-level=warning"], cwd=work).returncode:
            return ["esbuild could not bundle %s for Node; see its output above" % consumer]
        r = run(["node", os.path.join("bundled", out)], cwd=work, capture=True)
        if r.returncode:
            return ["%s, bundled for Node: a routed call did not run in WASM:\n%s%s"
                    % (consumer, r.stdout, r.stderr.strip())]
        print("--- %s" % r.stdout.strip().splitlines()[-1])
    for consumer, spec, forbidden in (
            ("bundle_js.mjs", "ta-lib/js", ("/runtime/wasmBytes.js", "/runtime/wasm.js")),
            ("bundle_js_abstract.mjs", "ta-lib/js/abstract", ("/runtime/wasmBytes.js", "/runtime/wasm.js"))):
        meta = os.path.join("bundled", consumer.replace(".mjs", ".meta.json"))
        if run([ESBUILD, consumer, "--bundle", "--format=esm", "--platform=node",
                "--outfile=bundled/%s" % consumer, "--metafile=%s" % meta, "--log-level=warning"],
               cwd=work).returncode:
            return ["esbuild could not bundle %s for Node; see its output above" % consumer]
        with open(os.path.join(work, meta)) as f:
            inputs = json.load(f)["inputs"]
        if not any("/dist/abstract/" in i or "/dist/func/" in i for i in inputs):
            return ["the metafile of %s names no module of the package, so the check below "
                    "checked nothing: %s" % (consumer, sorted(inputs)[:5])]
        engine = sorted(i for i in inputs if "/dist/engine/" in i or i.endswith(forbidden))
        if engine:
            return ["a Node bundle of %s loads %s" % (spec, ", ".join(engine[:3]))]
        print("--- %s: a Node bundle of %s loads none of the engine's modules (%s)"
              % (consumer, spec, ", ".join(["dist/engine/"] + [f.lstrip("/") for f in forbidden])))
    return plain_bundles(work)


def plain_bundles(work):
    """--platform=node also sets the node condition, so a plain entry is loaded
    only if its condition precedes node in the subpath."""
    failures = []
    for condition in ("workerd", "edge-light", "react-native"):
        for consumer, spec, plain in (("bundle_plain.mjs", "ta-lib", "/dist/engine/plain.js"),
                                      ("bundle_plain_abstract.mjs", "ta-lib/abstract", "/dist/abstract/plain.js")):
            where = "%s under --conditions=%s" % (spec, condition)
            out = "bundled/%s-%s" % (condition, consumer)
            meta = out.replace(".mjs", ".meta.json")
            if run([ESBUILD, consumer, "--bundle", "--format=esm", "--platform=node",
                    "--conditions=" + condition, "--outfile=" + out, "--metafile=" + meta,
                    "--log-level=warning"], cwd=work).returncode:
                failures.append("esbuild could not bundle %s; see its output above" % where)
                continue
            with open(os.path.join(work, meta)) as f:
                inputs = json.load(f)["inputs"]
            if not any(i.endswith(plain) for i in inputs):
                failures.append("a bundle of %s does not load %s" % (where, plain.lstrip("/")))
            engine = sorted(i for i in inputs if ("/dist/engine/" in i and not i.endswith("/dist/engine/plain.js"))
                            or i.endswith(("/runtime/wasm.js", "/runtime/wasmBytes.js")))
            if engine:
                failures.append("a bundle of %s loads %s" % (where, ", ".join(engine[:3])))
            r = run(["node", out], cwd=work, capture=True)
            if r.returncode:
                failures.append("a bundle of %s, run:\n%s%s" % (where, r.stdout, r.stderr.strip()))
            elif not engine:
                print("--- %s: %s" % (where, r.stdout.strip().splitlines()[-1]))
    return failures


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--allow-dirty", action="store_true",
                        help="pack a library directory with local edits or stray files")
    parser.add_argument("--output", help="pack into this new or empty directory and keep it")
    parser.add_argument("--write-api-snapshot", action="store_true",
                        help="record the packed declarations in %s" % os.path.relpath(SNAPSHOT, ROOT))
    args = parser.parse_args()

    for tool in ("node", "npm"):
        if not shutil.which(tool):
            print("\n=== PACKAGE GATE FAILED ===\n  no %s on PATH" % tool)
            return 1
    node_version = subprocess.run(["node", "--version"], capture_output=True, text=True).stdout.strip()
    ver = version()
    print("--- TypeScript package %s, Node %s" % (ver, node_version))

    out_dir = os.path.abspath(args.output) if args.output else tempfile.mkdtemp(prefix="talib-ts-pack-")
    if os.path.isdir(out_dir) and os.listdir(out_dir):
        print("\n=== PACKAGE GATE FAILED ===\n  %s is not empty" % out_dir)
        return 1
    os.makedirs(out_dir, exist_ok=True)
    try:
        failures = pack(out_dir, args.allow_dirty)
        checked = None
        if not failures:
            failures, checked = check_package(out_dir, ver, not args.write_api_snapshot)
        if checked and args.write_api_snapshot:
            write_snapshot(checked[1])
        if checked and not failures:
            failures = consume(out_dir, checked[0], checked[2])
    finally:
        if not args.output:
            shutil.rmtree(out_dir, ignore_errors=True)

    if failures:
        print("\n=== PACKAGE GATE FAILED ===")
        for failure in failures:
            print("  " + failure)
        return 1
    print("\n=== PACKAGE GATE PASSED ===")
    return 0


if __name__ == "__main__":
    sys.exit(main())

/* TA-LIB Copyright (c) 1999-2026, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*********************************************************************
 * This file contains only TA functions starting with the letter 'N' *
 *********************************************************************/
#include <stddef.h>
#include "ta_abstract.h"
#include "ta_def_ui.h"

/* NATR BEGIN */
const TA_OutputParameterInfo TA_DEF_UI_Output_Real_NATR_Default =
                               { TA_Output_Real, "outReal", TA_OUT_LINE | TA_OUT_ZERO | TA_OUT_POSITIVE };

static const TA_InputParameterInfo    *TA_NATR_Inputs[]    =
{
  &TA_DEF_UI_Input_Price_HLC,
  NULL
};

static const TA_OutputParameterInfo   *TA_NATR_Outputs[]   =
{
  &TA_DEF_UI_Output_Real_NATR_Default,
  NULL
};

static const TA_OptInputParameterInfo *TA_NATR_OptInputs[] =
{ &TA_DEF_UI_TimePeriod_14,
  NULL
};

DEF_FUNCTION( NATR,
              TA_GroupId_VolatilityIndicators,
              "Normalized Average True Range",
              TA_FUNC_FLG_UNST_PER | TA_FUNC_FLG_STREAM | TA_FUNC_FLG_POSITIVE_INPUT
             );
/* NATR END */

/* NVI BEGIN */
const TA_OutputParameterInfo TA_DEF_UI_Output_Real_NVI_Default =
                               { TA_Output_Real, "outReal", TA_OUT_LINE | TA_OUT_ZERO | TA_OUT_POSITIVE };

static const TA_InputParameterInfo    *TA_NVI_Inputs[]    =
{
  &TA_DEF_UI_Input_Price_CV,
  NULL
};

static const TA_OutputParameterInfo   *TA_NVI_Outputs[]   =
{
  &TA_DEF_UI_Output_Real_NVI_Default,
  NULL
};

static const TA_OptInputParameterInfo *TA_NVI_OptInputs[] =
{ NULL };

DEF_FUNCTION( NVI,
              TA_GroupId_VolumeIndicators,
              "Negative Volume Index",
              TA_FUNC_FLG_STREAM | TA_FUNC_FLG_PATH_DEP | TA_FUNC_FLG_POSITIVE_INPUT
             );
/* NVI END */

/****************************************************************************
 * Step 2 - Add your TA function to the table.
 *          Keep in alphabetical order. Must be NULL terminated.
 ****************************************************************************/
const TA_FuncDef *TA_DEF_TableN[] =
{
   ADD_TO_TABLE(NATR),
   ADD_TO_TABLE(NVI),
   NULL
};


/* Do not modify the following line. */
const unsigned int TA_DEF_TableNSize =
              ((sizeof(TA_DEF_TableN)/sizeof(TA_FuncDef *))-1);


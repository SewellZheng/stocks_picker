/* TA-LIB Copyright (c) 1999-2026, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdlib.h>
#include "ta_abstract.h"
#include "ta_def_ui.h"

const char TA_GroupId_MathOperatorsString[] = "Math Operators";
const char TA_GroupId_MathTransformString[] = "Math Transform";
const char TA_GroupId_OverlapStudiesString[] = "Overlap Studies";
const char TA_GroupId_VolatilityIndicatorsString[] = "Volatility Indicators";
const char TA_GroupId_MomentumIndicatorsString[] = "Momentum Indicators";
const char TA_GroupId_CycleIndicatorsString[] = "Cycle Indicators";
const char TA_GroupId_VolumeIndicatorsString[] = "Volume Indicators";
const char TA_GroupId_PatternRecognitionString[] = "Pattern Recognition";
const char TA_GroupId_StatisticString[] = "Statistic Functions";
const char TA_GroupId_PriceTransformString[] = "Price Transform";

const char *TA_GroupString[TA_NB_GROUP_ID] =
{
   &TA_GroupId_MathOperatorsString[0],
   &TA_GroupId_MathTransformString[0],
   &TA_GroupId_OverlapStudiesString[0],
   &TA_GroupId_VolatilityIndicatorsString[0],
   &TA_GroupId_MomentumIndicatorsString[0],
   &TA_GroupId_CycleIndicatorsString[0],
   &TA_GroupId_VolumeIndicatorsString[0],
   &TA_GroupId_PatternRecognitionString[0],
   &TA_GroupId_StatisticString[0],
   &TA_GroupId_PriceTransformString[0]
};

const TA_InputParameterInfo TA_DEF_UI_Input_Price_OHLCV =
                                  { TA_Input_Price, "inPriceOHLCV",
                                    TA_IN_PRICE_OPEN |
                                    TA_IN_PRICE_HIGH |
                                    TA_IN_PRICE_LOW |
                                    TA_IN_PRICE_CLOSE |
                                    TA_IN_PRICE_VOLUME };

const TA_InputParameterInfo TA_DEF_UI_Input_Price_HLCV =
                                  { TA_Input_Price, "inPriceHLCV",
                                    TA_IN_PRICE_HIGH |
                                    TA_IN_PRICE_LOW |
                                    TA_IN_PRICE_CLOSE |
                                    TA_IN_PRICE_VOLUME };

const TA_InputParameterInfo TA_DEF_UI_Input_Price_OHLC =
                                  { TA_Input_Price, "inPriceOHLC",
                                    TA_IN_PRICE_OPEN |
                                    TA_IN_PRICE_HIGH |
                                    TA_IN_PRICE_LOW |
                                    TA_IN_PRICE_CLOSE };

const TA_InputParameterInfo TA_DEF_UI_Input_Price_HLC =
                                  { TA_Input_Price, "inPriceHLC",
                                    TA_IN_PRICE_HIGH |
                                    TA_IN_PRICE_LOW |
                                    TA_IN_PRICE_CLOSE };

const TA_InputParameterInfo TA_DEF_UI_Input_Price_HLV =
                                  { TA_Input_Price, "inPriceHLV",
                                    TA_IN_PRICE_HIGH |
                                    TA_IN_PRICE_LOW |
                                    TA_IN_PRICE_VOLUME };

const TA_InputParameterInfo TA_DEF_UI_Input_Price_HL =
                                  { TA_Input_Price, "inPriceHL",
                                    TA_IN_PRICE_HIGH |
                                    TA_IN_PRICE_LOW };

const TA_InputParameterInfo TA_DEF_UI_Input_Price_OC =
                                  { TA_Input_Price, "inPriceOC",
                                    TA_IN_PRICE_OPEN |
                                    TA_IN_PRICE_CLOSE };

const TA_InputParameterInfo TA_DEF_UI_Input_Price_CV =
                                  { TA_Input_Price, "inPriceCV",
                                    TA_IN_PRICE_CLOSE |
                                    TA_IN_PRICE_VOLUME };

const TA_InputParameterInfo TA_DEF_UI_Input_Price_V =
                                  { TA_Input_Price, "inPriceV",
                                    TA_IN_PRICE_VOLUME };

const TA_InputParameterInfo TA_DEF_UI_Input_Real =
                                  { TA_Input_Real, "inReal", 0 };

const TA_InputParameterInfo TA_DEF_UI_Input_Periods =
                                  { TA_Input_Real, "inPeriods", 0 };

const TA_InputParameterInfo TA_DEF_UI_Input_Real0 =
                                  { TA_Input_Real, "inReal0", 0 };

const TA_InputParameterInfo TA_DEF_UI_Input_Real1 =
                                  { TA_Input_Real, "inReal1", 0 };

const TA_InputParameterInfo TA_DEF_UI_Input_Integer =
                                  { TA_Input_Integer, "inInteger", 0 };

const TA_OutputParameterInfo TA_DEF_UI_Output_Real =
                                  { TA_Output_Real, "outReal", TA_OUT_LINE };

const TA_OutputParameterInfo TA_DEF_UI_Output_Integer =
                                  { TA_Output_Integer, "outInteger", TA_OUT_LINE };

const TA_IntegerRange TA_DEF_TimePeriod_Positive =
{
   1,
   100000,
   1,
   200,
   1
};

const TA_IntegerRange TA_DEF_TimePeriod_Positive_Minimum5 =
{
   5,
   100000,
   5,
   200,
   1
};

const TA_IntegerRange TA_DEF_TimePeriod_Positive_Minimum2 =
{
   2,
   100000,
   4,
   200,
   1
};

const TA_IntegerRange TA_DEF_HorizontalShiftPeriod =
{
   -200,
   200,
   0,
   8,
   1
};

const TA_RealRange TA_DEF_VerticalShiftPercent =
{
   -99.0,
   99.0,
   1,
   -10.0,
   10.0,
   0.5
};

const TA_RealRange TA_DEF_NbDeviation =
{
   TA_REAL_MIN,
   TA_REAL_MAX,
   2,
   -2.0,
   2.0,
   0.2
};

const TA_RealRange TA_DEF_ZeroToOne =
{
   0.00,
   1.00,
   2,
   0.01,
   1.00,
   0.05
};

const TA_RealRange TA_DEF_RealPositive =
{
   0.00,
   TA_REAL_MAX,
   0,
   0.0,
   0.0,
   0.0
};

const TA_OptInputParameterInfo TA_DEF_UI_MinPeriod =
{
   TA_OptInput_IntegerRange,
   "optInMinPeriod",
   0,

   "Minimum Period",
   (const void *)&TA_DEF_TimePeriod_Positive_Minimum2,
   2,
   "Value less than minimum will be changed to Minimum period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_MaxPeriod =
{
   TA_OptInput_IntegerRange,
   "optInMaxPeriod",
   0,

   "Maximum Period",
   (const void *)&TA_DEF_TimePeriod_Positive_Minimum2,
   30,
   "Value higher than maximum will be changed to Maximum period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_TimePeriod_30_MINIMUM2 =
{
   TA_OptInput_IntegerRange,
   "optInTimePeriod",
   0,

   "Time Period",
   (const void *)&TA_DEF_TimePeriod_Positive_Minimum2,
   30,
   "Time period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_TimePeriod_20_MINIMUM2 =
{
   TA_OptInput_IntegerRange,
   "optInTimePeriod",
   0,

   "Time Period",
   (const void *)&TA_DEF_TimePeriod_Positive_Minimum2,
   20,
   "Time period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_TimePeriod_21_MINIMUM2 =
{
   TA_OptInput_IntegerRange,
   "optInTimePeriod",
   0,

   "Time Period",
   (const void *)&TA_DEF_TimePeriod_Positive_Minimum2,
   21,
   "Time period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_TimePeriod_14_MINIMUM2 =
{
   TA_OptInput_IntegerRange,
   "optInTimePeriod",
   0,

   "Time Period",
   (const void *)&TA_DEF_TimePeriod_Positive_Minimum2,
   14,
   "Time period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_TimePeriod_10_MINIMUM2 =
{
   TA_OptInput_IntegerRange,
   "optInTimePeriod",
   0,

   "Time Period",
   (const void *)&TA_DEF_TimePeriod_Positive_Minimum2,
   10,
   "Time period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_TimePeriod_5_MINIMUM2 =
{
   TA_OptInput_IntegerRange,
   "optInTimePeriod",
   0,

   "Time Period",
   (const void *)&TA_DEF_TimePeriod_Positive_Minimum2,
   5,
   "Time period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_TimePeriod_14_MINIMUM5 =
{
   TA_OptInput_IntegerRange,
   "optInTimePeriod",
   0,

   "Time Period",
   (const void *)&TA_DEF_TimePeriod_Positive_Minimum5,
   14,
   "Time period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_TimePeriod_30 =
{
   TA_OptInput_IntegerRange,
   "optInTimePeriod",
   0,

   "Time Period",
   (const void *)&TA_DEF_TimePeriod_Positive,
   30,
   "Time period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_TimePeriod_14 =
{
   TA_OptInput_IntegerRange,
   "optInTimePeriod",
   0,

   "Time Period",
   (const void *)&TA_DEF_TimePeriod_Positive,
   14,
   "Time period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_TimePeriod_10 =
{
   TA_OptInput_IntegerRange,
   "optInTimePeriod",
   0,

   "Time Period",
   (const void *)&TA_DEF_TimePeriod_Positive,
   10,
   "Time period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_TimePeriod_5 =
{
   TA_OptInput_IntegerRange,
   "optInTimePeriod",
   0,

   "Time Period",
   (const void *)&TA_DEF_TimePeriod_Positive,
   5,
   "Time period",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_NbDeviation =
{
   TA_OptInput_RealRange,
   "optInNbDev",
   0,

   "Deviations",
   (const void *)&TA_DEF_NbDeviation,
   1.0,
   "Nb of deviations",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_Penetration_30 =
{
   TA_OptInput_RealRange,
   "optInPenetration",
   0,

   "Penetration",
   (const void *)&TA_DEF_RealPositive,
   0.3,
   "Percentage of penetration of a candle within another candle",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_Penetration_50 =
{
   TA_OptInput_RealRange,
   "optInPenetration",
   0,

   "Penetration",
   (const void *)&TA_DEF_RealPositive,
   0.5,
   "Percentage of penetration of a candle within another candle",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_VerticalShift =
{
   TA_OptInput_RealRange,
   "optInVertShift",
   TA_OPTIN_IS_PERCENT,

   "Vertical Shift",
   (const void *)&TA_DEF_VerticalShiftPercent,
   0,
   "Positive number shift upwards, negative downwards",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_HorizontalShift =
{
   TA_OptInput_IntegerRange,
   "optInHorizShift",
   0,

   "Horizontal Shift",
   (const void *)&TA_DEF_HorizontalShiftPeriod,
   0,
   "Positive number shift 'n' period to the right, negative shift to the left",

   NULL
};

static const TA_IntegerDataPair TA_MA_TypeDataPair[] =
{
   {0,"SMA"},
   {1,"EMA"},
   {2,"WMA"},
   {3,"DEMA"},
   {4,"TEMA"},
   {5,"TRIMA"},
   {6,"KAMA"},
   {7,"MAMA"},
   {8,"T3"},
   {9,"HMA"},
   {10,"DISABLED"},
   {11,"DEFAULT"},
   {12,"ZLEMA"},
   {13,"RMA"}
};

const TA_IntegerList TA_MA_TypeList =
{
   &TA_MA_TypeDataPair[0],
   sizeof(TA_MA_TypeDataPair)/sizeof(TA_IntegerDataPair)
};

const TA_OptInputParameterInfo TA_DEF_UI_MA_Method =
{
   TA_OptInput_IntegerList,
   "optInMAType",
   0,

   "MA Type",
   (const void *)&TA_MA_TypeList,
   0,
   "Type of Moving Average",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_Fast_Period =
{
   TA_OptInput_IntegerRange,
   "optInFastPeriod",
   0,

   "Fast Period",
   (const void *)&TA_DEF_TimePeriod_Positive_Minimum2,
   12,
   "Period of the fast MA",

   NULL
};

const TA_OptInputParameterInfo TA_DEF_UI_Slow_Period =
{
   TA_OptInput_IntegerRange,
   "optInSlowPeriod",
   0,

   "Slow Period",
   (const void *)&TA_DEF_TimePeriod_Positive_Minimum2,
   26,
   "Period of the slow MA",

   NULL
};


#ifndef TA_TEST_PRIV_H
#define TA_TEST_PRIV_H

#ifndef TA_LIBC_H
   #include "ta_libc.h"
#endif

#ifndef TA_ERROR_NUMBER_H
   #include "ta_error_number.h"
#endif

typedef struct
{
   unsigned int nbBars; /* Nb of element into the following arrays. */

   /* The arrays containing data. Unused array are set to NULL. */
   TA_Real      *open;
   TA_Real      *high;
   TA_Real      *low;
   TA_Real      *close;
   TA_Real      *volume;
   TA_Real      *openInterest;
} TA_History;

ErrorNumber test_internals( void );
ErrorNumber test_abstract( void );

/* Set optional codegen server for abstract verification.
 * Pass NULL to disable. When set, test_abstract() also verifies
 * every TA_CallFunc against the server's abstract_call endpoint. */
#include "codegen_pipe.h"
void test_abstract_set_server(CodegenPipe *cp, const char *lang);

/* Run abstract metadata parity (TA_GetFuncInfo + the three param-info getters)
 * for every function against the server set via test_abstract_set_server(),
 * comparing to the C reference. Does NOT exercise abstract_call. Returns
 * TA_TEST_PASS on full parity. Used to lock cross-language introspection in CI. */
ErrorNumber test_abstract_server_metadata( const char *functionFilter );

ErrorNumber freeLib( void );
ErrorNumber allocLib( void );

void reportError( const char *str, TA_RetCode retCode );

/* Global Temporary Used by the ta_func_xxx function. */
 

typedef struct
{
   TA_Real *in;

   TA_Real *out0;
   TA_Real *out1;
   TA_Real *out2;
} TestBuffer;


/* That's quite a lot of global data, but who cares for
 * regression testing... it simplify memory alloc/dealloc.
 */
#define NB_GLOBAL_BUFFER 5
extern TestBuffer gBuffer[NB_GLOBAL_BUFFER];

/* Maximum number of element that can be written
 * at a gBuffer[n].ptr
 */
#define MAX_NB_TEST_ELEMENT 280

/* Must be called once to initialize the gBuffer. */
void initGlobalBuffer( void );

/* Will set to NAN all elements of gBuffer. */
void clearAllBuffers( void );

/* Initialize the 'gBuffer[i].in' with the provided data. */
void setInputBuffer( unsigned int i, const TA_Real *data, unsigned int nbElement );

/* Same as setInputBuffer but fill with a single value. */
void setInputBufferValue( unsigned int i, const TA_Real data, unsigned int nbElement );

/* Check that a buffer (within a TestBuffer) is not containing
 * NAN within the specified range (it also checks that all value
 * outside the range are untouched).
 *
 * Return TA_TEST_PASS if all ok.
 */
ErrorNumber checkForNAN( const TA_Real *buffer,
                         unsigned int nbElement );

/* Check that the 'data' is equal to the provided 
 * originalInput.
 *
 * The data must be one of the 'gBuffer[n].buffer'.
 *
 * It is also checked that all value outside of the
 * nbElement range are not-a-number.
 *
 * Return TA_TEST_PASS if no difference are found.
 */
ErrorNumber checkDataSame( const TA_Real *data,
                           const TA_Real *originalInput,
                           unsigned int nbElement );

/* Two runs of the SAME call (separate output buffer vs in-place): bit-identical.
 * Elements holding a reserved buffer pattern are skipped.
 *
 * Return TA_TEST_PASS if no difference are found.
 */
ErrorNumber checkSameContent( TA_Real *buffer1,
                              TA_Real *buffer2 );

/* Two DIFFERENT implementations of one function (naive reference vs shipped):
 * the contract is a tolerance, not bit-identity. */
ErrorNumber checkSameContentApprox( TA_Real *buffer1,
                                    TA_Real *buffer2 );

ErrorNumber checkExpectedValue( const TA_Real *data,
                                TA_RetCode retCode, TA_RetCode expectedRetCode,
                                unsigned int outBegIdx, unsigned int expectedBegIdx,
                                unsigned int outNbElement, unsigned int expectedNbElement,
                                TA_Real oneOfTheExpectedOutReal,
                                unsigned int oneOfTheExpectedOutRealIndex );

#define CHECK_EXPECTED_VALUE(bufid,id) \
   { \
      errNb = checkExpectedValue( bufid, \
                                  retCode, test->expectedRetCode, \
                                  outBegIdx, test->expectedBegIdx, \
                                  outNbElement, test->expectedNbElement, \
                                  test->oneOfTheExpectedOutReal##id, \
                                  test->oneOfTheExpectedOutRealIndex##id );  \
      if( errNb != TA_TEST_PASS ) \
      { \
         printf( "Fail for output id=%d\n", id ); \
         return errNb; \
      } \
   }

#define CLEAR_EXPECTED_VALUE(id) \
   { \
      retCode = TA_INTERNAL_ERROR(127); \
      outBegIdx = 0;\
      outNbElement = 0;\
   }


/* A systematic test can be done for most of the possible
 * range that a TA function can be called with. This test
 * is common to all TA function and can be easily done
 * with a RangeTestFunction. 
 *
 * The RangeTestFunction is making abstraction of the
 * TA function (handles the inputs, the parameters etc...)
 * The RangeTestFunction must call the TA function for
 * the requested startIdx/endIdx range and put the output
 * in the provided buffer.
 * 
 * The RangeTestFunction must also set the outBegIdx and
 * outNbElement for verification.
 *
 * Opaque data (for mostly passing optional parameters) are
 * pass through the pointer 'void * opaqueData'.
 *
 * The output of the function must be put in the outputBuffer
 * or outputBufferInt depending of the return type.
 */
#define MAX_RANGE_SIZE 252
#define MAX_RANGE_END  (MAX_RANGE_SIZE-1)

/* "This function has no unstable period" marker for the test tables.
 *
 * This was TA_FUNC_UNST_NONE, which the library used to publish. It was
 * useless in the public contract -- it is rejected as input and the library
 * never returns a TA_FuncUnstId -- so it was removed, and the only consumer
 * left was this harness. Any value outside 0..TA_FUNC_UNST_COUNT-1 that is
 * not the wildcard works; -1 keeps the tables reading as they did.
 */
#define TA_TEST_UNST_NONE ((TA_FuncUnstId)-1)

typedef TA_RetCode (*RangeTestFunction)( TA_Integer    startIdx,
                                         TA_Integer    endIdx,
                                         TA_Real      *outputBuffer,
                                         TA_Integer   *outputBufferInt,
                                         TA_Integer   *outBegIdx,
                                         TA_Integer   *outNbElement,
                                         TA_Integer   *lookback,
                                         void         *opaqueData,
                                         unsigned int  outputNb,
                                         unsigned int *isOutputInteger );

/* This is the function starting the range tests.
 * The parameter 'nbOutput' allows to repeat the
 * tests indepedently for each outputs.
 *
 * A lot of coherency tests are performed,
 * including comparing that the same value are
 * returned even when using a different startIdx
 * and endIdx.
 *
 * Because of the complexity added by algorithm that
 * have an unstable period, the comparison is
 * done using a tolerance algorithm (see test_util.c).
 *
 * Comparison can be ignored by specifiying 
 * an integerTolerance == TA_DO_NOT_COMPARE
 *
 * Even without comparison, a lot of coherency
 * tests are still performed (like making sure the
 * lookback function is coherent with its TA function).
 *
 * In the case that the TA function output are
 * integer, the integerTolerance indicate by how much
 * the value can vary for a function having an
 * unstable period. Example: If 2 is pass, the
 * value can vary of no more or less 2.
 * When passing zero, the tolerance is done using
 * a "reasonable" logic using double calculation (see
 * test_util.c for more info).
 */
#define TA_DO_NOT_COMPARE 0xFFFFFFFF

/* Explicit classification of how a function's output behaves when the SAME bar
 * is recomputed from a different startIdx (the range-test / self-coherency
 * property).
 *
 * This is DECOUPLED from TA_FuncUnstId on purpose. Whether a function carries an
 * unstable-period id (the sweep mechanism) is a separate concern from the
 * tolerance its numerical nature warrants. The tolerance tier used to be
 * *inferred* as "unstId == NONE ? tight : loose", which let a vestigial
 * unstable-period flag hand a finite-window function the loose convergence
 * tolerance and hide a real bug (IMI, issue #14; MFI, issue #4). The class is
 * now stated explicitly and cross-checked against the unstable-period id (see
 * the guard in doRangeTestEx).
 */
typedef enum
{
   TA_STABLE_EXACT,      /* Fresh-recomputed finite window -> bit-exact across
                          * ranges; any difference is a bug (e.g. IMI). */
   TA_STABLE_EPSILON,    /* Finite window via a running accumulator / algebraic
                          * re-order -> ~1e-10 FP drift only (e.g. MFI, running-
                          * sum MAs). */
   TA_STABLE_CONVERGING, /* Recursive / IIR -> the value depends on how far back
                          * the recursion started; the unstable period bounds the
                          * residual, so the tolerance is loose early and tightens
                          * (e.g. EMA, RSI, ADX, ATR, T3, HT_*). */
   TA_STABLE_SKIP        /* Non-converging accumulation seeded at startIdx or a
                          * path-dependent state machine -> cross-range
                          * comparison is meaningless. This set is the functions
                          * carrying the `path_dependent` YAML flag, surfaced
                          * through ta_abstract as TA_FUNC_FLG_PATH_DEP (issue
                          * #127; e.g. AD, OBV, SAR). */
} TA_RangeStability;

/* The most unstable-period ids one function may inherit. Two today (KC, through
 * TA_EMA and TA_ATR); the cap only sizes the caller's array. */
#define TA_MAX_SWEPT_UNST 4

/* Set every id of a sweep set to the same value. The range sweep warms only the
 * ids it is handed, so a function recursive through two different ids has to
 * move both together or the unhandled leg stays cold while the convergence
 * envelope tightens around it. */
void sweep_set_unstable( const TA_FuncUnstId *ids, int nbIds, unsigned int value );

ErrorNumber doRangeTest( RangeTestFunction testFunction,
                         TA_FuncUnstId unstId,
                         void *opaqueData,
                         unsigned int nbOutput,
                         unsigned int integerTolerance );

/* Same as doRangeTest, but the value-comparison tolerance is driven by an
 * explicit range-stability class instead of being inferred from unstId.
 * doRangeTest is a thin wrapper that derives the class from
 * (unstId, integerTolerance) for the legacy call sites. unstId is still
 * required here: it selects which unstable period to sweep and feeds the
 * convergence math for TA_STABLE_CONVERGING. */
ErrorNumber doRangeTestEx( RangeTestFunction testFunction,
                           TA_RangeStability stability,
                           TA_FuncUnstId unstId,
                           void *opaqueData,
                           unsigned int nbOutput,
                           unsigned int integerTolerance );

/* Same, for a function recursive through callees carrying DIFFERENT unstable
 * ids: every id in the set is swept together. doRangeTestEx is the one-id case.
 * The envelope reads the set's first member -- they all hold the same value. */
ErrorNumber doRangeTestMulti( RangeTestFunction testFunction,
                              TA_RangeStability stability,
                              const TA_FuncUnstId *unstIds,
                              int nbUnstIds,
                              void *opaqueData,
                              unsigned int nbOutput,
                              unsigned int integerTolerance );

/* Compare one computed value against an external-oracle golden.
 *
 * Passes when   |got - want| <= absTol + relTol * |want|.
 *
 * WHY NOT RELATIVE-ONLY. The original PVO/CMOU template divided by |want| and
 * justified it with "every golden |value| >> 1". That holds only because those
 * goldens were hand-picked away from zero. Relative error is UNBOUNDED as
 * want -> 0, so for any oscillator that crosses zero a relative-only check must
 * either be loosened until it no longer bites away from the crossing, or it
 * fails spuriously at it. Measured examples in this codebase's candidate set:
 * FOSC 8.6e-10 and AO 6.7e-13 relative at a crossing, against 8.9e-14 away from
 * one -- four orders of magnitude of spread that says nothing about correctness.
 *
 * This is the issue #107 abs-near-zero / rel-away-from-zero rule in the form
 * used by every mature numerical comparison. Choose absTol from the measured
 * noise floor AT a crossing, and relTol from the measured agreement where
 * |want| is O(1) or larger; a wrong formula misses by whole percent and is
 * caught by either term.
 *
 * Returns 1 on match, 0 on mismatch. On return, *outErr (optional) receives the
 * error in the regime that dominated and *outMode (optional) a short label
 * ("abs" or "rel") for use in the failure message.
 */
int checkOracleValue( double got, double want,
                      double relTol, double absTol,
                      double *outErr, const char **outMode );

/* Print out info about a retCode */
void printRetCode( TA_RetCode retCode );

/* Function to print character to show that the software is still alive. */
void showFeedback(void);
void hideFeedback(void);

#endif


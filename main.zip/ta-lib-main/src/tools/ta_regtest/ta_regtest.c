/* TA-LIB Copyright (c) 1999-2026, Mario Fortier
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 *
 * - Neither name of author nor the names of its contributors
 *   may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* List of contributors:
 *
 *  Initial  Name/description
 *  -------------------------------------------------------------------
 *  MF       Mario Fortier
 *  AC       Angelo Ciceri
 *  AB       Anatoliy Belsky
 *
 *
 * Change history:
 *
 *  MMDDYY BY   Description
 *  -------------------------------------------------------------------
 *  063001 MF   First version (initial framework only).
 *  090404 MF   Add test_candlestick
 *  110206 AC   Change volume and open interest to double
 *  122506 MF   Add MININDEX,MAXINDEX,MINMAX and MINMAXINDEX.
 *  101812 AB   Add AVGDEV.
 *  101912 AB   Add IMI.
 */

/* Description:
 *    Perform regression testing of the TA-LIB.
 */

/**** Headers ****/
#ifdef WIN32
   #include "windows.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "ta_test_priv.h"
#include "ta_test_func.h"
#include "test_codegen.h"
#include "codegen_pipe.h"
#include "server_verify.h"
#include "meta_ride.h"
#include "ta_utility.h"

/**** External functions declarations. ****/
/* None */

/**** External variables declarations. ****/
/* None */

/**** Global variables definitions.    ****/
/* CSV list of function names to test (NULL = test all) */
static const char *functionFilter = NULL;
static int doCodegenTest = 0;
static const char *refVersion = NULL;
static int doXlangHash = 0;
static const char *codegenLanguageFilter = NULL;
static unsigned int randSeed = 0;   /* 0 = pick one from the clock */

/**** Local declarations.              ****/
/* None */

/**** Local functions declarations.    ****/
static ErrorNumber testTAFunction_ALL( void );
static ErrorNumber test_with_simulator( void );
static void printUsage(void);
static ErrorNumber test_codegen_with_simulator( void );
static int svLanguageEnabled( const char *filter, const char *name );

/**** Local variables definitions.     ****/
/* None */

/* Exact-token match against the --language=CSV filter (NULL = all).
 * Same semantics as language_matches_filter in test_codegen.c.
 */
static int svLanguageEnabled( const char *filter, const char *name )
{
   char filterCopy[1024];
   char *token;
   if( filter == NULL ) return 1;
   strncpy(filterCopy, filter, sizeof(filterCopy) - 1);
   filterCopy[sizeof(filterCopy) - 1] = '\0';
   token = strtok(filterCopy, ",");
   while( token != NULL )
   {
      if( strcmp(name, token) == 0 ) return 1;
      token = strtok(NULL, ",");
   }
   return 0;
}

/* The tag a group is declared with is the `--function=` filter key, so it spells
 * out every function it covers and can run to any length. What gets printed is
 * width-bounded instead, so the "Testing" column lines up: a group whose tag
 * overflows gives a short label saying what it covers, and anything still too
 * long is cut with an ellipsis rather than pushing the column right. */
#define TAG_W 50

static const char *displayTag( const char *tag, const char *label )
{
   static char buf[TAG_W+1];
   const char *s = label ? label : tag;

   if( strlen(s) <= TAG_W )
      return s;
   memcpy( buf, s, TAG_W-3 );
   memcpy( buf+TAG_W-3, "...", 4 );
   return buf;
}

/**** Global functions definitions.   ****/
static ErrorNumber regtest_main( int argc, char **argv );

/* What the library reports about itself, asked once the first TA_Initialize has
 * returned and before any TA function has run: afterwards a loop has loaded its
 * own routine, and the answer says nothing about TA_Initialize.
 *
 * A kernel the library cannot load fails no value anywhere: only the speed is
 * lost. The kernel's platform is stated here, not taken from the library's own
 * switch, so that a kernel compiled out by mistake is not agreed with: keep the
 * two conditions written apart.
 */
static ErrorNumber runtimeInfoAfterFirstInitialize( void )
{
#if defined( __APPLE__ ) && defined( __aarch64__ ) && defined( __ENVIRONMENT_MAC_OS_X_VERSION_MIN_REQUIRED__ )
   const int wantKernel = 1;
#else
   const int wantKernel = TA_VMATH_KERNEL;
#endif
   int kernel = -1, nbInitialize = -1, nbShutdown = -1, untouched = 7;

   if( TA_GetRuntimeInfo( "vmath.transcendental", &kernel ) != TA_SUCCESS || kernel != wantKernel )
   {
      printf( "Fail: after TA_Initialize vmath.transcendental is %d, want %d on this build\n",
              kernel, wantKernel );
      return TA_TESTUTIL_INIT_FAILED;
   }
   if( TA_GetRuntimeInfo( "count.initialize", &nbInitialize ) != TA_SUCCESS ||
       TA_GetRuntimeInfo( "count.shutdown", &nbShutdown ) != TA_SUCCESS ||
       nbInitialize != 1 || nbShutdown != 0 )
   {
      printf( "Fail: after the first TA_Initialize count.initialize is %d and count.shutdown is %d\n",
              nbInitialize, nbShutdown );
      return TA_TESTUTIL_INIT_FAILED;
   }
   if( TA_GetRuntimeInfo( "vmath.SIN", &untouched ) != TA_BAD_PARAM ||
       TA_GetRuntimeInfo( "vmath", &untouched ) != TA_BAD_PARAM ||
       TA_GetRuntimeInfo( NULL, &untouched ) != TA_BAD_PARAM ||
       TA_GetRuntimeInfo( "vmath.transcendental", NULL ) != TA_BAD_PARAM ||
       untouched != 7 )
   {
      printf( "Fail: TA_GetRuntimeInfo accepts a key or an argument it must reject\n" );
      return TA_TESTUTIL_INIT_FAILED;
   }
   return TA_TEST_PASS;
}

/* A ride-along divergence fails the run that FOUND it.
 *
 * The ride is a passenger on the language servers, so every pass that drives
 * them computes verdicts -- the plain suite's abstract and server_verify legs,
 * --xlang-hash, and --codegen. Only --codegen read the verdict, because its
 * per-language floors are where the read lived; everywhere else a divergence
 * printed its diagnostic and the run still exited 0. */
int main( int argc, char **argv )
{
   ErrorNumber rideRet = regtest_main( argc, argv );

   if( codegen_ride_mismatches_ever() > 0 && rideRet == TA_TEST_PASS )
   {
      printf( "\nFAILED: %d ride-along divergence(s) -- batch and the streaming "
              "tiers disagreed on the caller's own data.\n",
              codegen_ride_mismatches_ever() );
      return TA_CODEGEN_RIDE_MISMATCH;
   }
   /* --codegen prints its own per-language census; this is the reach of every
    * OTHER pass, which had no number at all. */
   if( !doCodegenTest && codegen_ride_verdicts_ever() > 0 )
      printf( "  ride-along: %ld verdict(s), %ld rejection leg(s) compared\n",
              codegen_ride_verdicts_ever(), codegen_ride_rejects_ever() );
   return rideRet;
}

static ErrorNumber regtest_main( int argc, char **argv )
{
   ErrorNumber retValue;

   printf( "\n" );
   printf( "ta_regtest V%s - Regression Tests of TA-Lib code\n", TA_GetVersionString() );
   printf( "\n" );

   {
      int i;
      for( i = 1; i < argc; i++ )
      {
         if( strncmp(argv[i], "--function=", 11) == 0 )
         {
            functionFilter = argv[i] + 11;
         }
         else if( strcmp(argv[i], "--codegen") == 0 )
         {
            doCodegenTest = 1;
         }
         else if( strncmp(argv[i], "--codegen=", 10) == 0 )
         {
            doCodegenTest = 1;
            codegenLanguageFilter = argv[i] + 10;
         }
         else if( strncmp(argv[i], "--language=", 11) == 0 )
         {
            codegenLanguageFilter = argv[i] + 11;
         }
         else if( strncmp(argv[i], "--ref=", 6) == 0 && argv[i][6] )
         {
            refVersion = argv[i] + 6;
         }
         else if( strcmp(argv[i], "--xlang-hash") == 0 )
         {
            doXlangHash = 1;
         }
         else if( strncmp(argv[i], "--seed=", 7) == 0 )
         {
            randSeed = (unsigned int)strtoul( argv[i] + 7, NULL, 10 );
         }
         else if( strcmp(argv[i], "--no-guarded") == 0 )
         {
            extern int g_hideGuarded;
            g_hideGuarded = 1;
         }
         else
         {
            printUsage();
            return TA_REGTEST_BAD_USER_PARAM;
         }
      }
   }

   /* --ref and --xlang-hash each run their gate and RETURN, below, before
    * the normal suite. So pairing either with the other or with --codegen runs
    * whichever comes first and silently drops the rest -- `--codegen
    * --xlang-hash` produced the parity gate and ZERO stream_verify legs while
    * reading like it had run both. Reject the combination rather than pick a
    * winner: making them additive would put the whole C suite inside the
    * nightly's xlang-hash job, which is not what that job is for.
    */
   if( ((refVersion != NULL) + doXlangHash + doCodegenTest) > 1 )
   {
      printf( "Error: --codegen, --ref and --xlang-hash are separate runs.\n" );
      printf( "       --ref and --xlang-hash each return before anything\n" );
      printf( "       else can run, so combining them silently skips the rest.\n" );
      printf( "       Use one per invocation.\n" );
      return TA_REGTEST_BAD_USER_PARAM;
   }

   /* Some tests are using randomness: the range sweeps pick their startIdx and
    * sizes with rand(), so each run covers a different subset. Printed so a
    * failure can be replayed with --seed=N. */
   if( randSeed == 0 )
      randSeed = (unsigned int)time( NULL );
   printf( "Random seed: %u  (replay with --seed=%u)\n", randSeed, randSeed );
   srand( randSeed );

   /* The output-arity cap must hold before anything sizes or clamps by it
    * (issue #352) — checked here rather than inside test_codegen() because
    * --ref and --xlang-hash below are self-contained early returns that
    * never reach it, and their buffers clamp at the same cap. */
   {
      ErrorNumber arityRet;
      if( TA_Initialize() != TA_SUCCESS )
      {
         printf( "TA_Initialize failed\n" );
         return TA_TESTUTIL_INIT_FAILED;
      }
      arityRet = runtimeInfoAfterFirstInitialize();
      if( arityRet == TA_TEST_PASS )
         arityRet = codegen_output_arity_within_cap();
      TA_Shutdown();
      if( arityRet != TA_TEST_PASS )
         return arityRet;
   }

   /* Differential fuzz vs one frozen release (bin/ta_ref_<X_Y_Z>_serve).
    * Self-contained: init the lib, run the fuzz, done — skips the rest. */
   if( refVersion != NULL )
   {
      ErrorNumber fuzzRet;
      if( TA_Initialize() != TA_SUCCESS )
      {
         printf( "TA_Initialize failed\n" );
         return TA_TESTUTIL_INIT_FAILED;
      }
      TA_RestoreCandleDefaultSettings( TA_AllCandleSettings );
      fuzzRet = fuzz_ref( refVersion, functionFilter );
      retValue = freeLib();
      return fuzzRet != TA_TEST_PASS ? fuzzRet : retValue;
   }

   /* Opt-in cross-language BITWISE parity gate (issue #113). Self-contained:
    * init the lib (the in-process C golden), run the gate, done. Must run from
    * the bin/ directory so the language servers launch (like --ref). */
   if( doXlangHash )
   {
      ErrorNumber xlangRet;
      if( TA_Initialize() != TA_SUCCESS )
      {
         printf( "TA_Initialize failed\n" );
         return TA_TESTUTIL_INIT_FAILED;
      }
      TA_RestoreCandleDefaultSettings( TA_AllCandleSettings );
      xlangRet = xlang_hash( functionFilter, codegenLanguageFilter );
      retValue = freeLib();
      return xlangRet != TA_TEST_PASS ? xlangRet : retValue;
   }

   /* Test utility like List/Stack/Dictionary/Memory Allocation etc... */
   printf( "%*s: Testing....", TAG_W, "Utility functions" );
   fflush(stdout);
   showFeedback();
   retValue = test_internals();
   if( retValue != TA_TEST_PASS )
   {
      printf( "\nFailed an internal test with code=%d\n", retValue );
      return retValue;
   }
   /* Shares this group's output line: the range sweep's unstable-id table is
    * harness state, and a bare run must not be able to leave it inconsistent. */
   retValue = test_codegen_unstable_map();
   if( retValue != TA_TEST_PASS )
   {
      printf( "\nFailed the unstable-period map check with code=%d\n", retValue );
      return retValue;
   }
   hideFeedback();
   printf( "done.\n" );
   fflush(stdout);

   /* A server that will not start is only a legitimate skip when the caller
    * did not ask for that language. `--language=csharp` on a box without the
    * .NET SDK must fail loudly: "green because nothing ran" is the failure
    * mode every gate in this file exists to prevent.
    *
    * CODEGEN_PIPE_SUPPORTED excludes Windows, where codegen_pipe_open is an
    * unconditional-failure stub: there EVERY server is unavailable by design,
    * the C reference tests are the whole contract, and hard-failing would break
    * `--codegen --language=<anything>` for every Windows developer. */
#define ABSTRACT_SERVER_MISSING(lang, filter, rv)                                  \
   do {                                                                            \
      if( (filter) != NULL && CODEGEN_PIPE_SUPPORTED ) {                           \
         printf( "  ABSTRACT ERROR: --language named %s but its server could not " \
                 "be started\n", (lang) );                                         \
         if( (rv) == TA_TEST_PASS ) (rv) = TA_ABSTRACT_SERVER_ERROR;               \
      } else {                                                                     \
         printf( "  (%s server not available, skipping %s abstract parity)\n",     \
                 (lang), (lang) );                                                 \
      }                                                                            \
   } while(0)

   /* Test abstract interface.
    * When codegen mode is active, also verify each call against the server.
    * The line covers the whole phase, cross-language legs included, so it closes
    * at the retValue check below rather than at test_abstract() itself.
    */
   printf( "%*s: Testing....", TAG_W, "Abstract interface" );
   fflush(stdout);
   showFeedback();
   {
      CodegenPipe abstractPipe;
      int abstractPipeOpen = 0;
      ErrorNumber cMetaErr = TA_TEST_PASS;
      /* Only spawn the C server for abstract verification when C is actually in
       * the language filter. Under --language=rust the C server is not built
       * (regtest.py compiles servers with --backend=rust), so spawning it would
       * execvp a missing binary and surface as a confusing first-call pipe EOF.
       * The Rust abstract parity below has the matching guard for "rust". */
      if( doCodegenTest && svLanguageEnabled( codegenLanguageFilter, "c" ) )
      {
         /* Build server path relative to the ta_regtest executable,
          * so it works regardless of the current working directory. */
         char serverPath[1024];
         {
            const char *self = argv[0];
            const char *lastSlash = strrchr(self, '/');
            if( lastSlash ) {
               int dirLen = (int)(lastSlash - self + 1);
               snprintf(serverPath, sizeof(serverPath), "%.*sta_codegen_serve_c",
                        dirLen, self);
            } else {
               snprintf(serverPath, sizeof(serverPath), "./ta_codegen_serve_c");
            }
         }
         const char *const serverArgv[] = {serverPath, NULL};
         if( codegen_pipe_open(&abstractPipe, serverArgv) == TA_TEST_PASS )
         {
            test_abstract_set_server(&abstractPipe, "c");
            abstractPipeOpen = 1;
            /* The control arm. C's server answers the metadata RPCs from the
             * very ta_abstract this compares against, so a failure here is a
             * defect in the comparator, not in a backend — which is what makes
             * a failure on Rust/Java/C# meaningful. It is also the only caller
             * that reaches C's own abstract_for_each_func handler. */
            cMetaErr = test_abstract_server_metadata(functionFilter);
         }
         else
         {
            printf( "  (server not available, C only)\n" );
         }
      }
      retValue = test_abstract();
      if( retValue == TA_TEST_PASS )
         retValue = cMetaErr;
      test_abstract_set_server(NULL, NULL);
      if( abstractPipeOpen )
         codegen_pipe_close(&abstractPipe);
   }

   /* Cross-language abstract parity (dev / merge-loop gate via --codegen):
    * run the full ta_abstract path against the Rust server, comparing to the C
    * reference. Two complementary passes:
    *   1. test_abstract_server_metadata — the metadata RPCs (TA_GetFuncInfo + the
    *      param-info getters), which the dynamic path below does NOT exercise.
    *   2. test_abstract — the dynamic-dispatch path (abstract_call /
    *      abstract_get_lookback / TA_FunctionDescriptionXML), comparing output
    *      VALUES (not just metadata) for every function.
    * NOTE: the autotools dist nightly runs ta_regtest with no args, so this block
    * only runs under --codegen (build.py regtest / regtest.py),
    * not the dist verification path. */
   if( retValue == TA_TEST_PASS && doCodegenTest &&
       ( codegenLanguageFilter == NULL || strstr(codegenLanguageFilter, "rust") != NULL ) )
   {
      CodegenPipe rustAbstractPipe;
      char rustServerPath[1024];
      const char *self = argv[0];
      const char *lastSlash = strrchr(self, '/');
      if( lastSlash ) {
         int dirLen = (int)(lastSlash - self + 1);
         snprintf(rustServerPath, sizeof(rustServerPath), "%.*sta_codegen_serve_rust",
                  dirLen, self);
      } else {
         snprintf(rustServerPath, sizeof(rustServerPath), "./ta_codegen_serve_rust");
      }
      {
         const char *const rustArgv[] = {rustServerPath, NULL};
         if( codegen_pipe_open(&rustAbstractPipe, rustArgv) == TA_TEST_PASS )
         {
            ErrorNumber e;
            test_abstract_set_server(&rustAbstractPipe, "rust");
            e = test_abstract_server_metadata(functionFilter);
            /* Full dynamic-dispatch path (abstract_call / abstract_get_lookback /
             * TA_FunctionDescriptionXML) against the Rust server, comparing output
             * VALUES to the C for every function. */
            if( e == TA_TEST_PASS )
            {
               e = test_abstract();
            }
            test_abstract_set_server(NULL, NULL);
            codegen_pipe_close(&rustAbstractPipe);
            if( retValue == TA_TEST_PASS && e != TA_TEST_PASS )
               retValue = e;
         }
         else
         {
            ABSTRACT_SERVER_MISSING("rust", codegenLanguageFilter, retValue);
         }
      }
   }

   /* Java abstract parity (issue #114): metadata RPCs (TA_GetFuncInfo + the
    * param-info getters) AND the dynamic-dispatch path (abstract_call /
    * abstract_get_lookback / TA_FunctionDescriptionXML), comparing output VALUES
    * to the C reference for every function. Java server spawns via
    * `java -cp ta_codegen_java TaCodegenServe`. */
   if( retValue == TA_TEST_PASS && doCodegenTest &&
       ( codegenLanguageFilter == NULL || strstr(codegenLanguageFilter, "java") != NULL ) )
   {
      CodegenPipe javaAbstractPipe;
      const char *const javaArgv[] = {"java", "-cp", "ta_codegen_java", "TaCodegenServe", NULL};
      if( codegen_pipe_open(&javaAbstractPipe, javaArgv) == TA_TEST_PASS )
      {
         ErrorNumber e;
         test_abstract_set_server(&javaAbstractPipe, "java");
         e = test_abstract_server_metadata(functionFilter);
         if( e == TA_TEST_PASS )
         {
            e = test_abstract();
         }
         test_abstract_set_server(NULL, NULL);
         codegen_pipe_close(&javaAbstractPipe);
         if( retValue == TA_TEST_PASS && e != TA_TEST_PASS )
            retValue = e;
      }
      else
      {
         ABSTRACT_SERVER_MISSING("java", codegenLanguageFilter, retValue);
      }
   }

   /* C# abstract parity: the same two passes as Java and Rust — the metadata
    * RPCs (TA_GetFuncInfo + the param-info getters) and the dynamic-dispatch
    * path (abstract_call / abstract_get_lookback / TA_FunctionDescriptionXML),
    * comparing output VALUES to the C reference for every function.
    *
    * Without this block the C# server's abstract RPCs would have exactly zero
    * coverage and every gate would stay green: test_abstract_server_metadata()
    * and the server legs of test_abstract() both short-circuit to TA_TEST_PASS
    * when no pipe is set. The managed server spawns via
    * `dotnet ta_codegen_csharp/TaCodegenServe.dll`. */
   if( retValue == TA_TEST_PASS && doCodegenTest &&
       ( codegenLanguageFilter == NULL || strstr(codegenLanguageFilter, "csharp") != NULL ) )
   {
      CodegenPipe csharpAbstractPipe;
      const char *const csharpArgv[] = {"dotnet", "ta_codegen_csharp/TaCodegenServe.dll", NULL};
      if( codegen_pipe_open(&csharpAbstractPipe, csharpArgv) == TA_TEST_PASS )
      {
         ErrorNumber e;
         test_abstract_set_server(&csharpAbstractPipe, "csharp");
         e = test_abstract_server_metadata(functionFilter);
         if( e == TA_TEST_PASS )
         {
            e = test_abstract();
         }
         test_abstract_set_server(NULL, NULL);
         codegen_pipe_close(&csharpAbstractPipe);
         if( retValue == TA_TEST_PASS && e != TA_TEST_PASS )
            retValue = e;
      }
      else
      {
         ABSTRACT_SERVER_MISSING("csharp", codegenLanguageFilter, retValue);
      }
   }
#undef ABSTRACT_SERVER_MISSING

   if( retValue != TA_TEST_PASS )
   {
      printf( "\nFailed: Abstract interface Tests (error number = %d)\n", retValue );
      return retValue;
   }
   hideFeedback();
   printf( "done.\n" );
   fflush(stdout);

   {
      /* When codegen mode is active, also verify hand-written tests
       * against every available language server (C, Rust, Java, C#),
       * honoring --language=CSV. The Java/C# launch commands are
       * relative to the bin directory (same as test_codegen.c).
       */
      CodegenPipe svPipes[SV_MAX_PIPES];
      const char *svPipeLang[SV_MAX_PIPES] = {0};
      int nbSvPipes = 0;
      if( doCodegenTest )
      {
         char svPathC[1024];
         char svPathRust[1024];
         const char *self = argv[0];
         const char *lastSlash = strrchr(self, '/');
         if( lastSlash ) {
            int dirLen = (int)(lastSlash - self + 1);
            snprintf(svPathC, sizeof(svPathC), "%.*sta_codegen_serve_c",
                     dirLen, self);
            snprintf(svPathRust, sizeof(svPathRust), "%.*sta_codegen_serve_rust",
                     dirLen, self);
         } else {
            snprintf(svPathC, sizeof(svPathC), "./ta_codegen_serve_c");
            snprintf(svPathRust, sizeof(svPathRust), "./ta_codegen_serve_rust");
         }
         const char *const svArgvC[]      = {svPathC, NULL};
         const char *const svArgvRust[]   = {svPathRust, NULL};
         const char *const svArgvJava[]   = {"java", "-cp", "ta_codegen_java",
                                             "TaCodegenServe", NULL};
         const char *const svArgvCsharp[] = {"dotnet",
                                             "ta_codegen_csharp/TaCodegenServe.dll", NULL};
         const struct { const char *lang; const char *const *argvSv; } svServers[] = {
            { "c",      svArgvC },
            { "rust",   svArgvRust },
            { "java",   svArgvJava },
            { "csharp", svArgvCsharp },
         };
         unsigned int svIdx;
         for( svIdx = 0; svIdx < sizeof(svServers)/sizeof(svServers[0]); svIdx++ )
         {
            if( !svLanguageEnabled(codegenLanguageFilter, svServers[svIdx].lang) )
               continue;
            if( codegen_pipe_open(&svPipes[nbSvPipes], svServers[svIdx].argvSv) == TA_TEST_PASS )
            {
               svPipeLang[nbSvPipes] = svServers[svIdx].lang;
               nbSvPipes++;
            }
            else
               printf( "  (%s server not available for hand-written test verification)\n",
                       svServers[svIdx].lang );
         }
         if( nbSvPipes > 0 )
         {
            CodegenPipe *pipes[SV_MAX_PIPES];
            int p;
            for( p = 0; p < nbSvPipes; p++ )
               pipes[p] = &svPipes[p];
            server_verify_init(pipes, svPipeLang, nbSvPipes);
         }
      }

      retValue = test_with_simulator();

      if( nbSvPipes > 0 )
      {
         int p;
         /* The ride-along ran on the hand-written cases' own arrays. A pipe that
          * offered the check must have compared bars on at least one of them;
          * per pipe, because a total stays green while one server goes silent. */
         if( retValue == TA_TEST_PASS && server_verify_ride_cases() > 0 &&
             server_verify_ride_silent_pipes() > 0 )
         {
            printf("RIDE VACUOUS (hand-written cases): %d of %d server(s) offered "
                   "the batch-vs-stream check but compared no bars\n",
                   server_verify_ride_silent_pipes(), nbSvPipes);
            retValue = TA_CODEGEN_RIDE_VACUOUS;
         }
         server_verify_shutdown();
         for( p = 0; p < nbSvPipes; p++ )
            codegen_pipe_close(&svPipes[p]);
      }

      if( retValue != TA_TEST_PASS )
         return retValue;
   }

   if( doCodegenTest )
   {
      retValue = test_codegen_with_simulator();
      if( retValue != TA_TEST_PASS )
         return retValue;
   }

   printf( "\n* All tests succeeded. Enjoy the library. *\n" );


   return TA_TEST_PASS; /* Everything succeed !!! */
}

/**** Local functions definitions.     ****/
static ErrorNumber test_with_simulator( void )
{
   ErrorNumber retValue;

   /* Initialize the library. */
   retValue = allocLib();
   if( retValue != TA_TEST_PASS )
      return retValue;

   /* Perform testing of each of the TA Functions. */
   retValue = testTAFunction_ALL();
   if( retValue != TA_TEST_PASS )
   {
      return retValue;
   }

   if( functionFilter == NULL )
   {
      retValue = meta_ride_whole_run();
      if( retValue != TA_TEST_PASS )
         return retValue;
   }

   /* Clean-up and exit. */

   retValue = freeLib( );
   if( retValue != TA_TEST_PASS )
      return retValue;

   return TA_TEST_PASS; /* All test succeed. */
}

extern TA_Real      TA_SREF_open_daily_ref_0_PRIV[];
extern TA_Real      TA_SREF_high_daily_ref_0_PRIV[];
extern TA_Real      TA_SREF_low_daily_ref_0_PRIV[];
extern TA_Real      TA_SREF_close_daily_ref_0_PRIV[];
extern TA_Real      TA_SREF_volume_daily_ref_0_PRIV[];

static ErrorNumber test_codegen_with_simulator( void )
{
   ErrorNumber retValue;
   TA_History history;

   retValue = allocLib();
   if( retValue != TA_TEST_PASS )
      return retValue;

   history.nbBars = 252;
   history.open   = TA_SREF_open_daily_ref_0_PRIV;
   history.high   = TA_SREF_high_daily_ref_0_PRIV;
   history.low    = TA_SREF_low_daily_ref_0_PRIV;
   history.close  = TA_SREF_close_daily_ref_0_PRIV;
   history.volume = TA_SREF_volume_daily_ref_0_PRIV;
   history.openInterest = NULL;   /* the test series carries no OI; honor the
                                     "unused arrays are NULL" contract so readers
                                     (test_variants.c build_regime) can trust it */

   retValue = test_codegen(&history, codegenLanguageFilter, functionFilter);
   if( retValue != TA_TEST_PASS )
      return retValue;

   retValue = freeLib();
   if( retValue != TA_TEST_PASS )
      return retValue;

   return TA_TEST_PASS;
}

/* Check if any CSV token in 'filter' appears as a substring in 'tags'.
 * Returns 1 if match found (or filter is NULL), 0 otherwise.
 */
/* Does any '*'-suffixed element of `tags` prefix `token`?
 *
 * A tag element ending in '*' is a PREFIX CLAIM: the group covers every
 * function whose name starts with it. The plain substring rule asks whether the
 * TAG contains the user's token, so reaching a family of functions otherwise
 * means spelling every member into the tag -- which is what issue #137 did for
 * the composite group, and it goes stale the moment a new member lands. It went
 * stale here: all 61 CDL* names were unreachable, so `--function=CDLDOJI` ran
 * the candlestick group zero times and still printed "All tests succeeded".
 */
static int tagPrefixMatches(const char *tags, const char *token)
{
   const char *p = tags;

   while( *p )
   {
      const char *star = strchr(p, '*');
      const char *start;
      size_t len;

      if( star == NULL )
         return 0;
      start = star;
      while( start > tags && start[-1] != ',' )
         start--;
      len = (size_t)(star - start);
      if( len > 0 && strncmp(token, start, len) == 0 )
         return 1;
      p = star + 1;
   }
   return 0;
}

/* Does any comma-separated element of `tags` accept this short token, by the
 * '_'-component rule in test_codegen.h? The group tag is a list of names, so the
 * rule applies per element: "DI" reaches the tag holding PLUS_DI and MINUS_DI.
 */
static int tagHasShortToken(const char *tags, const char *token)
{
   char elem[128];
   const char *p = tags;

   while( *p )
   {
      const char *end = strchr(p, ',');
      size_t elemLen = (end == NULL) ? strlen(p) : (size_t)(end - p);

      if( elemLen < sizeof(elem) )
      {
         memcpy(elem, p, elemLen);
         elem[elemLen] = '\0';
         if( codegen_short_filter_token_matches(elem, token) )
            return 1;
      }
      if( end == NULL )
         return 0;
      p = end + 1;
   }
   return 0;
}

static int matchesFilter(const char *filter, const char *tags)
{
   char filterCopy[1024];
   char *token;

   if( filter == NULL )
      return 1; /* No filter = run everything */

   strncpy(filterCopy, filter, sizeof(filterCopy) - 1);
   filterCopy[sizeof(filterCopy) - 1] = '\0';

   token = strtok(filterCopy, ",");
   while( token != NULL )
   {
      if( strlen(token) <= 2 )
      {
         if( tagHasShortToken(tags, token) )
            return 1;
      }
      else if( strstr(tags, token) != NULL )
         return 1;
      if( tagPrefixMatches(tags, token) )
         return 1;
      token = strtok(NULL, ",");
   }
   return 0;
}

static ErrorNumber testTAFunction_ALL( void )
{
   ErrorNumber retValue;
   TA_History history;
   int nbGroupsRun = 0;

   history.nbBars = 252;
   history.open   = TA_SREF_open_daily_ref_0_PRIV;
   history.high   = TA_SREF_high_daily_ref_0_PRIV;
   history.low    = TA_SREF_low_daily_ref_0_PRIV;
   history.close  = TA_SREF_close_daily_ref_0_PRIV;
   history.volume = TA_SREF_volume_daily_ref_0_PRIV;
   history.openInterest = NULL;   /* the test series carries no OI; honor the
                                     "unused arrays are NULL" contract so readers
                                     (test_variants.c build_regime) can trust it */

   initGlobalBuffer();

   /* Make tests for each TA functions.
    *
    * Under --codegen every group must hand at least one of its own vectors to
    * server_verify, so the hand-written case is checked ACROSS languages and
    * not only against its own constants (#427). The floor lives here because
    * this macro is the one chokepoint a new test file must already edit, and
    * because it tests the effect rather than the text: server_verify answers
    * TA_TEST_PASS without comparing when it has no pipes, when the call was a
    * rejection, or when it cannot build the request, so a call that is present
    * and dead reads exactly like no call at all.
    *
    * DO_TEST_NOSV is the opt-out, for a group with nothing to route: no public
    * batch call at all (the streaming tiers, the TA_S_ float tier, no TA
    * function), or only the corpus and parameters the sweep already sends,
    * where a routed call duplicates a comparison instead of adding one. The
    * reason belongs on a SERVER_VERIFY: line in that group's file header. */
   #define DO_TEST(func,str) DO_TEST_FULL(func,str,NULL,1)
   #define DO_TEST_LBL(func,str,label) DO_TEST_FULL(func,str,label,1)
   #define DO_TEST_NOSV(func,str) DO_TEST_FULL(func,str,NULL,0)
   #define DO_TEST_LBL_NOSV(func,str,label) DO_TEST_FULL(func,str,label,0)
   #define DO_TEST_FULL(func,str,label,wantSv) \
      { \
      if( matchesFilter(functionFilter, str) ) \
      { \
         int svBefore = server_verify_value_comparisons(); \
         nbGroupsRun++; \
         printf( "%*s: Testing....", TAG_W, displayTag(str,label) ); \
         fflush(stdout); \
         showFeedback(); \
         retValue = func( &history ); \
         if( retValue != TA_TEST_PASS ) \
         { \
            printf( "\nFailed group [%s] with code=%d\n", str, retValue ); \
            return retValue; \
         } \
         hideFeedback(); \
         if( (wantSv) && server_verify_active() && \
             server_verify_value_comparisons() == svBefore ) \
         { \
            printf( "\nSERVER_VERIFY MISSING [%s]: the group ran under --codegen " \
                    "and compared no output value against any language server. " \
                    "Route one of its vectors through server_verify, or mark the " \
                    "row DO_TEST_NOSV with the reason in the file header.\n", str ); \
            return TA_SV_ROUTED_VACUOUS; \
         } \
         printf( "done.\n" ); \
         fflush(stdout); \
      } \
      }
   DO_TEST_LBL( test_func_1in_1out, "MATH,VECTOR,DCPERIOD/PHASE,TRENDLINE/MODE,"
                                "HT_DCPERIOD,HT_DCPHASE,HT_TRENDLINE,HT_TRENDMODE,MEDPRICE,"
                                "ACOS,ASIN,ATAN,COS,COSH,EXP,LN,LOG10,SIN,SINH,TAN,TANH",
                                "Math, vector, Hilbert Transforms, MEDPRICE" );
   DO_TEST_LBL( test_func_ma,   "All Moving Averages,"
                                "SMA,EMA,WMA,DEMA,TEMA,TRIMA,KAMA,MAMA,T3,MA",
                                "All Moving Averages (SMA..T3, MA)" );
   DO_TEST( test_func_wma,      "WMA,HMA/RESEED" );
   DO_TEST( test_func_per_hl,   "AROON,AROONOSC,CORREL,BETA,MIDPRICE" );
   DO_TEST( test_func_per_hlc,  "CCI,WILLR,ULTOSC,NATR,ACCBANDS,WAD" );
   DO_TEST( test_func_per_ohlc, "BOP,AVGPRICE" );
   DO_TEST( test_func_rsi,      "RSI,CMO" );
   DO_TEST( test_func_imi, "IMI" );
   DO_TEST_LBL( test_func_minmax, "MIN,MAX,MININDEX,MAXINDEX,MINMAX,MINMAXINDEX,MIDPOINT",
                                "Rolling min/max family, MIDPOINT" );
   DO_TEST( test_func_po,       "PO,APO,PPO" );
   DO_TEST_LBL( test_func_adx,  "ADX,ADXR,DI,DM,DX,PLUS_DI,PLUS_DM,MINUS_DI,MINUS_DM",
                                "Wilder Directional Movement (ADX/DI/DM)" );
   DO_TEST( test_func_sar,      "SAR,SAREXT" );
   DO_TEST( test_func_stoch,    "STOCH,STOCHF,STOCHRSI" );
   DO_TEST( test_func_per_hlcv, "MFI,AD,ADOSC" );
   DO_TEST( test_func_per_cv,   "NVI,PVI,PVT" );
   DO_TEST( test_func_1in_2out, "PHASOR,SINE,HT_PHASOR,HT_SINE" );
   DO_TEST( test_func_per_ema,  "TRIX" );
   DO_TEST( test_func_macd,     "MACD,MACDFIX,MACDEXT" );
   DO_TEST( test_func_mom_roc,  "MOM,ROC,ROCP,ROCR,ROCR100" );
   DO_TEST( test_func_trange,   "TRANGE,ATR" );
   /* Not a TA function: the shared reference battery checking itself (#251).
    * FIRST, deliberately. DO_TEST returns on the first failure, so registering
    * this after the suites that consume its goldens meant a corrupted or stale
    * table took test_func_stddev down first and the one diagnostic that would
    * name the real cause never ran -- the leg would have been silent in exactly
    * the case it exists for. */
   DO_TEST_LBL_NOSV( test_func_reference, "REFERENCE,GOLDEN,ORACLE,NUMERICS",
                                "Statistical reference: NIST StRD, Wilkinson" );
   DO_TEST( test_func_stddev,   "STDDEV,VAR" );
   DO_TEST( test_func_kurtosis, "KURTOSIS" );
   DO_TEST( test_func_median,   "MEDIAN" );
   /* CORREL numerical robustness (#242). Separate from the per_hl group so the
    * probes can be reached on their own; --function=CORREL matches both. */
   DO_TEST( test_func_correl,   "CORREL/NUMERICS" );
   DO_TEST( test_func_cti,      "CTI" );
   DO_TEST( test_func_beta,     "BETA/NUMERICS" );
   /* The TA_LINEARREG family and TA_TSF had no DEDICATED reference file before
    * #251. They were not uncovered: test_period_boundary.c's
    * testLinearRegRampOverflowProbe (#142) checks all five against a closed form
    * at period 1025, and the --codegen leg range-tests them via
    * stability_class(). This file adds the reference datasets and the
    * arbitrary-value goldens, and does NOT subsume either -- no leg here exceeds
    * period 60. */
   DO_TEST_LBL( test_func_linearreg,
            "LINEARREG,LINEARREG_SLOPE,LINEARREG_ANGLE,LINEARREG_INTERCEPT,TSF",
            "Linear regression family, TSF" );
   DO_TEST( test_func_avgdev,   "AVGDEV" );
   DO_TEST( test_func_bbands,   "BBANDS" );
   DO_TEST( test_func_period_boundary, "PERIOD1/BOUNDARY" );
   /* Corpus-wide, like the sweep above, so the tag names the property rather
    * than a function list: changing the quote unit by a power of two must not
    * change any answer (#253). */
   DO_TEST( test_func_quote_unit, "QUOTE-UNIT/SCALE" );
   DO_TEST( test_func_mavp,     "MAVP/GROUPING" );
   DO_TEST( test_func_s_overflow, "MATH,ADD,SUB,MULT,DIV" );
   DO_TEST( test_func_div_zero, "DIV,DIVZERO" );
   /* CDL* is a prefix claim: this one group covers every candlestick, so
    * naming any of them reaches it without the tag listing all 61. */
   DO_TEST( test_candlestick,   "All Candlesticks,CDL*" );
   /* The tag is what --function= substring-matches, so every function the
    * group covers must appear in it: --function=VWMA matched nothing before
    * VWMA was named here (issue #137). */
   /* Composite functions -- indicators defined as an exact arithmetic
    * composition of shipped primitives. Split by file (composite1, composite2,
    * ...) rather than by indicator: one file per group is the convention here,
    * and a single file had grown past 4000 lines. Each carries its own tag, so
    * --function= reaches the members of whichever file they live in. */
   DO_TEST( test_func_composite1, "PVO,VWMA,CMF,HMA,EFI,QSTICK,AO,AC,SUM" );
   DO_TEST( test_func_composite2, "SMI,COPPOCK,ER" );
   DO_TEST( test_func_marketfi, "MARKETFI" );
   DO_TEST( test_func_fisher,   "FISHER" );
   DO_TEST( test_func_pso, "PSO" );
   DO_TEST( test_func_rogerssatchell, "ROGERSSATCHELL" );
   DO_TEST( test_func_emv,       "EMV" );
   DO_TEST( test_func_ibs,       "IBS" );
   DO_TEST( test_func_kst,       "KST" );
   DO_TEST( test_func_kstext,    "KSTEXT" );
   DO_TEST( test_func_chop,      "CHOP,CHOPTR" );
   DO_TEST( test_func_cmf,       "CMF" );
   DO_TEST( test_func_kc,        "KC" );
   DO_TEST( test_func_donchian,  "DONCHIAN" );
   DO_TEST( test_func_rma,       "RMA" );
   DO_TEST( test_func_cksp,      "CKSP" );
   DO_TEST( test_func_supertrend, "SUPERTREND" );
   DO_TEST( test_func_mfi,       "MFI" );
   DO_TEST( test_func_vwap,      "VWAP" );
   DO_TEST( test_func_cmou,      "CMOU" );
   DO_TEST( test_func_vortex,    "VORTEX" );
   DO_TEST( test_func_eri,       "ERI" );
   DO_TEST( test_func_cumsum,    "CUMSUM" );
   DO_TEST( test_func_zlema,     "ZLEMA" );
   DO_TEST( test_func_vhf,       "VHF" );
   DO_TEST( test_func_rvi,       "RVI" );
   DO_TEST( test_func_rvir,      "RVIR" );
   DO_TEST( test_func_frama,     "FRAMA" );
   DO_TEST( test_func_mcgd,      "MCGD" );
   DO_TEST( test_func_vidya,     "VIDYA" );
   DO_TEST( test_func_alma,      "ALMA" );
   DO_TEST( test_func_stc,       "STC" );
   DO_TEST( test_func_swak,      "SWAK_GAUSS,SWAK_BUTTER,SWAK_HP,SWAK_2PHP,SWAK_BP,SWAK" );
   DO_TEST( test_func_fractal,   "FRACTAL" );
   DO_TEST( test_func_ha,        "HA" );
   DO_TEST( test_func_tsi,       "TSI" );
   DO_TEST( test_func_kdj,       "KDJ" );
   DO_TEST( test_func_adr,       "ADR" );
   DO_TEST( test_func_fosc,      "FOSC" );
   DO_TEST( test_func_dpo,       "DPO" );
   DO_TEST( test_func_percentrank, "PERCENTRANK" );
   DO_TEST( test_func_crsi,      "CRSI" );
   DO_TEST( test_func_bbw,       "BBW" );
   DO_TEST( test_func_cg,        "CG" );
   DO_TEST( test_func_percentb,  "PERCENTB" );
   DO_TEST( test_func_si,        "SI,ASI" );
   DO_TEST( test_func_percentile, "PERCENTILE" );
   DO_TEST( test_func_cvi,       "CVI" );
   DO_TEST( test_func_massi,     "MASSI" );
   DO_TEST( test_func_rvol,      "RVOL" );
   DO_TEST( test_func_variants,  "TA_S_,VARIANT" );
   DO_TEST( test_candle_precision, "CDLDOJI,CANDLE,VARIANT,PRECISION" );
   DO_TEST_LBL( test_func_rolling_extremum,
            "MIN,MAX,MINMAX,MIDPOINT,MIDPRICE,WILLR,ROLLING,BLOCKSCAN",
            "Rolling extremum block scan" );
   DO_TEST( test_func_legacy,    "LEGACY,064,FROZEN" );
   DO_TEST_LBL_NOSV( test_func_stream_finite,
            "SMA,MINUS_DI,MA,MAVP,BBANDS,STOCH,CDLDOJI,STREAM,FINITE",
            "Streaming finite-input gate" );
   DO_TEST_LBL_NOSV( test_func_open_contract,
            "STREAM,OPEN,REJECT,CONTRACT",
            "Open rejection write contract" );
   DO_TEST_LBL_NOSV( test_func_unstable_shift,
            "UNSTABLE,LOOKBACK,SHIFT",
            "Unstable period shift" );
   DO_TEST_LBL_NOSV( test_func_auto_stabilization,
            "UNSTABLE,LOOKBACK,AUTO",
            "Unstable period Auto levels" );

   /* A filter that matched nothing must not read as success. The group tags are
    * hand-maintained and cover far fewer names than the library exports, so a
    * plausible `--function=SMA` selected zero groups and still printed "All
    * tests succeeded" -- the failure mode that hid the candlestick gap above.
    *
    * Only fail when these groups were the whole job: --codegen, --xlang-hash
    * and --ref filter by REAL function name and legitimately run for names
    * no group tag carries (scripts/synth_gate.py drives --function=SYNTH that
    * way). There, zero groups here is expected, not an error. */
   if( functionFilter != NULL && nbGroupsRun == 0 &&
       !doCodegenTest && !doXlangHash && refVersion == NULL )
   {
      printf( "\nFAILED: --function=%s matched no test group, so nothing ran.\n",
              functionFilter );
      printf( "        The filter is a substring match against the GROUP TAG in\n" );
      printf( "        ta_regtest.c's DO_TEST list, not against the function name.\n" );
      printf( "        Some functions have no hand-written group at all (the plain\n" );
      printf( "        vector math, OBV, TYPPRICE, WCLPRICE); they\n" );
      printf( "        are covered by the systematic sweeps, which enumerate every\n" );
      printf( "        function through ta_abstract -- reach those with --codegen or\n" );
      printf( "        --xlang-hash. Otherwise add the name to its group's tag.\n" );
      return TA_REGTEST_FILTER_MATCHED_NOTHING;
   }

   return TA_TEST_PASS; /* All tests succeeded. */
}

static void printUsage(void)
{
      printf( "Usage: ta_regtest [--function=NAME[,NAME,...]]\n" );
      printf( "\n" );
      printf( "   No parameter needed for regression testing.\n" );
      printf( "\n" );
      printf( "   This tool will execute a series of tests to\n" );
      printf( "   make sure that the library is behaving as\n" );
      printf( "   expected.\n");
      printf( "\n" );
      printf( "   ** Must be run from the 'bin' directory.\n" );
      printf( "\n" );
      printf( "   OPTIONS:\n" );
      printf( "    --function=NAME[,NAME,...]\n" );
      printf( "       Only run test groups whose tags contain at least\n" );
      printf( "       one of the given names (substring match).\n" );
      printf( "       Example: --function=RSI,BBANDS\n" );
      printf( "\n" );
      printf( "    --codegen[=LANG[,LANG,...]]\n" );
      printf( "       After normal tests, verify ta_codegen output against C reference.\n" );
      printf( "       Languages: rust, c, java, csharp (default: all)\n" );
      printf( "       Example: --codegen=rust,java\n" );
      printf( "\n" );
      printf( "    --language=LANG[,LANG,...]\n" );
      printf( "       Filter which language servers to test with --codegen.\n" );
      printf( "       Valid values: rust, c, java, csharp (default: all)\n" );
      printf( "       Example: --language=c,rust\n" );
      printf( "\n" );
      printf( "       Requires language server binaries in the bin directory.\n" );
      printf( "       Build with: ta_codegen build\n" );
      printf( "\n" );
      printf( "    --xlang-hash\n" );
      printf( "       Cross-language BITWISE parity gate (issue #113): diff each\n" );
      printf( "       language server against the in-process C library on\n" );
      printf( "       seed-generated inputs, comparing full-precision output hashes\n" );
      printf( "       with no tolerance. Honors --function and --language (rust today).\n" );
      printf( "       Run from the bin directory (needs the language servers).\n" );
      printf( "\n" );
      printf( "    --ref=X_Y_Z\n" );
      printf( "       Differential fuzz against the frozen release X.Y.Z\n" );
      printf( "       (bin/ta_ref_X_Y_Z_serve, member ta_ref/ta_ref_X_Y_Z.c).\n" );
      printf( "       Honors --function. Run from the bin directory.\n" );
      printf( "\n" );
      printf( "    --codegen, --ref and --xlang-hash are SEPARATE runs and\n" );
      printf( "    cannot be combined: the last two return before anything else,\n" );
      printf( "    so a combination would silently skip what it did not reach.\n" );
      printf( "\n" );
      printf( "    --seed=N\n" );
      printf( "       Seed the range sweeps, replaying a previous run. Each run\n" );
      printf( "       otherwise picks its own seed and prints it.\n" );
      printf( "\n" );
      printf( "   On success, the exit code is 0.\n" );
      printf( "   On failure, the exit code is a number that can be\n" );
      printf( "   found in c/src/tools/ta_regtest/ta_error_number.h\n" );
}

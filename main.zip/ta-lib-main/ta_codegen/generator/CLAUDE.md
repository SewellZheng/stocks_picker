# ta_codegen — TA-Lib Code Generation Tool

## What This Is

`ta_codegen` is the Rust-based code generator that replaces the old `gen_code.c` pipeline for indicator code generation. It reads the per-indicator definitions in `ta_codegen/input/` — the source of truth — produces language-specific indicator implementations, and generates JSON-RPC servers for cross-language regression testing.

## Architecture

```
ta_codegen/input/                (per-indicator .c logic + YAML metadata)
       ↓
    parser                   (YAML metadata → raw serde structs → IR;
                              .c source → IR Statement/Expr directly, no raw stage)
       ↓
    ir                       (FuncDef + Statement/Expr intermediate representation)
       ↓
  ┌────┴─────────────┐
backends            server_gen / bench_gen
  ↓                      ↓
c.rs, rust_lang.rs,   JSON-RPC servers, bench binary,
java.rs               src/ta_func/ta_func_stream_private.h
ta_abstract_c.rs
  ↓
src/ta_func/*.c          (C indicator code — generated IN PLACE)
src/ta_abstract/         (ta_abstract introspection layer — generated IN PLACE)
ta_codegen/output/       (per-language products: library/ (shipped) + tools/ (server/bench))
  c/tools/               (server + bench + aggregation TUs; C library ships from src/)
  rust/library/ + rust/tools/  (ta-lib crate + server/bench — a Cargo workspace)
  java/library/ + java/tools/ + java/fragments/  (shipped Maven project + JSON-RPC
                               server + per-function method bodies: an intermediate
                               that ships nowhere, re-rendered into Core.java from
                               the IR and inlined into the server from disk)
  csharp/library/ + csharp/tools/  (shipped TALib package incl. src/metadata/ + managed JSON-RPC server)
include/ta_func.h        (generated public header)
```

**Hand-written library templates** (not indicator algorithms, not generated) live under
`ta_codegen/generator/templates/` — the generator's own assets, kept out of `input/`
(which holds only the indicator definitions) and out of `output/` (100% generated):
- `templates/rust/types.rs` — the `Core` / `RetCode` / `CoreBuilder` / `CandleSettings`
  scaffolding, copied verbatim into the Rust crate (`output/rust/library/src/ta_func/types.rs`).
- Four more, each copied verbatim and declared `#[cfg(test)]` in the generated
  `mod.rs`, so none ships in a release build. The nightly runs them with
  `cargo test --tests -p ta-lib`, which is the only thing that runs them —
  `clippy --all-targets` compiles the test target without executing it, and
  `--tests` rather than `--lib` because it must also reach `library/tests/`:
  `templates/rust/scratch_election.rs` (the scratch-buffer election value gate,
  issue #146), `stream_finite.rs` (the streaming tier's non-finite input
  rejection), `stream_out_range.rs` (a handle's `OutRange` against batch, issue
  #241) and `div_zero.rs` (DIV's zero-divisor result, issue #249).

Every Rust template is listed in `main.rs`'s `RUST_TEMPLATE_MODULES` (and the
test-only ones in `RUST_TEST_ONLY_MODULES`) and in `RustBackend::clean_keep`, so
`generate` copies them in and never deletes them. Adding another one means
touching all three.

A fifth `#[cfg(test)]` module is **generated, not copied**: the phantom-I/O sweep,
`src/ta_func/no_phantom_io.rs`, emitted by `backends/rust_phantom_io.rs`. It lives
in `src/` rather than `tests/` because it probes `<N>_Impl`, which is
`pub(crate)` (#265). Its own list is `RUST_GENERATED_TEST_MODULES`, and it is in
`clean_keep` too — the only entry there that is not a template, since the
stale-file sweep would otherwise delete a `.rs` in `src/ta_func/` that names no
indicator.
- `templates/c/ta_retcode.c.template` — spliced with `src/ta_common/ta_retcode.csv`
  (`backends/retcode.rs`) → `src/ta_common/ta_retcode.c`.
- `templates/c/ta_abstract_serve.c` — hand-written abstract-serve handlers `#include`d
  into the C JSON-RPC server (added to the server compile's `-I` path).

### Key Modules

| Module | Purpose |
|--------|---------|
| `parser` | Parses YAML metadata (via raw serde structs) into `FuncDef`; parses `.c` source directly into IR `Statement`/`Expr` (no intermediate raw-struct stage for the logic). Also classifies every function in the file into base / `_private` / `_ALT<n>` and reads their `PRAGMA` decorations (see [Alternate implementations](#alternate-implementations-pragma-ta_alt)) |
| `ir` | Intermediate representation (`FuncDef`, `ParamType`, `Statement`, `Expr`, etc.) |
| `backends/c.rs` | Generates C indicator implementations (guarded `TA_<N>` / `TA_S_<N>`, plus `TA_<N>_Private` where declared) |
| `backends/rust_lang.rs` | Generates Rust indicator implementations (concrete `f64`, guarded `<N>` plus `<N>_Private` where declared) |
| `backends/rust_doc.rs` | Renders each function's canonical `<name>.md` as rustdoc on the generated Rust methods (summary/formula/notes, `# Arguments` with YAML numbers injected, `# Errors`, a runnable doctest, `#[doc(alias)]`, intra-doc `# See also` links) |
| `backends/java.rs` | Generates Java Core class methods |
| `backends/ir_cleanup.rs` | Backend-selected IR cleanup, between the streaming decision and rendering. Each ported backend states its own explicit sequence — answered cross-call guards, deallocation, then inert guards. C states none. Every pass is length-preserving, because the stream emitters address the body by index |
| `backends/csharp.rs` | Generates the shipped C# indicators — one `Core_<NAME>.cs` (`public partial class Core`) per function; XML docs via `csharp_doc.rs`, condition folding shared with Java via `compat_fold.rs` |
| `backends/{c,rust,java,csharp}_stream.rs` | The four streaming emitters — one per backend, each rendering the *same* backend-neutral analysis from `streaming.rs` (`StreamPlan`, `StreamModel`, `build_transition`, the `NameMap` trait) into its own language. Adding a fifth means writing only the new emitter: the neutral layer and the other three stay untouched, which is what keeps them byte-frozen by construction while it lands. **The `NameMap` prefixes are shared on purpose** — `fma::stream_base` strips exactly `sp->`, `sp.` and `cur_` to decide integer-vs-float typing, so a backend that invents its own spelling silently changes which sites fuse `a*b+c`, i.e. ~1 ULP with nothing pointing at the cause |
| `backends/csharp_metadata.rs` | Generates the shipped C# introspection registry (`TALib.Metadata` under `csharp/library/src/metadata/`) **and, into the test project, `NoPhantomIoBinder.g.cs` — the phantom-I/O probe's own `<N>_Impl` call sites, which is what keeps that probe's corpus complete under `regen-check` (#265)**: the vocabularies, the model records, `FunctionCall`, and one factory per function carrying its two dispatch thunks. The C# JSON-RPC server answers the `ta_abstract` RPCs out of *this* registry — its csproj compiles the library sources — so `test_abstract.c` proves the shipped artifact, not a test-only copy |
| `backends/abstract_rows.rs` | **The backend-neutral `ta_abstract` row model.** One derivation of every function's metadata (flags, price bundling, parameter domains, unstable-period id), rendered by `rust_abstract`, `java_abstract` (server table), `java_metadata` (shipped registry) and `csharp_metadata`. Sum-typed `OptDomain` + closed `Group`/`InputKind`/`OutputKind` enums, so a renderer cannot silently mis-tag a domain. **C and `func_api_xml` deliberately do NOT render from it** — see below |
| `backends/ta_abstract_c.rs` | Generates `ta_abstract` introspection layer (tables, frames, group index, runtime API) |
| `backends/price_bundle.rs` | Folds the expanded price components back into the single `TA_Input_Price` descriptor (`inPriceHLC` + flags). Shared by the C, Rust and Java abstract backends — that name and flags word are **public ABI** (wrappers read them; ta-lib-python renders them as `{'prices': [...]}`), so they are derived once, from the YAML declaration carried on each `Input` as a `PriceRef`, never re-inferred from argument names |
| `backends/func_api_xml.rs` | Generates `ta_func_api.xml` metadata |
| `backends/docs_site.rs` | Generates the ta-lib.org website (`website/src/functions/<name>.md` + `index.md`) from each function's `ta_codegen/input/<name>/<name>.md` — written directly into the VuePress site source tree (`website/`), not `ta_codegen/output/` |
| `server_gen` | Generates JSON-RPC server wrappers + `src/ta_func/ta_func_stream_private.h` |
| `bench_gen` | Generates direct-call benchmark binary |
| `registry` | Function registry for tracking available indicators |

## Commands

```bash
# Runnable from ANY directory: the built binary locates the repo via its own
# path (the `ta_codegen/input/` marker). Override with `TA_CODEGEN_ROOT=/path/to/ta-lib`.
# `cargo run` from ta_codegen/generator/ works as before.
cargo run -- generate                        # Everything: libraries + servers + benches
cargo run -- generate --func=SMA,RSI         # Generate specific functions
cargo run -- generate --backend=rust         # Generate for specific backend

cargo run -- generate-servers                # Only the JSON-RPC servers, all languages
cargo run -- generate-servers --backend=c    # Only the server for one language

cargo run -- build                           # Compile generated servers into executables
cargo run -- build --backend=c,java          # Build specific servers
```

`generate` writes **everything committed** — the shipped libraries, the four
JSON-RPC servers, `ta_bench_cg.c` / `ta_bench_stream.c` — so "regenerate, then
`git status` must be clean" is a total gate over the tree. `generate-servers`
and `generate-bench` are narrowings of it, for the callers that rebuild a server
without a full regeneration (`build.py servers`, `regtest.py`); they own no path
`generate` does not write. Emitting a `.java` or `.cs` source is text, so none of
this needs a JDK or the .NET SDK — those belong to `build`, which compiles only
the backends asked for.

The exception is `--func=`: whole-corpus files (`Core.java`, the servers, the
benches) are skipped there, because rendering them from a filtered set would drop
every function the filter excluded. A `--func` iteration loop must therefore end
with one bare `generate` before committing.

## Testing

```bash
cd ta_codegen/generator && cargo test            # Run all 445+ tests
cd ta_codegen/generator && cargo clippy          # Strict pedantic lints enabled
```

Tests are in `tests/backend_suite.rs` and `tests/integration_test.rs` — they verify IR-to-backend rendering, expression types, function signatures, and function variants across all backends.

Value gates that need the *generated* library live in the crate itself, as
`#[cfg(test)]` modules — four copied from `templates/rust/` (see
`RUST_TEMPLATE_MODULES`) and one emitted (`RUST_GENERATED_TEST_MODULES`); run
them with `cargo test --tests -p ta-lib` in `ta_codegen/output/rust/`.

## Cross-Language Testing Architecture

**The big picture**: `ta_regtest` is the universal test runner. It should test ALL languages, not just C.

### Current State

**Fully working:**
- `codegen_pipe.c/h` in ta_regtest — complete subprocess pipe abstraction (fork, exec, stdin/stdout JSON-RPC)
- `test_codegen.c/h` in ta_regtest — full orchestration: multi-language loop, JSON helpers, `doRangeTest` integration, epsilon comparison (`1e-6`), language/function filters
- Server generation for all 4 languages (C, Java, C#, Rust)
- `ta_codegen build` compiles servers into executables in `bin/`

**What's working end-to-end:**
- Generic callback in `test_codegen.c` auto-generates JSON-RPC requests from ta_abstract metadata for every indicator
- `list_functions` implemented — servers report available indicators with parameter metadata
- `timing_ns` returned with each response — ta_regtest collects and prints a timing summary
- `set_unstable_period` and `set_compatibility` implemented for all 20 unstable-period functions

### How It Works

1. `ta_codegen generate-servers` produces a JSON-RPC server per language
2. `ta_codegen build` compiles them into executables in `bin/`
3. Each server reads JSON-RPC from stdin, dispatches to compiled indicators, writes responses to stdout
4. `ta_regtest` spawns each server as a subprocess via `codegen_pipe`
5. For each indicator, ta_regtest calls the C reference AND sends the same call to the server
6. `compare_codegen_output()` validates retCode, outBegIdx, outNbElement, and output values match

### Server Protocol

JSON-RPC over stdin/stdout.

**Request format:**
```json
{"method": "TA_SMA", "params": {"startIdx": 0, "endIdx": 251, "optInTimePeriod": 30, "inReal": [...]}}
```

**Input types vary by function:**
- `inReal` / `inReal0` / `inReal1` — for functions with `TA_Input_Real` params
- `inHigh`, `inLow`, `inClose`, etc. — for functions with `TA_Input_Price` params (STOCH, BBANDS, ADX, etc.)
- The server must handle both styles based on the function's signature

**Response format:**
```json
{"retCode": 0, "outBegIdx": 14, "outNBElement": 237, "outReal": [...], "timing_ns": 1842}
```

**Multi-output functions** (STOCH, BBANDS, MACD, etc.) return multiple arrays:
```json
{"retCode": 0, "outBegIdx": 14, "outNBElement": 50, "outReal": [...], "outReal1": [...], "outReal2": [...]}
```

**Integer output functions** (CDL* candlestick patterns, MINMAXINDEX) return:
```json
{"retCode": 0, "outBegIdx": 14, "outNBElement": 50, "outInteger": [...]}
```

## Alternate implementations (`PRAGMA TA_ALT`)

Some functions need genuinely different algorithms per API tier: the six
rolling-extremum functions run a block-batched Van Herk scan in batch, which
cannot be transcribed into a per-bar automaton. An input `.c` may therefore
declare `<name>_ALT<n>` alongside `<name>`, decorated with
`/* PRAGMA TA_ALT={<api>,<lang>} */`; the authoring contract is in
[docs/ta_codegen_input_code.md](../../docs/ta_codegen_input_code.md).

Two things about the implementation are worth knowing before touching it:

**There is exactly one resolution point.** `ir::FuncDef::resolved_for(lang)`
returns a view whose `body` is the `(BATCH, lang)` winner and whose
`stream_source()` is the `(STREAM, lang)` winner. It is called at each language
backend's `generate` entry (and again inside each `*_stream::generate`, which is
idempotent and covers the callers that bypass the backend, such as
`java_shipped::generate_core`). Everything downstream — the six stream analyzers,
the four batch emitters, the FMA fusion-set builders, the CIRCBUF prolog lookup —
keeps reading `body` / `stream_source()` and needs to know nothing. The
alternative was teaching ~20 scattered selection sites about the language, where
*missing one is silent*: it would quietly render the base.

`resolved_for` pins **both** tiers even where the base wins one of them, because
`stream_source()` falls back to `body` and `body` is about to become the batch
winner. The SYNTH6 fixture exists partly to catch that: it is the only shape where
an alternate claims BATCH, so a resolver that leaked the batch body into the
stream fails there and nowhere else.

**Nothing but the emitted code can prove which body won.** An alternate is
generator input, not a symbol, so every value-comparison gate in the tree passes
whichever body was selected. The generated file names its winner
(`/* Using min_ALT1 for TA_ALT={STREAM,ALL_LANGUAGES} */`), but a marker is
rendered *from* the resolution and would agree with a resolver that chose wrong.
`tests/alt_suite.rs` therefore checks the emitted statements, using SYNTH5 and
SYNTH6 — the same algorithm with the tiers swapped — so that no always-return-the-
base or always-return-the-alternate bug satisfies both.

## The abstract layer: one row model, and one independent oracle

Four surfaces describe the same metadata. Three of them — Rust's `abstract_api`,
the Java server's inline table plus the shipped `io.github.talib.metadata`, and
the shipped C# `TALib.Metadata` — render `backends/abstract_rows.rs`. **C's
`ta_abstract_c` does not, and that is the point.**

`test_abstract.c` proves each language server's metadata against the C library's
`ta_abstract` at run time. That gate is only worth something while C's values
come from somewhere else: fold C into the shared rows and it becomes a generator
compared against itself, unable to fail on a wrong row. So C keeps its own
derivation (its own `get_precision`, its own fallbacks, and
`match_predefined_opt_input`'s dedup against hand-curated `TA_DEF_UI_*`
descriptors), and stays the oracle. `func_api_xml` is left out for the same
reason plus a different projection (display labels, legacy ordering).

The dedup is a **total equality test**, and it has to stay one. C's ~20
pre-defined `TA_DEF_UI_*` descriptors are hand-written literals, and a slot
reuses one only when the constant already says exactly what the YAML says —
name, display name, hint, flags, default, range, suggested triple, precision.
Anything else gets its own descriptor carrying its own values. So a fold is pure
`.rodata` dedup with no semantic content: matching cannot discard what the YAML
declared, because a match means there was nothing to discard.

Keying on a subset is what issue #195 was. It let a new function inherit another
function's wording, and the divergence surfaced only after a four-language server
build, phrased as though the server were wrong. `match_predefined_output` in the
same file was already total; the opt-input side is now too.

The price is worth naming: for a folded slot the gate can no longer fail on
`displayName` / `hint` / `suggested`, since equality is what selected the
descriptor. That check was only ever detecting "YAML edited, generator literal
stale" — a condition that now causes a decline instead of a divergence. Editing
SMA's `display_name` today shows up as a diff to `src/ta_abstract/tables/table_s.c`,
a committed generated file the nightly `regen-check` pins. C still derives
`range`, `default` and `precision` on its own for every bespoke slot. What no
gate sees is a wrong `default:` or a wrong function-level `hint:`, where every
derivation moves together.

Two pieces C *does* share are shared deliberately, because an independent gate
already covers them: `price_bundle` (its own unit tests) and the flag bit values
(`flag_sync` pins them against `include/ta_abstract.h`).

A row carries no derived *name* at all. There is one name — the YAML `name` —
and every backend spells it verbatim (C alone prefixes `TA_`), so a row has
nothing to derive, nothing to keep in sync, and no way to name a method that
does not exist.

## Rust Backend Details

### Concrete `f64` API (no generics)

Generated Rust indicators are methods on the `Core` struct using concrete
`f64` slices (`&[f64]` / `&mut [f64]`), `usize` indices, and `i32` optional
params. There is **no** generic `<T: TaFloat>` system and no `f32`/`_s`
variants — an earlier sealed-trait generics experiment was removed; the backend
is concrete-`f64` only.

### Function Variants Per Indicator

| Variant | Purpose |
|---------|---------|
| `pub fn <N>_Lookback(...) -> usize` | Lookback (first valid output index) |
| `pub fn <N>(...) -> Result<OutRange, RetCode>` | The batch API, and the tier that owns the argument contract (#265): B1/B2, then B3 via `<N>_Lookback(..)?`, then every input and output length-checked, before it calls `<N>_Impl` and turns `Success` into `Ok(OutRange { beg_idx, count })`. Same two-tier shape Java (`<N>_Impl` + `OutRange`) and C# (`internal RetCode <N>_Impl` + `public OutRange <N>`) already ship |
| `pub(crate) fn <N>_Impl(...) -> RetCode` | The body: validates params and the index range, pre-computes optimization values, delegates. Keeps C's shape — a code plus `&mut outBegIdx` / `&mut outNBElement` — because that is what the transcribed bodies are written against, and it is where the FMA dispatch sits. Not a cross-call target since #267 |
| `fn <N>_Private(...)` | Only where the definition declares one. Extra pre-computed params, no validation prologue — its only caller is the `_Impl` body above it. No shipped indicator declares one; the construct is carried by the `SYNTH4` gate fixture (`input_synth/README.md`) |

Cross-indicator calls target the **public** wrapper, as in C, Java and C# (#267).
`?` is unavailable — the caller is `<N>_Impl`, which returns a bare `RetCode`, or
a `Result`-returning `<n>_open_impl` at three of the sites —
so `render_cross_indicator_call` drops the two out-meta arguments, binds the
returned range to a `_xrN` local with a `match`, assigns both out-params from it,
and then sets `retCode = RetCode::Success`. The `if( retCode != SUCCESS )` that
followed can no longer be taken and is folded out by
`ir_cleanup::drop_answered_cross_call_guards`; 22 of the 36 sites hand the
callee the caller's own `&mut outBegIdx` / `&mut outNBElement` and read them
back, and 10 fold "success with zero output" into the same conditional, so that
half survives alone and keeps the assignment live.

`<N>_Impl` still carries the bounds-assert preamble, and it still takes an
empty-range escape so a call computing nothing cannot panic. What changed is who
meets it: only `pub fn <N>` and the phantom-I/O sweep now, so the preamble is the
LLVM proof and the sweep's target rather than the cross-call path's guard.

`rust_doc::guarded_docs` is the rustdoc for the **public** wrapper, so its
`# Arguments` list must match that signature — not the `_Impl` one.
`rust_public_entry_documents_exactly_its_parameters` pins the two together;
nothing else can, since rustdoc has no lint for documenting a parameter that does
not exist.

### Documentation (rustdoc)

`backends/rust_doc.rs` renders the canonical `ta_codegen/input/<name>/<name>.md`
(parsed into `DocDef` by `parser/doc_md.rs`, attached as `FuncDef.doc`) as rustdoc
on all three variants, and every guarded function gets a **generated runnable
doctest** (252 bars of deterministic synthetic data, all params at defaults,
propagating with `?` and asserting the returned `OutRange` is non-empty). Crate-level docs, Cargo.toml package metadata, and the crate
README.md are emitted by `generate_rust_crate_scaffolding` in `main.rs`. Verify
with `cargo doc --no-deps` (must be warning-free — prose escaping of `[`/`<` is
load-bearing) and `cargo test --doc` in `ta_codegen/output/rust/`.

### Scratch-buffer election (issue #146)

Several C bodies elect one of their own *output* buffers as the scratch the
calculation runs in — `BBANDS` opens with `tempBuffer1 = outRealMiddleBand;` so it
needs no allocation at all. In C that is a pointer assignment. Rust has no pointer
to assign, so a naive rendering emits `outRealMiddleBand.to_vec()`: an allocation
plus a copy of bytes that are overwritten before they are read, sized by the
*caller's slice* rather than by the data range.

`backends::rust_lang::ScratchElection` (a Rust-only pass, applied to both batch
bodies at the top of `gen_impl_block`) restores C's shape by renaming the local to
the elected output. It leans on Rust's own aliasing rules — `&[T]` and `&mut [T]`
parameters can never overlap, and neither can two `&mut [T]` — which is also what
makes C's aliasing arms, its input-alias guard and its copy-back statically dead
here.

The rule is stated over the IR, and nothing in the pass names a function, a buffer
or an MA type: match an `if`/`else if`/…/`else` chain whose *every* condition is an
input↔output pointer equality and whose *every* arm is only `scratch = someOutput;`
elections; take the terminal `else`'s mapping; delete the chain and rename through
the rest of the enclosing block; drop any guard that became a self-comparison.
Clause 4 is load-bearing rather than cosmetic — left in place, `BBANDS`' copy-back
would read and write the same `&mut` slice in one statement, which is E0502.

Being general is not the same as being greedy. Requiring *every* arm to be an
election is what declines `STOCH`, `STOCHF` and `MAVP`: each mixes an allocation
and a `…IsAllocated = 1;` flag into a branch, which is a genuine in-place defence,
not an election (`MAVP` is inverted too — allocation in the `then`, election in the
`else`). Tolerating one allocating arm would reach them; that would be a widening
of this rule for a later change, never a per-function case. An election also stops
at the end of the block holding it, so `BBANDS`' general MA path and both stream
paths keep their real `vec![0.0; ...]` allocations, and the pass backs off entirely
if the local is assigned again while still in scope.

`BBANDS` is currently the only function in `input/` written in this shape.
`rust_scratch_election_declines_arms_that_allocate` in `tests/backend_suite.rs`
pins that by sweeping every indicator and asserting the pass fires for `bbands`
alone.

The C, Java and C# backends need none of this — they assign the pointer or
reference directly — so the transform must never change their output. `generate`
followed by `git diff` over `src/ta_func/`, `output/java/` and `output/csharp/` is
the check. `templates/rust/scratch_election.rs` is the value gate.

### Debug-safe decrements

C's `while (i-- > 0)` idiom lets an unsigned counter wrap past zero; the Rust
backend emits `wrapping_sub(1)` for post/pre-decrement so debug builds (and
doctests) behave like the regtest-verified release builds instead of panicking
on `attempt to subtract with overflow`.

## Linting

Strict Clippy pedantic lints are enabled in `src/lib.rs`. Allowed exceptions:
- `module_name_repetitions` — common in codegen
- `must_use_candidate` — codegen builders don't need this
- `format_push_string` — string building is the natural codegen pattern
- `doc_markdown` — generated doc comments come from upstream C

`rustfmt.toml`: edition 2021, max_width 100, use_field_init_shorthand true.

## Performance: C Server Compilation

- Server is single-TU (`#include .c` files) — do NOT switch to separate compilation, it causes CDL binary layout issues
- Candle settings are hoisted once into local `int`/`double` vars at the top of each function by `emit_c_unpacking()` — plain reads from `TA_Globals->candleSettings[...]`, no `volatile` cast
- Ternary chains (not switch statements) for numeric-case switches — matches reference macro pattern for compiler optimization
- CCI uses conditional reset (`idx++; if(idx>=max) idx=0`) not modulo — modulo costs ~10 cycles on ARM
- Full parameter validation (NULL checks, INTEGER_DEFAULT, range) is required — missing validation changes compiler register allocation
- `ta_ref_serve` is statically linked against `libta-lib.a` — MUST rebuild when cmake rebuilds the library, or benchmarks compare against stale code
- `regtest.py` auto-rebuilds ta_ref_serve in the cmake step
- Benchmark noise: full-suite runs have 10-20% variance from icache pressure. Use `ta_bench --function=NAME --iters=500` for ground truth.
- All servers and bench binaries call `TA_Initialize()` at startup — required for candle settings defaults.
- Thermal canary (SMA) runs between each indicator in ta_bench to normalize CPU thermal state

//! The streaming tier's non-finite input rejection.
//!
//! Hand-written, not generated: this file lives in
//! `ta_codegen/generator/templates/rust/stream_finite.rs` and is copied verbatim
//! into the crate by `generate` (the Rust backend's `clean_keep` holds it, so
//! `generate` never deletes it). It is declared `#[cfg(test)]` in `mod.rs`, so
//! nothing here ships in a release build. Run it with
//! `cargo test --lib -p ta-lib`.
//!
//! Non-finite rejection is a property of SINGLE VALUES, never of input arrays.
//!
//! An input ARRAY is never scanned, in either tier — including the warm-up
//! history handed to `_Open` / `_OpenAndFill`. Keeping one free of NaN and
//! infinities is the caller's responsibility; passing a non-finite one is
//! undefined behaviour. See `docs/error-handling-spec.md`, "Non-finite input".
//!
//! A SINGLE VALUE is always checked, because it is one comparison, and for the
//! streaming tier it earns that cost twice over: batch is handed a series,
//! computes and forgets, so a NaN reaches the outputs depending on that bar and
//! no others, while a handle RETAINS state and one non-finite bar poisons every
//! value it will ever produce afterwards — long after the feed recovers.
//! Rejecting the bar and leaving the handle untouched is strictly more useful
//! than accepting it and going permanently NaN.
//!
//! Two properties, per function:
//!
//! 2. `update` / `peek` reject a non-finite bar in ANY input slot.
//! 3. The handle is UNCHANGED by a rejected call. This is the property that
//!    makes the rejection useful rather than merely safe, and it is checked
//!    against a control stream rather than by inspection: two handles opened on
//!    the same history, one of them offered the bad bar first, must agree BIT
//!    FOR BIT on the next good bar. A rejection that half-advanced the state
//!    would satisfy (2) and fail only here.
//!
//! (The numbering keeps 2 and 3: property 1 was the history scan, withdrawn.)
//!
//! Coverage is by stream TIER, not by function count. The check is emitted from
//! one place in `rust_stream.rs`, but into the entry points of five different
//! tiers, so the functions here are chosen to reach every one:
//!
//! | function   | tier                                                        |
//! |------------|-------------------------------------------------------------|
//! | `SMA`      | loop                                                        |
//! | `MINUS_DI` | dual-mode                                                   |
//! | `MA`       | dispatch — including the identity arm, which copies the bar  |
//! |            | straight out and never reaches a sub-stream at all           |
//! | `MAVP`     | period-bank — and the only streaming input reaching an `as i32` |
//! | `BBANDS`   | composed, plus the real optional parameters                  |
//! | `STOCH`    | composed, multi-output, one sub feeding the next             |
//! | `CDLDOJI`  | integer output over four price inputs                       |

use crate::ta_func::types::{Core, RetCode};
use crate::MAType;

const WARM: usize = 60;

fn series(n: usize) -> (Vec<f64>, Vec<f64>, Vec<f64>, Vec<f64>, Vec<f64>) {
    let mut open = Vec::with_capacity(n);
    let mut high = Vec::with_capacity(n);
    let mut low = Vec::with_capacity(n);
    let mut close = Vec::with_capacity(n);
    let mut periods = Vec::with_capacity(n);
    for i in 0..n {
        let base = 100.0 + 8.0 * (i as f64 * 0.11).sin() + 0.03 * i as f64;
        open.push(base - 0.4);
        high.push(base + 1.25);
        low.push(base - 1.25);
        close.push(base + 0.4 * (i as f64 * 0.71).sin());
        periods.push(5.0 + (i % 11) as f64);
    }
    (open, high, low, close, periods)
}

/// The three values the tier refuses.
const BAD: [f64; 3] = [f64::NAN, f64::INFINITY, f64::NEG_INFINITY];

fn probed(n: &mut usize, ok: bool) -> bool {
    *n += 1;
    ok
}

fn is_bad_param<T>(r: &Result<T, RetCode>) -> bool {
    matches!(r, Err(RetCode::BadParam))
}

#[test]
fn update_and_peek_reject_a_non_finite_bar_without_moving_the_handle() {
    let core = Core::new();
    let (open, high, low, close, periods) = series(WARM + 2);
    let (o, h, l, c, p) = (
        &open[..WARM],
        &high[..WARM],
        &low[..WARM],
        &close[..WARM],
        &periods[..WARM],
    );
    let (no, nh, nl, nc, np) = (open[WARM], high[WARM], low[WARM], close[WARM], periods[WARM]);
    let mut rejects = 0usize;
    let mut states = 0usize;

    for &bad in &BAD {
        // --- loop tier ---
        let (mut sa, _) = core.sma_open(c, 14).unwrap();
        let (mut sb, _) = core.sma_open(c, 14).unwrap();
        assert!(probed(&mut rejects, is_bad_param(&sa.update(bad))), "SMA.update accepted {bad}");
        assert!(probed(&mut rejects, is_bad_param(&sa.peek(bad))), "SMA.peek accepted {bad}");
        assert!(
            probed(&mut states, (sa.update(nc).unwrap().to_bits() == sb.update(nc).unwrap().to_bits())),
            "SMA: a rejected bar moved the handle"
        );

        // --- dual-mode tier, one input slot at a time ---
        let (mut da, _) = core.minus_di_open(h, l, c, 14).unwrap();
        let (mut db, _) = core.minus_di_open(h, l, c, 14).unwrap();
        assert!(probed(&mut rejects, is_bad_param(&da.update(bad, nl, nc))), "MINUS_DI.update(high)");
        assert!(probed(&mut rejects, is_bad_param(&da.update(nh, bad, nc))), "MINUS_DI.update(low)");
        assert!(probed(&mut rejects, is_bad_param(&da.update(nh, nl, bad))), "MINUS_DI.update(close)");
        assert!(probed(&mut rejects, is_bad_param(&da.peek(bad, nl, nc))), "MINUS_DI.peek(high)");
        assert!(
            probed(&mut states, da.update(nh, nl, nc).unwrap().to_bits()
                == db.update(nh, nl, nc).unwrap().to_bits()),
            "MINUS_DI: a rejected bar moved the handle"
        );

        // --- dispatch tier, and its identity arm ---
        let (mut ma, _) = core.ma_open(c, 14, MAType::EMA).unwrap();
        let (mut mb, _) = core.ma_open(c, 14, MAType::EMA).unwrap();
        assert!(probed(&mut rejects, is_bad_param(&ma.update(bad))), "MA.update accepted {bad}");
        assert!(probed(&mut rejects, is_bad_param(&ma.peek(bad))), "MA.peek accepted {bad}");
        assert!(
            probed(&mut states, (ma.update(nc).unwrap().to_bits() == mb.update(nc).unwrap().to_bits())),
            "MA: a rejected bar moved the handle"
        );

        // Period 1 copies the bar straight to the output and never reaches a
        // sub-stream, so a check delegated to the sub would miss it.
        let (mut mi, _) = core.ma_open(c, 1, MAType::SMA).unwrap();
        assert!(probed(&mut rejects, is_bad_param(&mi.update(bad))), "MA(identity).update");
        assert!(probed(&mut rejects, is_bad_param(&mi.peek(bad))), "MA(identity).peek");

        // --- period-bank tier: the period reaches `as i32` ---
        let (mut va, _) = core.mavp_open(c, p, 2, 30, MAType::SMA).unwrap();
        let (mut vb, _) = core.mavp_open(c, p, 2, 30, MAType::SMA).unwrap();
        assert!(probed(&mut rejects, is_bad_param(&va.update(bad, np))), "MAVP.update(real)");
        assert!(probed(&mut rejects, is_bad_param(&va.update(nc, bad))), "MAVP.update(period)");
        assert!(probed(&mut rejects, is_bad_param(&va.peek(nc, bad))), "MAVP.peek(period)");
        assert!(
            probed(&mut states, va.update(nc, np).unwrap().to_bits()
                == vb.update(nc, np).unwrap().to_bits()),
            "MAVP: a rejected bar moved the handle"
        );

        // --- composed tiers ---
        let (mut ba, _) = core.bbands_open(c, 20, 2.0, 2.0, MAType::SMA).unwrap();
        let (mut bb, _) = core.bbands_open(c, 20, 2.0, 2.0, MAType::SMA).unwrap();
        assert!(probed(&mut rejects, is_bad_param(&ba.update(bad))), "BBANDS.update accepted {bad}");
        assert!(probed(&mut rejects, is_bad_param(&ba.peek(bad))), "BBANDS.peek accepted {bad}");
        let (au, am, al) = ba.update(nc).unwrap();
        let (bu, bm, bl) = bb.update(nc).unwrap();
        assert!(
            probed(&mut states, (au.to_bits(), am.to_bits(), al.to_bits())
                == (bu.to_bits(), bm.to_bits(), bl.to_bits())),
            "BBANDS: a rejected bar moved the handle"
        );

        let (mut ka, _) = core
            .stoch_open(h, l, c, 5, 3, MAType::SMA, 3, MAType::SMA)
            .unwrap();
        let (mut kb, _) = core
            .stoch_open(h, l, c, 5, 3, MAType::SMA, 3, MAType::SMA)
            .unwrap();
        assert!(probed(&mut rejects, is_bad_param(&ka.update(bad, nl, nc))), "STOCH.update");
        assert!(probed(&mut rejects, is_bad_param(&ka.peek(nh, bad, nc))), "STOCH.peek");
        let (kak, kad) = ka.update(nh, nl, nc).unwrap();
        let (kbk, kbd) = kb.update(nh, nl, nc).unwrap();
        assert!(
            probed(&mut states, (kak.to_bits(), kad.to_bits())
                == (kbk.to_bits(), kbd.to_bits())),
            "STOCH: a rejected bar moved the handle"
        );

        // --- integer output, four price inputs ---
        let (mut ja, _) = core.cdldoji_open(o, h, l, c).unwrap();
        let (mut jb, _) = core.cdldoji_open(o, h, l, c).unwrap();
        assert!(probed(&mut rejects, is_bad_param(&ja.update(bad, nh, nl, nc))), "CDLDOJI.update(open)");
        assert!(probed(&mut rejects, is_bad_param(&ja.peek(no, nh, nl, bad))), "CDLDOJI.peek(close)");
        assert!(
            probed(&mut states, ja.update(no, nh, nl, nc).unwrap()
                == jb.update(no, nh, nl, nc).unwrap()),
            "CDLDOJI: a rejected bar moved the handle"
        );
    }
    // Both floors are literal and both counters live inside their assertions.
    assert!(rejects >= 57, "the reject sweep ran {rejects} probes");
    assert!(states >= 21, "the handle-unchanged sweep ran {states} compares");
}

/// A NaN real PARAMETER is rejected too.
///
/// Not a restatement of the range check: `x < min` and `x > max` are BOTH false
/// for NaN, so the batch tier's range test admits it — which is exactly why the
/// streaming tier spells the same two comparisons inverted,
/// `!(x >= min && x <= max)`. An infinity is already outside every declared
/// bound and both spellings reject it, so NaN is the whole difference.
#[test]
fn a_nan_real_parameter_is_rejected() {
    let core = Core::new();
    let (_, _, _, close, _) = series(WARM + 2);
    let c = &close[..WARM];

    assert!(
        is_bad_param(&core.bbands_open(c, 20, f64::NAN, 2.0, MAType::SMA)),
        "bbands_open accepted a NaN optInNbDevUp"
    );
    assert!(
        is_bad_param(&core.bbands_open(c, 20, 2.0, f64::NAN, MAType::SMA)),
        "bbands_open accepted a NaN optInNbDevDn"
    );
    // Control: the same call with both parameters in range must succeed, or the
    // two assertions above would pass for the wrong reason.
    assert!(
        core.bbands_open(c, 20, 2.0, 2.0, MAType::SMA).is_ok(),
        "the control open must succeed"
    );
}

// ---------------------------------------------------------------------------
// `update_and_fill`: n bars in one call, and what a rejected bar leaves behind
// (issue #246).
// ---------------------------------------------------------------------------

const UF_N: usize = 6;
const UF_BAD: usize = 3;
const UF_CANARY: f64 = -1.234_567_890_123_4e300;
const UF_CANARY_I: i32 = -987_654_321;

/// `update_and_fill` is a loop of `update`s that stops at the first error, so a
/// non-finite bar `k` is rejected exactly as `update` rejects it — the bars
/// before it stay committed with their values written, and bar `k` itself is
/// counted without being written (rule U3).
///
/// That is the one place in the API where a call returns an error AND leaves
/// output behind, so what it leaves is pinned against a CONTROL handle driven
/// the same way — the same bars one at a time, *including* the rejected one,
/// which is what makes this an equivalence rather than a comparison against a
/// constant. Same range, same values, same answer on the next good bar. A
/// whole-array pre-scan would satisfy "it rejects" and fail every one of those.
///
/// The control moves with the rule, so that equivalence is blind to the net
/// advance itself — drop the advance from both arms and it still holds. The
/// SMA arm therefore also asserts the count absolutely: the committed bars plus
/// the rejected one.
#[test]
fn update_and_fill_commits_the_bars_before_a_rejected_one() {
    let core = Core::new();
    let (open, high, low, close, periods) = series(WARM + UF_N + 1);
    let (o, h, l, c, p) = (
        &open[..WARM],
        &high[..WARM],
        &low[..WARM],
        &close[..WARM],
        &periods[..WARM],
    );
    let next = WARM + UF_N;
    let mut commits = 0usize;
    let mut absolute = 0usize;
    let mut values = 0usize;
    let mut untouched = 0usize;

    for &bad in &BAD {
        let mut bars: Vec<f64> = (0..UF_N).map(|i| close[WARM + i]).collect();
        bars[UF_BAD] = bad;

        // --- the shared step loop (loop / dual-mode / composed all reach it) --
        let (mut sa, _) = core.sma_open(c, 14).unwrap();
        let (mut sb, _) = core.sma_open(c, 14).unwrap();
        let base = sa.out_range().count;
        let want: Vec<f64> = (0..UF_BAD).map(|i| sb.update(bars[i]).unwrap()).collect();
        assert!(is_bad_param(&sb.update(bars[UF_BAD])), "SMA: the control accepted the bad bar");
        let mut out = vec![UF_CANARY; UF_N];
        assert!(
            is_bad_param(&sa.update_and_fill(&bars, &mut out)),
            "SMA.update_and_fill accepted {bad}"
        );
        assert!(
            probed(&mut absolute, sa.out_range().count == base + UF_BAD + 1),
            "SMA: counted {} for {UF_BAD} committed bars plus the rejected one",
            sa.out_range().count - base
        );
        assert!(
            probed(&mut commits, sa.out_range() == sb.out_range()),
            "SMA: committed {:?}, {UF_BAD} updates committed {:?}",
            sa.out_range(),
            sb.out_range()
        );
        for i in 0..UF_BAD {
            assert!(probed(&mut values, out[i].to_bits() == want[i].to_bits()), "SMA: value {i}");
        }
        for i in UF_BAD..UF_N {
            assert!(
                probed(&mut untouched, out[i].to_bits() == UF_CANARY.to_bits()),
                "SMA: wrote slot {i}, at or past the rejected bar"
            );
        }
        assert_eq!(
            sa.update(close[next]).unwrap().to_bits(),
            sb.update(close[next]).unwrap().to_bits(),
            "SMA: a rejected update_and_fill left the handle out of step"
        );

        // --- composed, three outputs: the commit has to be consistent across all
        let (mut ba, _) = core.bbands_open(c, 20, 2.0, 2.0, MAType::SMA).unwrap();
        let (mut bb, _) = core.bbands_open(c, 20, 2.0, 2.0, MAType::SMA).unwrap();
        let wantb: Vec<(f64, f64, f64)> =
            (0..UF_BAD).map(|i| bb.update(bars[i]).unwrap()).collect();
        assert!(is_bad_param(&bb.update(bars[UF_BAD])), "BBANDS: the control accepted the bad bar");
        let (mut bu, mut bm, mut bl) =
            (vec![UF_CANARY; UF_N], vec![UF_CANARY; UF_N], vec![UF_CANARY; UF_N]);
        assert!(
            is_bad_param(&ba.update_and_fill(&bars, &mut bu, &mut bm, &mut bl)),
            "BBANDS.update_and_fill accepted {bad}"
        );
        assert!(probed(&mut commits, ba.out_range() == bb.out_range()), "BBANDS: commit");
        for i in 0..UF_BAD {
            let got = (bu[i].to_bits(), bm[i].to_bits(), bl[i].to_bits());
            let w = (wantb[i].0.to_bits(), wantb[i].1.to_bits(), wantb[i].2.to_bits());
            assert!(probed(&mut values, got == w), "BBANDS: value {i}");
        }
        for i in UF_BAD..UF_N {
            let clean = bu[i].to_bits() == UF_CANARY.to_bits()
                && bm[i].to_bits() == UF_CANARY.to_bits()
                && bl[i].to_bits() == UF_CANARY.to_bits();
            assert!(probed(&mut untouched, clean), "BBANDS: wrote slot {i}");
        }

        // --- dispatch, both arms: period 1 is the identity loop, which never
        // reaches a sub-stream and carries its own copy of the per-bar check.
        for period in [1i32, 14] {
            let (mut ma, _) = core.ma_open(c, period, MAType::SMA).unwrap();
            let (mut mb, _) = core.ma_open(c, period, MAType::SMA).unwrap();
            let wantm: Vec<f64> = (0..UF_BAD).map(|i| mb.update(bars[i]).unwrap()).collect();
            assert!(
                is_bad_param(&mb.update(bars[UF_BAD])),
                "MA({period}): the control accepted the bad bar"
            );
            let mut mo = vec![UF_CANARY; UF_N];
            assert!(
                is_bad_param(&ma.update_and_fill(&bars, &mut mo)),
                "MA({period}).update_and_fill accepted {bad}"
            );
            assert!(probed(&mut commits, ma.out_range() == mb.out_range()), "MA({period}): commit");
            for i in 0..UF_BAD {
                assert!(probed(&mut values, mo[i].to_bits() == wantm[i].to_bits()), "MA({period}): value {i}");
            }
            for i in UF_BAD..UF_N {
                assert!(probed(&mut untouched, mo[i].to_bits() == UF_CANARY.to_bits()), "MA({period}): slot {i}");
            }
        }

        // --- period-bank: the poisoned slot is the PERIOD series, the one input
        // that reaches an `as i32`.
        let good_bars: Vec<f64> = (0..UF_N).map(|i| close[WARM + i]).collect();
        let mut pers: Vec<f64> = (0..UF_N).map(|i| 2.0 + (i % 8) as f64).collect();
        pers[UF_BAD] = bad;
        let (mut va, _) = core.mavp_open(c, p, 2, 30, MAType::SMA).unwrap();
        let (mut vb, _) = core.mavp_open(c, p, 2, 30, MAType::SMA).unwrap();
        let wantv: Vec<f64> = (0..UF_BAD)
            .map(|i| vb.update(good_bars[i], pers[i]).unwrap())
            .collect();
        assert!(
            is_bad_param(&vb.update(good_bars[UF_BAD], pers[UF_BAD])),
            "MAVP: the control accepted the bad period"
        );
        let mut vo = vec![UF_CANARY; UF_N];
        assert!(
            is_bad_param(&va.update_and_fill(&good_bars, &pers, &mut vo)),
            "MAVP.update_and_fill accepted {bad} in the period series"
        );
        assert!(probed(&mut commits, va.out_range() == vb.out_range()), "MAVP: commit");
        for i in 0..UF_BAD {
            assert!(probed(&mut values, vo[i].to_bits() == wantv[i].to_bits()), "MAVP: value {i}");
        }
        for i in UF_BAD..UF_N {
            assert!(probed(&mut untouched, vo[i].to_bits() == UF_CANARY.to_bits()), "MAVP: slot {i}");
        }

        // --- integer output over four price inputs; poison the LOW, so a check
        // that only looked at the first input array would still be caught.
        let mut lows: Vec<f64> = (0..UF_N).map(|i| low[WARM + i]).collect();
        lows[UF_BAD] = bad;
        let opens: Vec<f64> = (0..UF_N).map(|i| open[WARM + i]).collect();
        let highs: Vec<f64> = (0..UF_N).map(|i| high[WARM + i]).collect();
        let (mut ja, _) = core.cdldoji_open(o, h, l, c).unwrap();
        let (mut jb, _) = core.cdldoji_open(o, h, l, c).unwrap();
        let wantj: Vec<i32> = (0..UF_BAD)
            .map(|i| jb.update(opens[i], highs[i], lows[i], good_bars[i]).unwrap())
            .collect();
        assert!(
            is_bad_param(&jb.update(opens[UF_BAD], highs[UF_BAD], lows[UF_BAD], good_bars[UF_BAD])),
            "CDLDOJI: the control accepted the bad low"
        );
        let mut jo = vec![UF_CANARY_I; UF_N];
        assert!(
            is_bad_param(&ja.update_and_fill(&opens, &highs, &lows, &good_bars, &mut jo)),
            "CDLDOJI.update_and_fill accepted {bad} in the low series"
        );
        assert!(probed(&mut commits, ja.out_range() == jb.out_range()), "CDLDOJI: commit");
        for i in 0..UF_BAD {
            assert!(probed(&mut values, jo[i] == wantj[i]), "CDLDOJI: value {i}");
        }
        for i in UF_BAD..UF_N {
            assert!(probed(&mut untouched, jo[i] == UF_CANARY_I), "CDLDOJI: slot {i}");
        }
    }
    // Literal floors, every counter incremented inside the assertion it counts.
    assert!(commits >= 18, "the commit sweep ran {commits} compares");
    assert!(absolute >= 3, "the absolute-count sweep ran {absolute} compares");
    assert!(values >= 54, "the value sweep ran {values} compares");
    assert!(untouched >= 54, "the untouched sweep ran {untouched} compares");
}

/// The two rejections Rust can reach that C cannot: slices carry their own
/// lengths, so a ragged input set and an output too short for the run are
/// answerable before anything is committed. Both must leave the handle exactly
/// where it was — and a zero-bar call is a success that does the same.
#[test]
fn update_and_fill_rejects_bad_lengths_and_treats_zero_bars_as_a_no_op() {
    let core = Core::new();
    let (_, high, low, close, _) = series(WARM + UF_N + 1);
    let c = &close[..WARM];
    let bars: Vec<f64> = (0..UF_N).map(|i| close[WARM + i]).collect();

    let (mut s, _) = core.sma_open(c, 14).unwrap();
    let before = s.out_range();
    let mut out = vec![UF_CANARY; UF_N];

    assert!(s.update_and_fill(&[], &mut out).is_ok(), "zero bars must be a no-op");
    assert_eq!(s.out_range(), before, "a zero-bar call moved the handle");
    assert_eq!(out[0].to_bits(), UF_CANARY.to_bits(), "a zero-bar call wrote a value");

    assert!(
        is_bad_param(&s.update_and_fill(&bars, &mut out[..UF_N - 1])),
        "an output shorter than the run must reject"
    );
    assert_eq!(s.out_range(), before, "a short output moved the handle");

    // Ragged inputs, on a multi-input function.
    let (mut d, _) = core
        .minus_di_open(&high[..WARM], &low[..WARM], c, 14)
        .unwrap();
    let dbefore = d.out_range();
    let hs: Vec<f64> = (0..UF_N).map(|i| high[WARM + i]).collect();
    let ls: Vec<f64> = (0..UF_N).map(|i| low[WARM + i]).collect();
    let mut dout = vec![UF_CANARY; UF_N];
    assert!(
        is_bad_param(&d.update_and_fill(&hs, &ls[..UF_N - 1], &bars, &mut dout)),
        "input series of different lengths must reject"
    );
    assert_eq!(d.out_range(), dbefore, "a ragged input set moved the handle");

    // Control: the same call with everything the right length succeeds and
    // advances by exactly the bars it was handed.
    assert!(d.update_and_fill(&hs, &ls, &bars, &mut dout).is_ok());
    assert_eq!(d.out_range().count, dbefore.count + UF_N);
}

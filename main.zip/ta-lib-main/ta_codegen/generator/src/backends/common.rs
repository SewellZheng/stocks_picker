//! Pure IR-inspection helpers shared by the language backends.
//!
//! These walk the backend-agnostic [`Statement`]/[`Expr`] AST and contain no
//! language-specific output, so every backend shares one copy instead of
//! re-implementing them. New backends import from here rather than copy-pasting.

use crate::ir::{BinOp, EnumDef, EnumVariant, Expr, FuncDef, ParamType, Statement};
use crate::registry::Lang;
use std::collections::{BTreeSet, HashMap};

// TA-Lib's parameter sentinels, mirroring include/ta_defs.h. The "use the
// default" value deliberately sits one step OUTSIDE the legal range so
// `x == DEFAULT` can never collide with real data — hence -4e37 vs -3e37, and
// i32::MIN vs i32::MIN+1. DBL_MIN/DBL_MAX cannot express that scheme (there is
// no representable double outside them to spare), which is why these are fixed
// decimals. Values are pinned by the ta_defs_sentinels_match test below.
pub const TA_REAL_MIN: f64 = -3e37;
pub const TA_REAL_MAX: f64 = 3e37;
pub const TA_REAL_DEFAULT: f64 = -4e37;
pub const TA_INTEGER_MIN: i32 = i32::MIN + 1;
pub const TA_INTEGER_MAX: i32 = i32::MAX;
pub const TA_INTEGER_DEFAULT: i32 = i32::MIN;

/// The rejection condition for a real optional parameter's declared range.
///
/// Spelled `!(x >= min && x <= max)` rather than the obvious `x < min || x > max`.
/// The two are identical for every finite `x` — and every declared bound in the
/// corpus is finite, ±3e37 at the widest — but they differ on NaN, and that
/// difference is the whole point: `NaN < min` and `NaN > max` are BOTH false, so
/// the obvious spelling silently ACCEPTS a NaN parameter and computes with it.
/// The inverted form costs the same two comparisons and rejects NaN along with
/// the infinities.
///
/// One spelling everywhere — batch, lookback and streaming. The streaming tier
/// got it first (it cannot afford a NaN entering a retained handle), but there
/// was never a reason for the batch tier to accept a parameter it has no
/// meaning for; "batch does not filter" is a statement about INPUT SERIES, not
/// about parameters.
///
/// `paren` parenthesizes each comparison, which is how the Rust backend has
/// always spelled it.
#[must_use]
pub(crate) fn real_range_reject(name: &str, lo: &str, hi: &str, paren: bool) -> String {
    if paren {
        format!("!(({name} >= {lo}) && ({name} <= {hi}))")
    } else {
        format!("!({name} >= {lo} && {name} <= {hi})")
    }
}

/// Render a real range bound: the `REAL_MIN`/`REAL_MAX` sentinels by name, anything
/// else as a literal. `prefix` is the backend's namespace — `"TA_"` for C, `"Self::"`
/// for Rust (they are associated consts on `Core`, as they are static members of
/// Java's `Core`, and the emission site is inside `impl Core`), empty for Java, whose
/// package already namespaces them — so the generated sources name the constant
/// instead of repeating ±3e37.
#[must_use]
#[allow(clippy::float_cmp)] // these are exact sentinel values, not measurements
pub fn real_bound_literal(v: f64, prefix: &str) -> String {
    real_bound_named(v, prefix, "REAL_MIN", "REAL_MAX")
}

/// `real_bound_literal` for a backend that spells the two sentinels its own way
/// (C# has `RealMin`/`RealMax`).
#[must_use]
#[allow(clippy::float_cmp)] // these are exact sentinel values, not measurements
pub fn real_bound_named(v: f64, prefix: &str, min: &str, max: &str) -> String {
    if v == TA_REAL_MIN {
        format!("{prefix}{min}")
    } else if v == TA_REAL_MAX {
        format!("{prefix}{max}")
    } else {
        format!("{v:e}")
    }
}

/// The name every enum uses for its "let the function choose" member (#182).
pub(crate) const ENUM_DEFAULT_VARIANT: &str = "DEFAULT";

/// The enum's `DEFAULT` member, when its type declares one.
///
/// A parameter typed by such an enum accepts two spellings of "use the documented
/// default": the generic `TA_INTEGER_DEFAULT` sentinel every integer parameter
/// takes, and this member. Both resolve to the parameter's own `default:`, which
/// differs per parameter — so every backend's validation prologue substitutes it
/// before the body runs, and no switch arm ever sees it.
#[must_use]
pub(crate) fn enum_default_variant<'a>(
    enums: &'a HashMap<String, EnumDef>,
    enum_name: &str,
) -> Option<&'a EnumVariant> {
    enums
        .get(enum_name)?
        .variants
        .iter()
        .find(|v| v.name == ENUM_DEFAULT_VARIANT)
}

/// Prose for a `MAType` member that does not name a moving average.
///
/// `DISABLED` (#93) and `DEFAULT` (#182) sit in the same list as SMA and EMA but
/// select a behaviour rather than an average, so every surface that describes the
/// members one by one would otherwise call them moving averages. Two entries, in
/// one place, rather than a `doc:` field on a schema whose members are otherwise
/// pure name-and-value: nothing here can go stale silently, because a member with
/// no entry gets the "moving average" wording that is right for every real one.
#[must_use]
pub(crate) fn ma_pseudo_member_doc(variant: &str) -> Option<&'static str> {
    match variant {
        "DISABLED" => Some("Not a moving average: the input is copied through unchanged."),
        ENUM_DEFAULT_VARIANT => Some(
            "Not a moving average: selects the documented default of whichever \
             parameter it is passed to.",
        ),
        _ => None,
    }
}

/// The enum types some function declares an optional parameter with.
///
/// Those are the only enums that get generated limit constants, because they are
/// the only ones whose value crosses the API boundary as a caller-supplied
/// integer and therefore has to be range-checked. `FuncUnstId` is deliberately
/// excluded by the same rule: no parameter is typed with it, and its `ALL`
/// wildcard sits far outside the member span, so limits derived from the members
/// would describe a domain its API does not have.
#[must_use]
pub fn param_enum_names(funcs: &[FuncDef]) -> BTreeSet<String> {
    funcs
        .iter()
        .flat_map(|f| &f.optional_inputs)
        .filter_map(|opt| match &opt.param_type {
            ParamType::Enum(name) => Some(name.clone()),
            _ => None,
        })
        .collect()
}

/// How `lang` spells the generated inclusive value-limit constants of an `enum:`
/// parameter type — `(min, max)`, or `None` when that backend declares none.
///
/// This function is the single registry of both halves: *whether* a backend has
/// the constants and *what they are called*. The emitter that declares them and
/// every emitter that references them read the same answer, so a range check can
/// never name a constant the enum surface did not emit, and appending a member
/// moves the declaration and every use together.
///
/// C and C# have them because both surface the parameter as a plain integer a
/// caller can put any value in, so both generate a range check that needs a
/// bound to name. Java and Rust have neither the check nor the constants: their
/// `MAType` is a real enum, the only values reachable through the typed API are
/// members, and Rust's `TryFrom<i32>` is itself the domain gate — a second
/// spelling of the domain there would disagree with it about the
/// `TA_INTEGER_DEFAULT` sentinel, which `TryFrom` accepts. A future backend that
/// does need one adds an arm here and a declaration in its enum emitter.
#[must_use]
pub fn enum_limit_names_of(def: &EnumDef, lang: Lang) -> Option<(String, String)> {
    match lang {
        // Macros rather than enumerators: an enumerator would join the member
        // list and be an `optInMAType` a caller could pass. The prefix is
        // upper-cased -- `TA_MAType_` -> `TA_MATYPE_` -- so the macro cannot be
        // read as one of the members it bounds, which the shared prefix would
        // otherwise suggest. Uniform, not a MAType special case: an already
        // upper-case prefix like `TA_FUNC_UNST_` passes through unchanged.
        Lang::C => {
            let p = def.c_prefix.to_uppercase();
            Some((format!("{p}MIN"), format!("{p}MAX")))
        }
        // A C# enum cannot hold static members, so they live in the sibling
        // static class the `FuncUnstIds.Count` companion already established.
        Lang::CSharp => Some((format!("{}s.Min", def.name), format!("{}s.Max", def.name))),
        Lang::Java | Lang::Rust => None,
    }
}

/// [`enum_limit_names_of`] keyed by type name, for the emitters that hold the
/// map rather than the definition.
#[must_use]
pub(crate) fn enum_limit_names(
    enums: &HashMap<String, EnumDef>,
    enum_name: &str,
    lang: Lang,
) -> Option<(String, String)> {
    enum_limit_names_of(enums.get(enum_name)?, lang)
}

/// The inclusive bounds an integer-valued optional parameter's validation
/// prologue must compare against, already spelled for `lang`: a declared
/// `range:` renders as literals, an `enum:` domain names that enum's generated
/// limit constants instead of repeating their values.
///
/// # Panics
///
/// If `lang` asks for an `enum:` parameter's bounds but declares no limit
/// constants for that enum. Emitting the literal span instead would silently
/// reintroduce the per-call-site copy of the bound this exists to remove, so it
/// fails the generate rather than the review.
#[must_use]
#[allow(clippy::implicit_hasher)]
// Integer optional-param ranges are stored as `f64` in the IR; casting the
// integer-valued ones for literal emission is exact, not truncating.
#[allow(clippy::cast_possible_truncation)]
pub fn int_bound_exprs(
    opt: &crate::ir::OptInput,
    enums: &HashMap<String, EnumDef>,
    lang: Lang,
) -> Option<(String, String)> {
    if let Some((lo, hi)) = opt.range {
        return Some(((lo as i32).to_string(), (hi as i32).to_string()));
    }
    let ParamType::Enum(name) = &opt.param_type else {
        return None;
    };
    // Asserts contiguity, so a gapped enum fails here rather than admitting the
    // missing value through the span the constants describe.
    enum_value_bounds(enums, name)?;
    Some(enum_limit_names(enums, name, lang).unwrap_or_else(|| {
        panic!(
            "{lang:?} range-checks the enum parameter {} but declares no limit \
             constants for {name}: add the arm in common::enum_limit_names and the \
             declaration in that backend's enum emitter.",
            opt.name
        )
    }))
}

/// The inclusive value range an `enum:` parameter accepts: `0..=max member`.
///
/// A choice list declares no `range:` in YAML, so until now nothing rejected a
/// value outside it and each body decided for itself — which is how a lookback
/// came to answer a usable number for parameters its own function rejects. The
/// prologue is where the two tiers agree by construction: one emitter, two
/// failure literals.
///
/// Derived from the members, so an appended one widens the gate automatically.
#[must_use]
pub fn enum_value_bounds_of(e: &EnumDef) -> Option<(i32, i32)> {
    let enum_name = &e.name;
    let lo = e.variants.iter().map(|v| v.value).min()?;
    let hi = e.variants.iter().map(|v| v.value).max()?;
    // A span only describes the member set while the values are contiguous, and
    // the prologue gate this feeds is `< lo || > hi` -- a reserved slot would sit
    // inside the span and reach the body's dispatch again, re-arming exactly the
    // defect the gate exists to close. MAType is asserted contiguous by three
    // emitters, but each of those names it explicitly; this helper is generic, so
    // it checks here rather than inheriting an invariant keyed to another type.
    let n = i32::try_from(e.variants.len()).unwrap_or(i32::MAX);
    assert!(
        hi - lo + 1 == n,
        "enum {enum_name} has a gap in its values ({lo}..={hi} over {n} members): the \
         validation prologue gates on the span, which would admit the missing value. \
         Emit a membership test instead of widening this."
    );
    Some((lo, hi))
}

/// [`enum_value_bounds_of`] keyed by type name.
#[must_use]
pub(crate) fn enum_value_bounds(
    enums: &HashMap<String, EnumDef>,
    enum_name: &str,
) -> Option<(i32, i32)> {
    enum_value_bounds_of(enums.get(enum_name)?)
}

/// `Type.MEMBER` for `value`, when the enum declares a member with that value.
///
/// Java and C# spell a qualified enum member identically, so both render from
/// here. They differ only in the fallback for a value no member carries: C# can
/// cast, Java cannot — hence `Option` rather than a shared default.
#[must_use]
pub(crate) fn enum_member_literal(
    enums: &HashMap<String, EnumDef>,
    enum_name: &str,
    value: i32,
) -> Option<String> {
    let v = enums.get(enum_name)?.variants.iter().find(|v| v.value == value)?;
    Some(format!("{enum_name}.{}", v.name))
}

/// The candlestick helper functions (`ta_candlerange`, `ta_candleaverage`) whose
/// calls are unpacked/hoisted before the surrounding expression is rendered.
pub const CANDLE_FNS: &[&str] = &["ta_candlerange", "ta_candleaverage"];

/// True if `expr` directly contains a call to a candlestick helper, stopping the
/// walk at logical `&&`/`||` operators (which begin a separate condition in the
/// chain).
// The `And|Or => false` arm is intentionally separate from the catch-all: it must
// precede the general `BinOp` arm to stop the walk at logical operators.
#[allow(clippy::match_same_arms)]
pub fn expr_directly_contains_candle_call(expr: &Expr) -> bool {
    match expr {
        Expr::FuncCall(name, args) => {
            CANDLE_FNS.contains(&name.as_str())
                || args.iter().any(expr_directly_contains_candle_call)
        }
        // Stop at logical operators — those are separate conditions in the chain
        Expr::BinOp(_, BinOp::And | BinOp::Or, _) => false,
        Expr::BinOp(l, _, r) => {
            expr_directly_contains_candle_call(l) || expr_directly_contains_candle_call(r)
        }
        Expr::Ternary(c, t, e) => {
            expr_directly_contains_candle_call(c)
                || expr_directly_contains_candle_call(t)
                || expr_directly_contains_candle_call(e)
        }
        Expr::Cast(_, inner)
        | Expr::Not(inner)
        | Expr::BitwiseNot(inner)
        | Expr::AddressOf(inner)
        | Expr::PostIncrement(inner)
        | Expr::PostDecrement(inner)
        | Expr::PreIncrement(inner)
        | Expr::PreDecrement(inner) => expr_directly_contains_candle_call(inner),
        Expr::ArrayAccess(_, idx) => expr_directly_contains_candle_call(idx),
        Expr::Var(_) | Expr::Literal(_) | Expr::IntLiteral(_) | Expr::PointerDeref(_) => false,
    }
}

/// PascalCase a single word: lowercase it, then upper-case the first character
/// (`"SMA"` → `"Sma"`, `"rsi"` → `"Rsi"`). For multi-segment `snake_case` names,
/// backends use their own underscore-splitting `pascal_words` instead.
pub fn pascal_word(s: &str) -> String {
    let lower = s.to_lowercase();
    let mut chars = lower.chars();
    match chars.next() {
        None => String::new(),
        Some(c) => c.to_uppercase().collect::<String>() + chars.as_str(),
    }
}

/// PascalCase a `_`-joined SCREAMING name, one word per segment (`"HT_TRENDLINE"`
/// -> `"HtTrendline"`, `"CDL2CROWS"` (no `_`) -> `"Cdl2crows"`, `"MA"` -> `"Ma"`).
pub fn pascal_words(name: &str) -> String {
    name.split('_').map(pascal_word).collect()
}

/// `pascal_words` with the leading segment lower-cased (`"HT_TRENDLINE"` -> `"htTrendline"`).
pub fn camel_words(name: &str) -> String {
    let p = pascal_words(name);
    let mut chars = p.chars();
    match chars.next() {
        Some(f) => f.to_ascii_lowercase().to_string() + chars.as_str(),
        None => String::new(),
    }
}

/// Lower-case a SCREAMING name, `_` untouched (`"HT_TRENDLINE"` -> `"ht_trendline"`).
pub fn snake_words(name: &str) -> String {
    name.to_lowercase()
}

/// True if any statement is `return ALLOC_ERR;`.
pub fn contains_alloc_err_return(stmts: &[Statement]) -> bool {
    // "Err(RetCode::AllocErr)" is the Rust stream tier's pre-mapped form of the
    // same return (`map_return_code` runs before rendering); no batch IR ever
    // carries it, so recognizing it is batch-invariant.
    stmts.iter().any(|s| matches!(s, Statement::Return { value: Some(Expr::Var(name)) }
        if name == "ALLOC_ERR" || name == "Err(RetCode::AllocErr)"))
}

/// If `expr` is (or recursively contains) a `sizeof(TYPE)`, return the type name.
pub fn find_sizeof_type(expr: &Expr) -> Option<String> {
    match expr {
        Expr::FuncCall(name, args) if name == "sizeof" => args.first().and_then(|a| match a {
            Expr::Var(type_name) => Some(type_name.clone()),
            _ => None,
        }),
        Expr::BinOp(left, _, right) => find_sizeof_type(left).or_else(|| find_sizeof_type(right)),
        Expr::Cast(_, inner) => find_sizeof_type(inner),
        _ => None,
    }
}

/// The widest output arity in the corpus, split by element type:
/// `(reals, integers)`.
///
/// The C harnesses — `ta_codegen_serve`, `ta_bench`, `ta_bench_stream` and the
/// in-server `stream_verify` — hand every function the same file-scope buffers,
/// so they need one per output slot any function can use. That count has to come
/// from the corpus and never from a literal: a literal is only ever the corpus's
/// current maximum, and the first function past it fails to compile against a
/// buffer that was never declared (#262).
///
/// The split follows the emitters' own test — `ParamType::Integer` is the `int`
/// buffer, everything else is `double` — so the three cannot drift apart.
#[must_use]
pub fn max_output_arity(funcs: &[FuncDef]) -> (usize, usize) {
    funcs.iter().fold((0, 0), |(reals, ints), f| {
        let n_int = f
            .outputs
            .iter()
            .filter(|o| o.param_type == ParamType::Integer)
            .count();
        (reals.max(f.outputs.len() - n_int), ints.max(n_int))
    })
}

/// The outputs a caller may decline — the `nullable` flag in the .yaml, rule
/// B6a of `docs/error-handling-spec.md`.
///
/// One source of truth for the four backends: each spells "declined" in its own
/// way (`NULL` in C, `null` in Java, `None` in Rust, an empty `Span` in C#), but
/// all four have to guard the same set of stores, and all four skip the same
/// presence/capacity check on them.
#[must_use]
pub(crate) fn nullable_output_names(func: &FuncDef) -> std::collections::HashSet<String> {
    nullable_output_list(func).into_iter().collect()
}

/// [`nullable_output_names`] in declaration order, for the emitters that carry
/// the set as a slice.
///
/// The one producer, so that asking which outputs are declinable is also what
/// runs [`assert_nullable_stores_are_guardable`]: a backend cannot reach the
/// answer without the check. That matters because `generate --backend=c` runs
/// only the C emitter — a check wired into the Rust one alone would be skipped
/// by exactly the invocation a C-only contributor uses.
#[must_use]
pub(crate) fn nullable_output_list(func: &FuncDef) -> Vec<String> {
    let names: Vec<String> = func
        .outputs
        .iter()
        .filter(|o| o.is_nullable())
        .map(|o| o.name.clone())
        .collect();
    if !names.is_empty() {
        assert_nullable_stores_are_guardable(func, &names);
    }
    names
}

/// Guarding a store is only *complete* while the cursor advance rides a store
/// that is always made. Enforce that, rather than trusting the comment in
/// `mama.c` that says so.
///
/// Every backend wraps a store into a nullable output in an `if declined` guard
/// and leaves the rest of the body alone. So if the `outIdx++` sat on that
/// store, declining the output would stop the cursor: the call would report
/// `outNBElement = 0`, write every other output repeatedly to index 0, and
/// return success. No gate can see it — the JSON-RPC servers bind every declared
/// output, so the declining call is never made — which is exactly why this is an
/// assert and not a test.
///
/// Two conditions, both cheap:
///
/// * at least one output is **not** nullable, so a cursor has somewhere to ride;
/// * no nullable output is indexed by an increment or decrement, in a store or a
///   read. A read of a declined output is a hazard of its own.
///
/// Panics loudly, at generate time, naming the output — the house answer for a
/// shape the emitters cannot render correctly (`c_stream.rs` asserts the same
/// way for the dispatch tiers that have no NULL-guarded form at all).
fn assert_nullable_stores_are_guardable(func: &FuncDef, nullable: &[String]) {
    assert!(
        nullable.len() < func.outputs.len(),
        "{}: every output is `nullable` — the `outIdx` advance has no store to ride,          so a caller who declined them all would leave the cursor at 0",
        func.name
    );
    // The IR's own spelling of "this output is indexed by a cursor step", read
    // off the debug form: `ArrayAccess("outX", PostIncrement(...))` and its three
    // siblings. Matching the rendered shape keeps this in step with what the
    // emitters actually wrap, which is the assignment target, not the statement.
    let body = format!("{:?}", func.body);
    for name in nullable {
        for step in [
            "PostIncrement",
            "PostDecrement",
            "PreIncrement",
            "PreDecrement",
        ] {
            let needle = format!("ArrayAccess(\"{name}\", {step}(");
            assert!(
                !body.contains(&needle),
                "{}: `{name}` is `nullable` and its index carries a `{step}` — the guard                  would make the cursor conditional on the caller declining it. Move the                  advance onto an output that is always written (see mama.c).",
                func.name
            );
        }
    }
}

/// One C# span-overlap term, shared by the batch (`csharp.rs`) and streaming
/// (`csharp_stream.rs`) aliasing guards.
///
/// `a_ty` / `b_ty` are C# ELEMENT types (`double`, `float`, `int`), not a
/// signedness or an is-integer flag: the float overload pairs a `float` input
/// with a `double` output, and nothing narrower can tell that pair from a
/// same-typed one.
///
/// Same element type: `Span<T>.Overlaps` directly. Different: `Overlaps` is not
/// defined across element types, but a caller CAN place the two on one backing
/// buffer (`MemoryMarshal.Cast`, or any other reinterpretation), so compare the
/// byte ranges instead — `MemoryMarshal.AsBytes` is safe code for any unmanaged
/// `T` and needs no `unsafe` block here. Differing WIDTH is no barrier either:
/// a `Span<float>` and a `Span<double>` over one `byte[]` overlap, which is the
/// premise that made this skippable and was wrong twice (#386).
///
/// `allow_identity` carves out the exact-same-span case (`a == b`) from the
/// same-type rejection: legitimate for an output computing in place over one
/// of its inputs (BBANDS-style scratch election), never legitimate between
/// two outputs, and moot on the cross-type arm — two spans of different element
/// type can never be the same span object to begin with, so the carve-out would
/// be dead code there.
pub(crate) fn csharp_overlap_expr(
    a: &str,
    a_ty: &str,
    b: &str,
    b_ty: &str,
    allow_identity: bool,
) -> String {
    if a_ty == b_ty {
        if allow_identity {
            format!("({a}.Overlaps({b}) && {a} != {b})")
        } else {
            format!("{a}.Overlaps({b})")
        }
    } else {
        format!(
            "System.Runtime.InteropServices.MemoryMarshal.AsBytes({a}).Overlaps(\
             System.Runtime.InteropServices.MemoryMarshal.AsBytes({b}))"
        )
    }
}

// ---------------------------------------------------------------------------
// Markdown emphasis, for the doc targets that render markup
// ---------------------------------------------------------------------------

/// True when `chars[i..]` opens a run of exactly `len` asterisks — so a lookup
/// for `*` never matches half of a `**`.
#[must_use]
pub(crate) fn asterisks_at(chars: &[char], i: usize, len: usize) -> bool {
    if chars.len() < i + len || !chars[i..i + len].iter().all(|&c| c == '*') {
        return false;
    }
    chars.get(i + len) != Some(&'*')
}

/// Whether a `len`-asterisk run opened at `from` ever closes. Code spans are
/// skipped: an asterisk between backticks is source text, so it can neither
/// close nor open emphasis.
fn emphasis_closes(chars: &[char], from: usize, len: usize) -> bool {
    let mut in_code = false;
    let mut i = from;
    while i < chars.len() {
        if chars[i] == '`' {
            in_code = !in_code;
            i += 1;
            continue;
        }
        if !in_code && asterisks_at(chars, i, len) && i > from && !chars[i - 1].is_whitespace() {
            return true;
        }
        i += 1;
    }
    false
}

/// The delimiter length of the Markdown emphasis run opening at `chars[i]` — 2
/// for `**bold**`, 1 for `*italic*` — or `None` when this asterisk is prose.
///
/// The canonical `.md` files are Markdown, and the Rust doc target renders them
/// as such. The HTML and XML targets do not, so each converts what it can: this
/// is the one place that decides *what counts*, so the two cannot disagree about
/// it. Each caller supplies its own tags.
///
/// Recognized only when the run pairs, only outside a code span, and only at a
/// boundary that flanks non-space without splitting a word. An asterisk failing
/// any of those is prose: the corpus multiplies with it (`factor = 4*ATR`) and
/// names parameters with it (`optInROC*Period`), and neither is emphasis.
///
/// Formulas never come through the escapers — every backend renders them as
/// preformatted text through its own raw escaper, where `*` is math.
#[must_use]
pub(crate) fn emphasis_open(chars: &[char], i: usize) -> Option<usize> {
    if chars.get(i) != Some(&'*') {
        return None;
    }
    let len = if asterisks_at(chars, i, 2) { 2 } else { 1 };
    if !asterisks_at(chars, i, len) {
        return None; // a run of three or more: not emphasis the corpus writes
    }
    let splits_word = len == 1 && i > 0 && chars[i - 1].is_alphanumeric();
    // An asterisk immediately after another is the tail of a run already
    // accounted for — the second `*` of `**bold**`, which reads as a lone
    // italic opener when asked about on its own. The escapers consume both at
    // once and never ask, but the answer must not depend on that: a helper two
    // callers share has to give the same reading at every position.
    let continues_run = i > 0 && chars[i - 1] == '*';
    let flanks_text = chars.get(i + len).is_some_and(|n| !n.is_whitespace());
    (!splits_word && !continues_run && flanks_text && emphasis_closes(chars, i + len, len))
        .then_some(len)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// What `emphasis_open` answers, as the escapers ask it: the delimiter
    /// length at each `*`, or `None`.
    fn opens(text: &str) -> Vec<(usize, Option<usize>)> {
        let chars: Vec<char> = text.chars().collect();
        chars
            .iter()
            .enumerate()
            .filter(|(_, c)| **c == '*')
            .map(|(i, _)| (i, emphasis_open(&chars, i)))
            .collect()
    }

    #[test]
    fn bold_and_italic_are_recognized() {
        // "the **sum** of" — the opener answers 2, the closer is not an opener.
        assert_eq!(opens("the **sum** of"), vec![(4, Some(2)), (5, None), (9, None), (10, None)]);
        assert_eq!(opens("travels *within* a"), vec![(8, Some(1)), (15, None)]);
    }

    /// An asterisk in a code span is the author's text. Nothing else in the
    /// corpus asserts this, and the natural over-fix — convert every `*` —
    /// would rewrite parameter names inside `{@code ...}`.
    #[test]
    fn a_code_span_is_not_emphasis() {
        assert_eq!(opens("`optInROC*Period` back"), vec![(9, None)]);
        assert_eq!(opens("`a * b` and `c * d`"), vec![(3, None), (15, None)]);
    }

    /// Each pairing rule in the direction that would corrupt prose if the
    /// scanner were greedier.
    #[test]
    fn unpaired_and_intraword_asterisks_are_prose() {
        assert_eq!(opens("factor = 4*ATR"), vec![(10, None)]);
        assert_eq!(opens("a lone * asterisk"), vec![(7, None)]);
        assert_eq!(opens("opens *but never closes"), vec![(6, None)]);
        assert_eq!(opens("4 * 5 = 20"), vec![(2, None)]);
    }

    /// A `*` closer may not be half of a `**`, or `**bold**` reads as an italic
    /// followed by a stray asterisk.
    #[test]
    fn a_bold_run_is_not_two_italics() {
        let o = opens("**a** and *b*");
        assert_eq!(o[0], (0, Some(2)));
        assert_eq!(o[1], (1, None));
        assert_eq!(o.last(), Some(&(12, None)));
    }

    /// The sentinels above are a copy of `include/ta_defs.h`, which is hand-written
    /// public ABI. Nothing else notices when the two drift: a wrong value silently
    /// widens or narrows every generated range check (that is exactly how
    /// `TA_REAL_MAX` came to be emitted as `f64::MAX`). Pin them to the header.
    #[test]
    #[allow(clippy::float_cmp)] // pinning exact literals is the point
    fn ta_defs_sentinels_match() {
        let hdr = std::fs::read_to_string(
            std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../include/ta_defs.h"),
        )
        .expect("include/ta_defs.h");
        for (macro_name, expected) in [
            ("TA_REAL_MIN", "(-3e+37)"),
            ("TA_REAL_MAX", "(3e+37)"),
            ("TA_REAL_DEFAULT", "(-4e+37)"),
            ("TA_INTEGER_MIN", "(INT_MIN+1)"),
            ("TA_INTEGER_MAX", "(INT_MAX)"),
            ("TA_INTEGER_DEFAULT", "(INT_MIN)"),
        ] {
            let needle = format!("#define {macro_name} ");
            let line = hdr
                .lines()
                .find(|l| l.starts_with(&needle))
                .unwrap_or_else(|| panic!("{macro_name} not found in ta_defs.h"));
            assert_eq!(
                line[needle.len()..].trim(),
                expected,
                "{macro_name} changed in ta_defs.h; update backends::common to match"
            );
        }
        // And that our Rust values are those literals.
        assert_eq!(TA_REAL_MIN, -3e37);
        assert_eq!(TA_REAL_MAX, 3e37);
        assert_eq!(TA_REAL_DEFAULT, -4e37);
        assert_eq!(TA_INTEGER_MIN, i32::MIN + 1);
        assert_eq!(TA_INTEGER_MAX, i32::MAX);
        assert_eq!(TA_INTEGER_DEFAULT, i32::MIN);
    }
}

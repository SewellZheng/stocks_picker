# APO

## Summary

Absolute Price Oscillator: the difference between a fast and a slow moving average of the input, in price units. Measures short- vs long-term momentum. Positive when fast MA > slow MA (upward momentum); negative otherwise.

## Formula

$APO = MA_{fast}(inReal) - MA_{slow}(inReal)$, both MAs of type optInMAType

The standard form is exponential — APO with EMA and periods 12/26 is the fast-minus-slow EMA construction underlying the MACD (in price units). `optInMAType` therefore **defaults to EMA** — the moving average Gerald Appel used for the original MACD; pass another type (e.g. `TA_MAType_SMA`) to override.

## Inputs

- `inReal` — Source data series

## Outputs

- `outReal` — Fast MA minus slow MA

## Parameters

- `optInFastPeriod` — Period of the fast moving average
- `optInSlowPeriod` — Period of the slow moving average
- `optInMAType` — Moving-average type used for both MAs

## Implementation

TA-Lib Definition: [`apo.c`](https://github.com/TA-Lib/ta-lib/blob/main/ta_codegen/input/apo/apo.c) · [`apo.yaml`](https://github.com/TA-Lib/ta-lib/blob/main/ta_codegen/input/apo/apo.yaml)

| Native | File |
|--------|------|
| C | [`ta_APO.c`](https://github.com/TA-Lib/ta-lib/blob/main/src/ta_func/ta_APO.c) |
| Rust | [`apo.rs`](https://github.com/TA-Lib/ta-lib/blob/main/ta_codegen/output/rust/library/src/ta_func/apo.rs) |
| Java | [`Core_APO.java`](https://github.com/TA-Lib/ta-lib/blob/main/ta_codegen/output/java/fragments/Core_APO.java) |

TA-Lib is also available for Python, R and more using a [wrapper](/install/#wrappers).

## Aliases

Absolute Price Oscillator

## See Also

PPO · MACD · MA · EMA · SMA

## References

- Gerald Appel, creator of the MACD (introduced 1979 in his *Systems and Forecasts* newsletter). The APO is the same fast-minus-slow moving-average oscillator in price units; with exponential moving averages and periods 12/26 it is the oscillator underlying the MACD line. Appel's original definition uses **exponential** moving averages.
